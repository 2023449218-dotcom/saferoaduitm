<?php 

/* Import PHPMailer classes */
use PHPMailer\PHPMailer\PHPMailer; 
use PHPMailer\PHPMailer\Exception; 

/* Load PHPMailer library files */
require_once __DIR__ . '/../PHPMailer/src/Exception.php';
require_once __DIR__ . '/../PHPMailer/src/PHPMailer.php';
require_once __DIR__ . '/../PHPMailer/src/SMTP.php';


/*=====================================================
    Function: sendEmail()

    Purpose:
    Send a standard HTML email notification
    to the recipient.

    Parameters:
    - Recipient Email
    - Recipient Name
    - Email Subject
    - Email Body

    Return:
    - true  = Email sent successfully
    - false = Failed to send email
=====================================================*/
function sendEmail( 
    $recipientEmail, 
    $recipientName, 
    $subject, 
    $message 
){ 
    
    /* Create a new PHPMailer instance */
    $mail = new PHPMailer(true); 
 
    try{ 

        /* Configure Gmail SMTP server */
        $mail->isSMTP(); 
 
        $mail->Host = 'smtp.gmail.com'; 
 
        $mail->SMTPAuth = true; 
 
        $mail->Username = 'syafiedaadiela@gmail.com'; 
 
        $mail->Password = 'kand rmlg brxs gebh'; 
 
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; 
 
        $mail->Port = 587; 
        

        /* Set sender information */
        $mail->setFrom( 
            'syafiedaadiela@gmail.com', 
            'SafeRoad UiTM' 
        ); 


        /* Add recipient */
        $mail->addAddress( 
            $recipientEmail, 
            $recipientName 
        ); 
        

        /* Enable HTML email format */
        $mail->isHTML(true); 
 
        $mail->Subject = $subject; 
 
        $mail->Body = $message; 
        

        /* Send email */
        $mail->send(); 
        
        /* Email sent successfully */
        return true; 
 
    } 
    /* Return false if sending fails */
    catch(Exception $e){ 
 
        return false; 
 
    } 
 
}


/*=====================================================
    Function: sendEmailWithImage()

    Purpose:
    Send an HTML email with an embedded image.

    Used for:
    Complaint notifications that include
    additional visual information.

    Parameters:
    - Recipient Email
    - Recipient Name
    - Email Subject
    - Email Body
    - Image Path

    Return:
    - true
    - false
=====================================================*/
function sendEmailWithImage(

    $recipientEmail,

    $recipientName,

    $subject,

    $message,

    $imagePath

){

    $mail = new PHPMailer(true);

    try{

        $mail->isSMTP();

        $mail->Host = 'smtp.gmail.com';

        $mail->SMTPAuth = true;

        $mail->Username = 'syafiedaadiela@gmail.com';

        $mail->Password = 'kand rmlg brxs gebh';

        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;

        $mail->Port = 587;

        $mail->setFrom(
            'syafiedaadiela@gmail.com',
            'SafeRoad UiTM'
        );

        $mail->addAddress(
            $recipientEmail,
            $recipientName
        );

        $mail->isHTML(true);


        /* Embed image into the email if the file exists */
        if(file_exists($imagePath)){

            $mail->addEmbeddedImage(
                $imagePath,
                'resolutionImage'
            );

        }

        $mail->Subject = $subject;

        $mail->Body = $message;

        $mail->send();

        return true;

    }
    catch(Exception $e){

        return false;

    }

}