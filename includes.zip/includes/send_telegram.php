<?php

function sendTelegram(
$chatID,
$message
){

$botToken = "8647750167:AAFT7WUheFhWEYm-KbpkQEgFpe4QMNeMftk";

$url = "https://api.telegram.org/bot".$botToken."/sendMessage";

$data = [

'chat_id' => $chatID,

'text' => $message

];

$options = [

'http' => [

'header' =>
"Content-Type: application/x-www-form-urlencoded\r\n",

'method' => 'POST',

'content' => http_build_query($data)

]

];

$context =
stream_context_create($options);

$result = file_get_contents(
$url,
false,
$context
);

return $result;

}



function sendTelegramPhoto(
$chatID,
$imagePath,
$caption
){

$botToken =
"8647750167:AAFT7WUheFhWEYm-KbpkQEgFpe4QMNeMftk";

$url =
"https://api.telegram.org/bot".$botToken."/sendPhoto";

$data = [

'chat_id' => $chatID,

'caption' => $caption,

'photo' => new CURLFile(realpath($imagePath))

];

$ch = curl_init();

curl_setopt(
$ch,
CURLOPT_URL,
$url
);

curl_setopt(
$ch,
CURLOPT_POST,
true
);

curl_setopt(
$ch,
CURLOPT_POSTFIELDS,
$data
);

curl_setopt(
$ch,
CURLOPT_RETURNTRANSFER,
true
);

$result =
curl_exec($ch);

curl_close($ch);

return $result;

}

?>