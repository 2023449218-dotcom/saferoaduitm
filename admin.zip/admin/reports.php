<?php

session_start();



/* Set Malaysia timezone */
date_default_timezone_set('Asia/Kuala_Lumpur');



if(!isset($_SESSION['Role']) || $_SESSION['Role']!="Admin"){

    header("Location: ../index.php");

    exit();
}




include("../db.php");





$adminID = $_SESSION['UserID'];

$name = $_SESSION['UserName'];




$adminQuery = mysqli_query(
$conn,
"SELECT Admin_profile
FROM admin
WHERE AdminID='$adminID'"
);

$admin = mysqli_fetch_assoc($adminQuery);


$profileImage = !empty($admin['Admin_profile'])
?
"../uploads/profile/".$admin['Admin_profile']
:
"../images/default-profile.png";




$currentMonth = isset($_GET['month']) ? (int)$_GET['month'] : date("n");
$currentYear  = isset($_GET['year']) ? (int)$_GET['year'] : date("Y");



$summaryQuery = mysqli_query(
$conn,
"SELECT
Complaint_status,
COUNT(*) AS Total
FROM complaint
WHERE
MONTH(Complaint_createdAt)='$currentMonth'
AND
YEAR(Complaint_createdAt)='$currentYear'
GROUP BY Complaint_status"
);

$summary = [];

while($row = mysqli_fetch_assoc($summaryQuery)){

    $summary[$row['Complaint_status']] = $row['Total'];
}








$categoryQuery = mysqli_query($conn,
"SELECT
cc.CategoryName,
COUNT(*) AS Total
FROM complaint c
INNER JOIN category cc
ON c.CategoryID = cc.CategoryID
WHERE
MONTH(c.Complaint_createdAt)='$currentMonth'
AND
YEAR(c.Complaint_createdAt)='$currentYear'
GROUP BY c.CategoryID
ORDER BY
Total DESC,
cc.CategoryName ASC"
);






$riskQuery = mysqli_query($conn,
"SELECT
cs.Subcategory_risk,
COUNT(*) AS Total
FROM complaint c
INNER JOIN subcategory cs
ON c.SubcategoryID = cs.SubcategoryID
WHERE
MONTH(c.Complaint_createdAt)='$currentMonth'
AND
YEAR(c.Complaint_createdAt)='$currentYear'
GROUP BY cs.Subcategory_risk
ORDER BY FIELD(
cs.Subcategory_risk,
'High',
'Medium',
'Low'
)"
);






$policeQuery = mysqli_query(
$conn,
"SELECT
ap.Police_fullName,

COUNT(c.ComplaintID) AS Assigned,

SUM(
CASE
WHEN c.Complaint_status='Resolved'
THEN 1
ELSE 0
END
) AS Resolved,

SUM(
CASE
WHEN c.Complaint_status='Escalated'
THEN 1
ELSE 0
END
) AS Escalated

FROM auxiliary_police ap

LEFT JOIN complaint c
ON ap.PoliceID = c.PoliceID
AND MONTH(c.Complaint_createdAt) = '$currentMonth'
AND YEAR(c.Complaint_createdAt) = '$currentYear'

GROUP BY ap.PoliceID
"
);







$escalatedQuery = mysqli_query(
$conn,
"SELECT
c.ReferenceNumber,
cc.CategoryName,
ap.Police_fullName,
c.Complaint_deadline,

DATEDIFF(
CURDATE(),
DATE(c.Complaint_deadline)
) AS OverdueDays

FROM complaint c

LEFT JOIN category cc
ON c.CategoryID = cc.CategoryID

LEFT JOIN auxiliary_police ap
ON c.PoliceID = ap.PoliceID

WHERE c.Complaint_status='Escalated'

AND MONTH(c.Complaint_createdAt)='$currentMonth'

AND YEAR(c.Complaint_createdAt)='$currentYear'

ORDER BY c.Complaint_deadline DESC"
);

?>




<!DOCTYPE html>

<html>

<head>

<link rel="icon" type="image/png" href="../images/logo.png">

<title>Monthly Report</title>

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:Arial,sans-serif;
}

body{
background:#f4f6f9;
}

/* Sidebar */

.sidebar{
width:250px;
height:100vh;
background:#5E2D91;
position:fixed;
left:0;
top:0;
box-shadow:2px 0 10px rgba(0,0,0,0.1);
}

.logo-section{
text-align:center;
padding:20px;
border-bottom:1px solid rgba(255,255,255,0.15);
}

.sidebar-logo{
width:80px;
height:80px;
object-fit:contain;
}

.sidebar h2{
color:white;
font-size:20px;
margin-top:10px;
}

.sidebar a{
display:block;
padding:15px 20px;
color:white;
text-decoration:none;
font-size:15px;
transition:0.3s;
}

.sidebar a:hover{
background:#4b2374;
}

.active{
background:#4b2374;
border-left:5px solid white;
}

.content{
margin-left:250px;
padding:30px;
margin-top:20px;
}



.dashboard-header{
background:white;
padding:25px 30px;
border-radius:15px;
margin-bottom:25px;
box-shadow:0 2px 10px rgba(0,0,0,0.08);
border-left:5px solid #5E2D91;
}

.dashboard-header h1{
margin-bottom:8px;
font-size:38px;
}

.dashboard-header p{
color:#666;
margin:0;
}



table{
width:100%;
border-collapse:collapse;
margin-bottom:20px;
background:white;
}

th{
text-align:center;
background:#5E2D91;
color:white;
padding:10px;
}

td{
text-align:center;
padding:10px;
border:1px solid #ddd;
}




.btn{
background:#5E2D91;
color:white;
padding:10px 20px;
text-decoration:none;
border-radius:5px;
}

.stats{
display:grid;
grid-template-columns:repeat(4,1fr);
gap:20px;
margin-bottom:25px;
}

.card{
background:white;
padding:20px;
border-radius:15px;
box-shadow:0 2px 10px rgba(0,0,0,0.08);
text-align:center;
}

.card h3{
font-size:14px;
color:#666;
margin-bottom:10px;
}

.card p{
font-size:28px;
font-weight:bold;
color:#5E2D91;
}

.content{
margin-left:250px;
padding:30px;
}

select{
padding:10px;
border:1px solid #ddd;
border-radius:8px;
margin-right:10px;
}

.filter-box{
background:white;
padding:15px;
border-radius:12px;
margin-bottom:20px;
box-shadow:0 2px 10px rgba(0,0,0,0.08);
}





.topbar{
height:70px;
background:white;
display:flex;
justify-content:flex-end;
align-items:center;
padding:0 30px;
box-shadow:0 2px 10px rgba(0,0,0,0.1);
margin-left:250px;
}

.profile-menu{
display:flex;
align-items:center;
gap:10px;
position:relative;
}

.username{
font-weight:bold;
color:#5E2D91;
}

.profile-menu img{
width:45px;
height:45px;
border-radius:50%;
object-fit:cover;
cursor:pointer;
border:2px solid #5E2D91;
}

.dropdown{
display:none;
position:absolute;
right:0;
top:55px;
background:white;
width:180px;
border-radius:10px;
box-shadow:0 5px 15px rgba(0,0,0,0.15);
overflow:hidden;
z-index:999;
}

.dropdown a{
display:block;
padding:12px 15px;
text-decoration:none;
color:#333;
}

.dropdown a:hover{
background:#f5f5f5;
}
</style>

</head>







<body>

<div class="sidebar">

    <div class="logo-section">

        <img
        src="../images/logo.png"
        class="sidebar-logo">

        <h2>SafeRoad UiTM</h2>

        <p class="sidebar-role">
            Administrator
        </p>

    </div>

    <a href="dashboard.php">
        Dashboard
    </a>

    <a href="manage_complaints.php">
        Manage Complaints
    </a>

    <a href="heatmap.php">
        Complaint Heatmap
    </a>

    <a href="reports.php" class="active">
        Reports
    </a>

</div>



<div class="topbar">

    <div class="profile-menu">

        <span class="username">
            <?php echo $name; ?>
        </span>

        <img
        src="<?php echo $profileImage; ?>"
        alt="Profile"
        onclick="toggleMenu()">

        <div
        id="dropdownMenu"
        class="dropdown">

            <a href="profile.php">
                My Profile
            </a>

            <a href="../logout.php">
                Logout
            </a>

        </div>

    </div>

</div>






<div class="content">

<div class="dashboard-header">

<h1>Monthly Complaint Report</h1>

<p>Traffic complaint statistics and performance report.</p>

<br>

<p>
<strong>Report Period:</strong>
<?php echo date("F Y", mktime(0,0,0,$currentMonth,1,$currentYear)); ?>
</p>

<p>
<strong>Generated On:</strong>
<?php echo date("d F Y, h:i A"); ?>
</p>

</div>

<form method="GET" class="filter-box">

<label><strong>Month:</strong></label>

<select name="month">

<?php

for($m=1;$m<=12;$m++){

?>

<option
value="<?php echo $m; ?>"

<?php
if((isset($_GET['month']) && $_GET['month']==$m)
||
(!isset($_GET['month']) && $m==date("n"))){
echo "selected";
}
?>

>

<?php echo date("F", mktime(0,0,0,$m,1)); ?>

</option>

<?php } ?>

</select>





<label><strong>Year:</strong></label>
<select name="year">

<?php

for(
$y=date("Y");
$y>=2024;
$y--
){

?>

<option

value="<?php echo $y; ?>"

<?php
if((isset($_GET['year']) && $_GET['year']==$y)
||
(!isset($_GET['year']) && $y==date("Y"))){

    echo "selected";
}

?>

>

<?php echo $y; ?>

</option>

<?php } ?>

</select>

<button
type="submit"
class="btn">

Filter Report

</button>

</form>
   




<a
href="generate_report_pdf.php?month=<?php echo $currentMonth; ?>&year=<?php echo $currentYear; ?>"
class="btn">

Download Monthly Report (PDF)

</a>

<br><br>






<?php if(array_sum($summary) == 0){ ?>

<div style="
background:#fff3cd;
color:#856404;
padding:15px;
margin-bottom:20px;
border-radius:10px;
border:1px solid #ffeeba;
text-align:center;
">

No complaint records were found for the selected month.

</div>

<?php } ?>

<div class="stats">

<div class="card">


<h3>Total Complaints</h3>
<p><?php echo array_sum($summary); ?></p>

</div>

<div class="card">

<h3>Resolved</h3>
<p><?php echo $summary['Resolved'] ?? 0; ?></p>

</div>

<div class="card">

<h3>Escalated</h3>
<p><?php echo $summary['Escalated'] ?? 0; ?></p>

</div>

<div class="card">
<h3> Complaint Resolution Rate</h3>
<p>

<?php

$resolved = $summary['Resolved'] ?? 0;

$cancelled = $summary['Cancelled'] ?? 0;

$total = array_sum($summary) - $cancelled;

echo
$total > 0
?
round(($resolved / $total) * 100) . "%"
:
"0%";

?>

</p>

</div>

</div>







<h2>Complaint Summary</h2>

<table border="1" cellpadding="10">

<tr>
<th>Status</th>
<th>Total</th>
</tr>

<tr>
<td>Pending</td>
<td><?php echo $summary['Pending'] ?? 0; ?></td>
</tr>

<tr>
<td>Awaiting Police</td>
<td><?php echo $summary['Awaiting Police'] ?? 0; ?></td>
</tr>

<tr>
<td>Warning Sent</td>
<td><?php echo $summary['Warning Sent'] ?? 0; ?></td>
</tr>

<tr>
<td>In Progress</td>
<td><?php echo $summary['In Progress'] ?? 0; ?></td>
</tr>

<tr>
<td>Resolved</td>
<td><?php echo $summary['Resolved'] ?? 0; ?></td>
</tr>

<tr>
<td>Escalated</td>
<td><?php echo $summary['Escalated'] ?? 0; ?></td>
</tr>

<tr>
<td>Cancelled</td>
<td><?php echo $summary['Cancelled'] ?? 0; ?></td>
</tr>

</table>








<h2>Complaint Categories</h2>

<table>

<tr>
<th>Category</th>
<th>Total Complaints</th>
</tr>

<?php

if(mysqli_num_rows($categoryQuery) > 0){

    while($row = mysqli_fetch_assoc($categoryQuery)){
?>

<tr>
    <td><?php echo $row['CategoryName']; ?></td>
    <td><?php echo $row['Total']; ?></td>
</tr>

<?php
    }

}

else{
?>

<tr>
    <td colspan="2" style="text-align:center;">
        No data available for the selected month.
    </td>
</tr>

<?php } ?>

</table>








<h2>Risk Level Analysis</h2>

<table>

<tr>
<th>Risk Level</th>
<th>Total Complaints</th>
</tr>

<?php

if(mysqli_num_rows($riskQuery) > 0){

while($row=mysqli_fetch_assoc($riskQuery)){
?>

<tr>

<td>

<?php

$risk = $row['Subcategory_risk'];

if($risk == "High"){

echo "<span style='color:red;font-weight:bold;'>High</span>";

}
elseif($risk == "Medium"){

echo "<span style='color:orange;font-weight:bold;'>Medium</span>";

}
else{

echo "<span style='color:green;font-weight:bold;'>Low</span>";

}

?>

</td>

<td><?php echo $row['Total']; ?></td>

</tr>

<?php
}

}

else{
?>

<tr>

<td colspan="2" style="text-align:center;">
No data available for the selected month.
</td>

</tr>

<?php } ?>

</table>





<h2>Auxiliary Police Performance</h2>

<table>

<tr>
<th>Police Officer</th>
<th>Assigned Cases</th>
<th>Resolved Cases</th>
<th>Escalated Cases</th>
<th>Performance</th>
</tr>

<?php

if(mysqli_num_rows($policeQuery) > 0){

while($row=mysqli_fetch_assoc($policeQuery)){
?>

<tr>

<td><?php echo $row['Police_fullName']; ?></td>

<td><?php echo $row['Assigned']; ?></td>

<td><?php echo $row['Resolved']; ?></td>

<td><?php echo $row['Escalated']; ?></td>

<td>

<?php

if($row['Assigned']==0){

    echo "-";

}

else{

    $rate = ($row['Resolved'] / $row['Assigned']) * 100;

    if($rate >= 80){

        echo "Excellent";

    }
    elseif($rate >= 50){

        echo "Good";

    }
    else{

        echo "Poor";

    }

}

?>

</td>

</tr>

<?php
}

}

else{
?>

<tr>

<td colspan="5" style="text-align:center;">
No data available for the selected month.
</td>

</tr>

<?php } ?>

</table>








<h2>Escalated Complaints</h2>

<table>

<tr>
<th>Reference No</th>
<th>Category</th>
<th>Assigned Police</th>
<th>Deadline</th>
<th>Overdue Days</th>
</tr>

<?php

if(mysqli_num_rows($escalatedQuery) > 0){

while($row=mysqli_fetch_assoc($escalatedQuery)){
?>

<tr>

<td><?php echo $row['ReferenceNumber']; ?></td>

<td><?php echo $row['CategoryName']; ?></td>

<td>
<?php
echo $row['Police_fullName'] ?? "Not Assigned";
?>
</td>

<td>
<?php
echo date(
"d M Y",
strtotime($row['Complaint_deadline'])
);
?>
</td>

<td>
<?php

$days = max(0,$row['OverdueDays']);

echo $days;

echo $days == 1 ? " day" : " days";

?>

</td>

</tr>

<?php
}

}

else{
?>

<tr>

<td colspan="5" style="text-align:center;">
No escalated complaints for the selected month.
</td>

</tr>

<?php } ?>

</table>












<script>

function toggleMenu(){

var menu = document.getElementById("dropdownMenu");

if(menu.style.display=="block"){

menu.style.display="none";

}

else{

menu.style.display="block";

}

}

document.addEventListener("click",

function(event){

var menu = document.getElementById("dropdownMenu");

var profile = document.querySelector(".profile-menu");

if(!profile.contains(event.target)
){

menu.style.display="none";

}

}
);

</script>

</body>

</html>










