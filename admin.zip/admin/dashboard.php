<?php

session_start();


date_default_timezone_set('Asia/Kuala_Lumpur');


if(!isset($_SESSION['Role']) || $_SESSION['Role'] != "Admin"){

    header("Location: ../index.php");

    exit();
}




include("../db.php");




$adminID = $_SESSION['UserID'];

$name = $_SESSION['UserName'];





$adminQuery = mysqli_query(
$conn,
"SELECT Admin_profile
FROM admin
WHERE AdminID='$adminID'"
);

$admin = mysqli_fetch_assoc($adminQuery);



$profileImage = !empty($admin['Admin_profile'])
?
"../uploads/profile/".$admin['Admin_profile']
:
"../images/default-profile.png";




$totalTodayQuery = mysqli_query(
$conn,

"SELECT COUNT(DISTINCT c.ComplaintID) AS Total
FROM complaint c
INNER JOIN complaint_timeline t
ON c.ComplaintID = t.ComplaintID
WHERE DATE(t.TimelineDate)=CURDATE()"
);

$totalToday = mysqli_fetch_assoc($totalTodayQuery)['Total'];





$pendingTodayQuery = mysqli_query(
$conn,

"SELECT COUNT(DISTINCT c.ComplaintID) AS Total
FROM complaint c
INNER JOIN complaint_timeline t
ON c.ComplaintID=t.ComplaintID
WHERE c.Complaint_status='Pending'
AND DATE(t.TimelineDate)=CURDATE()"
);

$pendingToday = mysqli_fetch_assoc($pendingTodayQuery)['Total'];



$awaitingTodayQuery = mysqli_query(
$conn,

"SELECT COUNT(DISTINCT c.ComplaintID) AS Total
FROM complaint c
INNER JOIN complaint_timeline t
ON c.ComplaintID=t.ComplaintID
WHERE c.Complaint_status='Awaiting Police'
AND DATE(t.TimelineDate)=CURDATE()"
);

$awaitingToday = mysqli_fetch_assoc($awaitingTodayQuery)['Total'];




$progressTodayQuery = mysqli_query(
$conn,

"SELECT COUNT(DISTINCT c.ComplaintID) AS Total
FROM complaint c
INNER JOIN complaint_timeline t
ON c.ComplaintID=t.ComplaintID
WHERE c.Complaint_status='In Progress'
AND DATE(t.TimelineDate)=CURDATE()"
);

$progressToday = mysqli_fetch_assoc($progressTodayQuery)['Total'];






$resolvedTodayQuery = mysqli_query(
$conn,

"SELECT COUNT(DISTINCT c.ComplaintID) AS Total
FROM complaint c
INNER JOIN complaint_timeline t
ON c.ComplaintID=t.ComplaintID
WHERE c.Complaint_status='Resolved'
AND DATE(t.TimelineDate)=CURDATE()"
);

$resolvedToday = mysqli_fetch_assoc($resolvedTodayQuery)['Total'];



$warningTodayQuery = mysqli_query(
$conn,

"SELECT COUNT(DISTINCT c.ComplaintID) AS Total
FROM complaint c
INNER JOIN complaint_timeline t
ON c.ComplaintID=t.ComplaintID
WHERE c.Complaint_status='Warning Sent'
AND DATE(t.TimelineDate)=CURDATE()"
);

$warningToday = mysqli_fetch_assoc($warningTodayQuery)['Total'];




$recentQuery = mysqli_query(
    $conn,

    "SELECT
        c.ComplaintID,
        c.ReferenceNumber,
        c.Complaint_status,
        cs.Subcategory_name,
        c.Complaint_createdAt
    FROM complaint c
    INNER JOIN subcategory cs
        ON c.SubcategoryID = cs.SubcategoryID
    WHERE c.Complaint_status NOT IN ('Escalated', 'Cancelled')
    ORDER BY c.Complaint_createdAt DESC
    LIMIT 5"
);





$subcategoryChartQuery = mysqli_query($conn,
"SELECT
cs.Subcategory_name,
COUNT(*) AS TotalComplaints
FROM complaint c
JOIN subcategory cs
ON c.SubcategoryID=cs.SubcategoryID
GROUP BY cs.SubcategoryID
ORDER BY TotalComplaints DESC
LIMIT 8"
);


$subcategoryLabels = [];
$subcategoryData = [];

while($row = mysqli_fetch_assoc($subcategoryChartQuery)){

    $subcategoryLabels[] = $row['Subcategory_name'];

    $subcategoryData[] = $row['TotalComplaints'];

}




$statusLabels = [

"Pending",

"Awaiting Police",

"In Progress",

"Warning Sent",

"Resolved"

];



$statusData = [

$pendingToday,

$awaitingToday,

$progressToday,

$warningToday,

$resolvedToday

];

$totalStatusToday = array_sum($statusData);





$categoryQuery = mysqli_query(
$conn,
"SELECT
cc.CategoryName,
COUNT(*) AS Total
FROM complaint c
INNER JOIN category cc
ON c.CategoryID = cc.CategoryID
GROUP BY c.CategoryID"
);


$categoryLabels = [];
$categoryData = [];

while($row = mysqli_fetch_assoc($categoryQuery)){

$categoryLabels[] = $row['CategoryName'];

$categoryData[] = $row['Total'];

}






$riskQuery = mysqli_query(
$conn,
"SELECT
Subcategory_risk,
COUNT(*) AS Total
FROM complaint c
INNER JOIN subcategory cs
ON c.SubcategoryID = cs.SubcategoryID
GROUP BY Subcategory_risk"
);

$riskLabels = [];
$riskData = [];


while($row = mysqli_fetch_assoc($riskQuery)){

$riskLabels[] = $row['Subcategory_risk'];

$riskData[] = $row['Total'];

}





$trendQuery = mysqli_query(
$conn,
"SELECT
DATE_FORMAT(Complaint_createdAt,'%b %Y') AS Month,
COUNT(*) AS Total
FROM complaint
WHERE Complaint_createdAt >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
GROUP BY YEAR(Complaint_createdAt), MONTH(Complaint_createdAt)
ORDER BY YEAR(Complaint_createdAt), MONTH(Complaint_createdAt)"
);


$trendLabels = [];
$trendData = [];

while($row = mysqli_fetch_assoc($trendQuery)){

$trendLabels[] = $row['Month'];

$trendData[] = $row['Total'];

}






$locationQuery = mysqli_query(
$conn,
"SELECT
Complaint_locationName,
COUNT(*) AS Total
FROM complaint
WHERE Complaint_locationName IS NOT NULL
AND Complaint_locationName <> ''
GROUP BY Complaint_locationName
ORDER BY Total DESC
LIMIT 5"
);

$locations = [];

$maxTotal = 0;

while($row = mysqli_fetch_assoc($locationQuery)){

    $locations[] = $row;

    if($row['Total'] > $maxTotal){

        $maxTotal = $row['Total'];

    }

}

?>








<!DOCTYPE html>

<html>

<head>

<link rel="icon" type="image/png" href="../images/logo.png">

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<title>Admin Dashboard</title>

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:Arial,sans-serif;
}

body{
background:#f4f6f9;
}

/* Sidebar */

.sidebar{
width:250px;
height:100vh;
background:#5E2D91;
position:fixed;
left:0;
top:0;
box-shadow:2px 0 10px rgba(0,0,0,0.1);
}

.logo-section{
text-align:center;
padding:20px;
border-bottom:1px solid rgba(255,255,255,0.15);
}

.sidebar-logo{
width:80px;
height:80px;
object-fit:contain;
}

.sidebar h2{
color:white;
font-size:20px;
margin-top:10px;
}

.sidebar a{
    display:block;
    padding:15px 20px;
    color:white;
    text-decoration:none;
    font-size:15px;
    transition:0.3s;
}

.sidebar a:hover{
    background:#4b2374;
}

.sidebar a.active{
    background:#4b2374;
    border-left:5px solid white;
}

/* Topbar */

.topbar{
height:70px;
background:white;
display:flex;
justify-content:flex-end;
align-items:center;
padding:0 30px;
margin-left:250px;
box-shadow:0 2px 10px rgba(0,0,0,0.08);
}

.profile-menu{
display:flex;
align-items:center;
gap:10px;
position:relative;
cursor:pointer;
}

.username{
font-weight:bold;
color:#333;
}

.profile-menu img{
width:45px;
height:45px;
border-radius:50%;
object-fit:cover;
border:2px solid #5E2D91;
}

.dropdown{
display:none;
position:absolute;
right:0;
top:55px;
background:white;
width:180px;
border-radius:10px;
box-shadow:0 5px 15px rgba(0,0,0,0.15);
overflow:hidden;
z-index:9999;
}

.dropdown a{
display:block;
padding:12px 15px;
text-decoration:none;
color:#333;
}

.dropdown a:hover{
background:#f5f5f5;
}

/* Content */

.content{
margin-left:250px;
padding:30px;
}


/* Cards */

.card{
background:white;
display:flex;
justify-content:space-between;
align-items:center;
padding:22px;
border-radius:15px;
box-shadow:0 2px 10px rgba(0,0,0,0.08);
transition:.3s;
min-height:110px;
}

.card-left h4{
color:#666;
font-size:15px;
margin-bottom:8px;
font-weight:600;
}

.card-left h2{
font-size:34px;
font-weight:700;
margin-top:5px;
color:#222;
}

.card-icon{
width:60px;
height:60px;
border-radius:50%;
display:flex;
justify-content:center;
align-items:center;
font-size:28px;
color:white;
}

.card:hover{
transform:translateY(-5px);
box-shadow:0 10px 25px rgba(0,0,0,0.12);
}



.icon-total{
background:#5E2D91;
}

.icon-pending{
background:#f39c12;
}

.icon-progress{
background:#1f4e79;
}

.icon-resolved{
background:#27ae60;
}

.icon-warning{
background:#9b59b6;
}

.icon-awaiting{
background:#17a2b8;
}





/* Card Colors */

.pending{
border-left:5px solid #f39c12;
}

.progress{
border-left:5px solid #1f4e79;
}

.resolved{
border-left:5px solid #27ae60;
}

.warning{
border-left:5px solid #9b59b6;
}

.awaiting{
border-left:5px solid #17a2b8;
}





/* Status Text */

.status-pending,
.status-progress,
.status-resolved,
.status-warning,
.status-awaiting{

display:inline-block;
padding:6px 12px;
border-radius:20px;
font-size:12px;
font-weight:bold;
color:white;

}


.status-pending{
background:#f39c12;
}

.status-progress{
background:#1f4e79;
}

.status-resolved{
background:#27ae60;
}

.status-warning{
background:#9b59b6;
}

.status-awaiting{
background:#17a2b8;
}






/* Table Card */

.recent-card{
background:white;
padding:20px;
border-radius:12px;
box-shadow:0 2px 10px rgba(0,0,0,0.08);
}

.recent-card h3{
color:#5E2D91;
margin-bottom:15px;
}



.stats{
display:grid;
grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
gap:20px;
margin-top:20px;
}


canvas{
max-height:350px;
}

table{
width:100%;
border-collapse:collapse;
}

th{
background:#5E2D91;
color:white;
padding:12px;
}

td{
padding:12px;
border-bottom:1px solid #ddd;
}


.dashboard-grid{
display:grid;
grid-template-columns:35% 65%;
gap:20px;
margin-top:20px;
}


.chart-card{
background:white;
padding:25px;
border-radius:15px;
box-shadow:0 2px 12px rgba(0,0,0,.08);
transition:.3s;
}

.chart-card:hover{
transform:translateY(-3px);
box-shadow:0 8px 20px rgba(0,0,0,.12);
}

.chart-card canvas{
max-height:280px;
}


.full-width{
grid-column:1 / span 2;
}


.table-grid{
display:grid;
grid-template-columns:1fr 1fr;
gap:20px;
margin-top:20px;
}


.location-item{
margin-bottom:20px;
}

.location-header{
display:flex;
justify-content:space-between;
font-weight:bold;
margin-bottom:8px;
font-size:15px;
color:#333;
}

.location-bar{
width:100%;
height:12px;
background:#ececec;
border-radius:20px;
overflow:hidden;
}

.location-fill{
height:100%;
background:linear-gradient(90deg,#5E2D91,#8A4FFF);
border-radius:20px;
transition:width .5s;
}


.recent-table tbody tr{
cursor:pointer;
}

.recent-table tbody tr:hover{
background:#f5f0ff;
transform:scale(1.01);
transition:0.2s;
}


.dashboard-header{
display:flex;
justify-content:space-between;
align-items:center;
background:white;
padding:25px 30px;
border-radius:15px;
margin-bottom:25px;
box-shadow:0 2px 10px rgba(0,0,0,0.08);
border-left:5px solid #5E2D91;
}

.dashboard-date{
background:#f5f0ff;
color:#5E2D91;
padding:10px 18px;
border-radius:30px;
font-weight:bold;
font-size:14px;
}

.dashboard-header h1{
margin-bottom:8px;
font-size:38px;
}

.dashboard-header p{
color:#666;
margin:0;
}

.empty-chart{

height:280px;

display:flex;
flex-direction:column;
justify-content:center;
align-items:center;

color:#888;

text-align:center;

}

.empty-icon{

font-size:60px;

margin-bottom:15px;

opacity:.5;

}

.empty-chart h3{

margin-bottom:8px;

color:#555;

}

.empty-chart p{

font-size:14px;

color:#888;

}

</style>

</head>

<body>

<div class="sidebar">

    <div class="logo-section">

        <img
        src="../images/logo.png"
        class="sidebar-logo">

        <h2>SafeRoad UiTM</h2>

        <p class="sidebar-role">
            Administrator
        </p>

    </div>

        <a href="dashboard.php" class="active">
        Dashboard
        </a>

        <a href="manage_complaints.php">
        Manage Complaints
        </a>

        <a href="heatmap.php">
        Complaint Heatmap
        </a>

        <a href="reports.php">
        Reports
        </a>

</div>






<div class="topbar">

    <div class="profile-menu">

        <span class="username">
            <?php echo $name; ?>
        </span>

        <img
        src="<?php echo $profileImage; ?>"
        alt="Profile"
        onclick="toggleMenu()">

        <div
        id="dropdownMenu"
        class="dropdown">

        <a href="profile.php">
            My Profile
        </a>

         <a href="../logout.php">
        Logout
        </a>

        </div>

    </div>

</div>




<div class="content">

<div class="dashboard-header">

    <div>

        <h1>Administrator Dashboard</h1>

            <p>

            Welcome back, <?php echo htmlspecialchars($name); ?>.

            Monitor today's complaint activities across UiTM Shah Alam.

            </p>

    </div>



    <div class="dashboard-date">

        <?php echo date("l, d F Y"); ?>

    </div>

</div>






<div class="stats">

<div class="card">

    <div class="card-left">

        <h4>Today's Complaints</h4>

        <h2><?php echo $totalToday; ?></h2>

    </div>

    <div class="card-icon icon-total">

        📋

    </div>

</div>





<div class="card pending">

    <div class="card-left">

        <h4>Pending</h4>

        <h2><?php echo $pendingToday; ?></h2>

    </div>

    <div class="card-icon icon-pending">

        ⏳

    </div>

</div>





<div class="card progress">

    <div class="card-left">

        <h4>In Progress</h4>

       <h2><?php echo $progressToday; ?></h2>

    </div>

    <div class="card-icon icon-progress">

        🔄

    </div>

</div>




<div class="card awaiting">

    <div class="card-left">

        <h4>Awaiting Police</h4>

        <h2><?php echo $awaitingToday; ?></h2>

    </div>

    <div class="card-icon icon-awaiting">

        👮

    </div>

</div>







<div class="card resolved">

    <div class="card-left">

        <h4>Resolved</h4>

        <h2><?php echo $resolvedToday; ?></h2>

    </div>

    <div class="card-icon icon-resolved">

        ✓

    </div>

</div>





<div class="card warning">

    <div class="card-left">

        <h4>Warning Sent</h4>

        <h2><?php echo $warningToday; ?></h2>

    </div>

    <div class="card-icon icon-warning">

        ⚠️

    </div>

</div>

</div>






<div class="dashboard-grid">

    <div class="chart-card">

    <h3>📊 Today's Complaint Status</h3>

    <p style="color:#777;font-size:13px;margin-top:5px;">

    Current complaint distribution based on today's reports.

    </p>

    <?php if($totalStatusToday > 0){ ?>

    <canvas id="statusChart"></canvas>

    <?php }else{ ?>

    <div class="empty-chart">

        <div class="empty-icon">📊</div>

        <h3>No Data Yet</h3>

        <p>No complaints have been submitted today.</p>

    </div>

    <?php } ?>

    </div>






<div class="chart-card">

    <h3>📈 Monthly Complaint Trend</h3>

    <p style="color:#777;font-size:13px;margin-top:5px;">

    Complaint trends over the last 12 months.

    </p>

    <canvas id="trendChart"></canvas>

    </div>

</div>







<br>

<div class="table-grid">

<div class="chart-card">

<h3>📋 Latest Complaints</h3>

<table class="recent-table">

<tr>
<th>Reference No</th>
<th>Issue</th>
<th>Status</th>
<th>Date</th>
</tr>

<?php
while($row=mysqli_fetch_assoc($recentQuery)){
?>

<tr
onclick="window.location='view_complaint.php?id=<?php echo $row['ComplaintID']; ?>'"
style="cursor:pointer;">

    <td>
    <?php echo $row['ReferenceNumber']; ?>
    </td>


    <td>
    <?php echo $row['Subcategory_name']; ?>
    </td>


    <td>
    <?php

    $class="";

    if($row['Complaint_status']=="Pending"){
    $class="status-pending";
    }
    elseif($row['Complaint_status']=="In Progress"){
    $class="status-progress";
    }
    elseif($row['Complaint_status']=="Resolved"){
    $class="status-resolved";
    }
    elseif($row['Complaint_status']=="Warning Sent"){
    $class="status-warning";
    }
    elseif($row['Complaint_status']=="Awaiting Police"){
    $class="status-awaiting";
    }

    ?>

    <span class="<?php echo $class; ?>">
    <?php echo $row['Complaint_status']; ?>
    </span>
    </td>


    <td>
    <?php
    echo date("d M Y",strtotime($row['Complaint_createdAt']));
    ?>
    </td>

</tr>



<?php } ?>

</table>

</div>



<div class="chart-card">

<h3>📍 Top 5 Complaint Locations</h3>

<p style="color:#777;font-size:13px;margin-top:5px;">

Locations with the highest number of reported complaints.

</p>

<?php
foreach($locations as $row){

$percentage = ($maxTotal > 0)
    ? ($row['Total'] / $maxTotal) * 100
    : 0;
?>

<div class="location-item">

    <div class="location-header">

        <span>
            <?php echo htmlspecialchars($row['Complaint_locationName']); ?>
        </span>

        <span>
            <?php echo $row['Total']; ?>
        </span>

    </div>

    <div class="location-bar">

        <div
        class="location-fill"
        style="width:<?php echo $percentage; ?>%;">

        </div>

    </div>

</div>

<?php } ?>

</div>

</div>


<br>


<div class="chart-card">

<h3>📊 Top 8 Complaint Issues Analysis</h3>

<canvas id="issueChart"></canvas>

</div>







<script>

const statusCanvas = document.getElementById('statusChart');

if(statusCanvas){

new Chart(statusCanvas,
{
    type:'doughnut',

    data:{
        labels: <?php echo json_encode($statusLabels); ?>,
        datasets:[{
            data: <?php echo json_encode($statusData); ?>,
            backgroundColor:[
                '#f39c12',
                '#1f4e79',
                '#27ae60',
                '#17a2b8',
                '#9b59b6',
                '#17a2b8'
            ],
            borderWidth:1
        }]
    },

    options:{
        plugins:{
            legend:{
                position:'bottom'
            }
        }
    }

});

}

</script>




<script>

new Chart(document.getElementById('trendChart'),
{

type:'line',

data:{

labels:
<?php echo json_encode($trendLabels); ?>,

datasets:[{

label:'Complaints',

data:
<?php echo json_encode($trendData); ?>,

borderColor:'#5E2D91',

backgroundColor:'rgba(94,45,145,0.1)',

fill:true,

tension:0.3

}]

}

}

);

</script>











<script>

new Chart(
document.getElementById("issueChart"),
{
type:'bar',
indexAxis:'y',

data:{
labels:
<?php echo json_encode($subcategoryLabels); ?>,

datasets:[{

label:'Total Complaints',

data:
<?php echo json_encode($subcategoryData); ?>,

backgroundColor:'#5E2D91'

}]
},

options:{

responsive:true,

plugins:{
legend:{
display:false
}
},

scales:{
y:{
beginAtZero:true
}
}

}

}
);

</script>










<script>

function toggleMenu(){

var menu = document.getElementById("dropdownMenu");

if(menu.style.display=="block"){

menu.style.display="none";

}

else{

menu.style.display="block";

}

}

document.addEventListener("click",

function(event){

var menu = document.getElementById("dropdownMenu");

var profile = document.querySelector(".profile-menu");

if(!profile.contains(event.target)
){

menu.style.display="none";

}

}
);

</script>

</body>

</html>









