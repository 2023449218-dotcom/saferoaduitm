<?php

session_start();

if(!isset($_SESSION['Role']) || $_SESSION['Role'] != "Admin"){

    header("Location: ../index.php");
    exit();
}




include("../db.php");



$adminID = $_SESSION['UserID'];

$name = $_SESSION['UserName'];



$adminQuery = mysqli_query(
$conn,
"SELECT Admin_profile
FROM admin
WHERE AdminID='$adminID'"
);

$admin = mysqli_fetch_assoc($adminQuery);



$profileImage = !empty($admin['Admin_profile'])
?
"../uploads/profile/".$admin['Admin_profile']
:
"../images/default-profile.png";





$pendingCount = mysqli_fetch_assoc(mysqli_query(
$conn,
"SELECT COUNT(*) AS Total
FROM complaint
WHERE Complaint_status='Pending'"
))['Total'];



$awaitingCount = mysqli_fetch_assoc(mysqli_query(
$conn,
"SELECT COUNT(*) AS Total
FROM complaint
WHERE Complaint_status='Awaiting Police'"
))['Total'];



$progressCount = mysqli_fetch_assoc(mysqli_query(
$conn,
"SELECT COUNT(*) AS Total
FROM complaint
WHERE Complaint_status='In Progress'"
))['Total'];



$warningCount = mysqli_fetch_assoc(mysqli_query(
$conn,
"SELECT COUNT(*) AS Total
FROM complaint
WHERE Complaint_status='Warning Sent'"
))['Total'];



$resolvedCount = mysqli_fetch_assoc(mysqli_query(
$conn,
"SELECT COUNT(*) AS Total
FROM complaint
WHERE Complaint_status='Resolved'"
))['Total'];




mysqli_query($conn,
"UPDATE complaint
SET Complaint_status='Escalated'
WHERE
Complaint_deadline < NOW()
AND
Complaint_status IN
(
'Pending',
'Warning Sent',
'Awaiting Police',
'In Progress'
)"

);



$sql = "
SELECT
c.*,
cc.CategoryName,
cs.Subcategory_name,
cs.Subcategory_risk,
ap.Police_fullName
FROM complaint c
INNER JOIN category cc
ON c.CategoryID = cc.CategoryID
LEFT JOIN auxiliary_police ap
ON c.PoliceID = ap.PoliceID
INNER JOIN subcategory cs
ON c.SubcategoryID = cs.SubcategoryID
WHERE c.Complaint_status NOT IN
(
'Escalated',
'Cancelled'
)
ORDER BY

FIELD(
c.Complaint_status,
'Pending',
'Awaiting Police',
'In Progress',
'Warning Sent',
'Resolved'
),

FIELD(
cs.Subcategory_risk,
'High',
'Medium',
'Low'
),

c.Complaint_createdAt DESC

";


$complaints = mysqli_query(
$conn,
$sql
);

?>






<!DOCTYPE html>

<html>

<head>

<link rel="icon" type="image/png" href="../images/logo.png">

<title>Manage Complaints</title>

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:Arial,sans-serif;
}

body{
background:#f4f6f9;
}

/* Sidebar */

.sidebar{
width:250px;
height:100vh;
background:#5E2D91;
position:fixed;
left:0;
top:0;
box-shadow:2px 0 10px rgba(0,0,0,0.1);
}

.logo-section{
text-align:center;
padding:20px;
border-bottom:1px solid rgba(255,255,255,0.15);
}

.sidebar-logo{
width:80px;
height:80px;
object-fit:contain;
}

.sidebar h2{
color:white;
font-size:20px;
margin-top:10px;
}

.sidebar a{
display:block;
padding:15px 20px;
color:white;
text-decoration:none;
font-size:15px;
transition:0.3s;
}

.sidebar a:hover{
background:#4b2374;
}

.active{
background:#4b2374;
border-left:5px solid white;
}

.content{
margin-left:250px;
padding:30px;
margin-top:20px;
}



.search-box input{
width:350px;
padding:10px;
border:1px solid #ccc;
border-radius:5px;
}



.dashboard-header{
background:white;
padding:25px 30px;
border-radius:15px;
margin-bottom:25px;
box-shadow:0 2px 10px rgba(0,0,0,0.08);
border-left:5px solid #5E2D91;
}

.dashboard-header h1{
margin-bottom:8px;
font-size:38px;
}

.dashboard-header p{
color:#666;
margin:0;
}


table{
width:100%;
background:white;
border-collapse:collapse;
border-radius:10px;
overflow:hidden;
box-shadow:0 2px 10px rgba(0,0,0,0.1);
}

th{
background:#5E2D91;
color:white;
padding:12px;
}

td{
padding:12px;
border-bottom:1px solid #ddd;
}




.btn{
background:#5E2D91;
color:white;
padding:8px 15px;
text-decoration:none;
border-radius:5px;
}

.btn:hover{
background:#4b2374;
}




.status{
padding:5px 12px;
border-radius:20px;
color:white;
font-size:13px;
font-weight:bold;
}

.pending{
background:#f39c12;
}

.progress{
background:#1f4e79;
}

.resolved{
background:#27ae60;
}


.warning{
background:#9b59b6;
}

.awaiting{
background:#17a2b8;
}



.stats{
display:grid;
grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
gap:20px;
margin-top:20px;
}

.card{
background:white;
padding:25px;
border-radius:15px;
box-shadow:0 2px 15px rgba(0,0,0,0.08);
}

.card h4{
color:#666;
margin-top:10px;
font-size:14px;
}

table tr:hover{
background:#f8f4ff;
}



.topbar{
height:70px;
background:white;
display:flex;
justify-content:flex-end;
align-items:center;
padding:0 30px;
box-shadow:0 2px 10px rgba(0,0,0,0.1);
margin-left:250px;
}

.profile-menu{
display:flex;
align-items:center;
gap:10px;
position:relative;
}

.username{
font-weight:bold;
color:#5E2D91;
}

.profile-menu img{
width:45px;
height:45px;
border-radius:50%;
object-fit:cover;
cursor:pointer;
border:2px solid #5E2D91;
}

.dropdown{
display:none;
position:absolute;
right:0;
top:55px;
background:white;
width:180px;
border-radius:10px;
box-shadow:0 5px 15px rgba(0,0,0,0.15);
overflow:hidden;
z-index:999;
}

.dropdown a{
display:block;
padding:12px 15px;
text-decoration:none;
color:#333;
}

.dropdown a:hover{
background:#f5f5f5;
}

</style>

</head>

<body>

<div class="sidebar">

    <div class="logo-section">

        <img
        src="../images/logo.png"
        class="sidebar-logo">

        <h2>SafeRoad UiTM</h2>

        <p class="sidebar-role">
            Administrator
        </p>

    </div>

    <a href="dashboard.php">
        Dashboard
    </a>

    <a href="manage_complaints.php"class="active">
        Manage Complaints
    </a>

    <a href="heatmap.php">
        Complaint Heatmap
    </a>

    <a href="reports.php">
        Reports
    </a>

</div>



<div class="topbar">

    <div class="profile-menu">

        <span class="username">
            <?php echo $name; ?>
        </span>

        <img
        src="<?php echo $profileImage; ?>"
        alt="Profile"
        onclick="toggleMenu()">

        <div
        id="dropdownMenu"
        class="dropdown">

            <a href="profile.php">
                My Profile
            </a>

            <a href="../logout.php">
                Logout
            </a>

        </div>

    </div>

</div>





<div class="content">

<div class="dashboard-header">

    <h1>Manage Complaints</h1>

    <p>View, assign, and monitor complaint progress across UiTM Shah Alam.</p>

</div>




<div class="stats">

<div class="card pending">
<h4>Pending</h4>
<h2><?php echo $pendingCount; ?></h2>
</div>

<div class="card awaiting">
<h4>Awaiting Police</h4>
<h2><?php echo $awaitingCount; ?></h2>
</div>

<div class="card progress">
<h4>In Progress</h4>
<h2><?php echo $progressCount; ?></h2>
</div>

<div class="card warning">
<h4>Warning Sent</h4>
<h2><?php echo $warningCount; ?></h2>
</div>

<div class="card resolved">
<h4>Resolved</h4>
<h2><?php echo $resolvedCount; ?></h2>
</div>

</div>





<br>

<div class="search-box">

<input
type="text"

id="searchInput"

placeholder="🔍 Search by reference, issue, status or location">

</div>




<br>

<h3>Complaint List

(<?php echo mysqli_num_rows($complaints); ?>)

</h3>

<br>





<table>

<tr>

<th>Reference No</th>

<th>Category</th>

<th>Subcategory</th>

<th>Risk</th>

<th>Status</th>

<th>Assigned Police</th>

<th>Location</th>

<th>Deadline</th>

<th>Action</th>

</tr>



<?php

while(
$row =
mysqli_fetch_assoc($complaints)
){



$statusClass = "";

switch(
$row['Complaint_status']
){

case "Pending":
$statusClass = "pending";
break;

case "Warning Sent":
$statusClass = "warning";
break;

case "In Progress":
$statusClass = "progress";
break;

case "Resolved":
$statusClass = "resolved";
break;

case "Awaiting Police":
$statusClass = "awaiting";
break;

}

?>




<tr>

<td>
<?php echo $row['ReferenceNumber']; ?>
</td>


<td>
<?php echo $row['CategoryName']; ?>
</td>


<td>
<?php echo $row['Subcategory_name']; ?>
</td>


<td>

<?php

if($row['Subcategory_risk']=="High"){
echo "<span style='color:red;font-weight:bold;'>High</span>";
}

elseif($row['Subcategory_risk']=="Medium"){
echo "<span style='color:orange;font-weight:bold;'>Medium</span>";
}

else{
echo "<span style='color:green;font-weight:bold;'>Low</span>";
}

?>

</td>





<td>

<span
class="status <?php echo $statusClass; ?>">

<?php echo $row['Complaint_status']; ?>

</span>

</td>


<td>

<?php

echo
$row['Police_fullName']
?
$row['Police_fullName']
:
"Not Assigned";

?>

</td>


<td>

<?php echo $row['Complaint_locationName']; ?>

</td>



<td>

<?php

echo date("d M Y h:i A",
strtotime($row['Complaint_deadline'])
);

?>

</td>





<td>

<a
href="view_complaint.php?id=<?php echo $row['ComplaintID']; ?>"
class="btn">

View

</a>

</td>

</tr>

<?php } ?>

</table>




<p

id="noResult"
style="
display:none;
text-align:center;
padding:25px;
color:#777;
">
🔍 No matching complaints found.<br>
Try searching by Reference Number, Category, Status, or Location.

</p>

</div>








<script>

document.getElementById("searchInput")
.addEventListener("keyup",

function(){

var value = this.value.toLowerCase();

var rows = document.querySelectorAll("table tr");

var found = false;

for(
var i=1;
i<rows.length;
i++
){

var text = rows[i].innerText.toLowerCase();

if(
text.includes(value)
){

rows[i].style.display = "";

found = true;

}

else{

rows[i].style.display = "none";

}

}

document.getElementById("noResult").style.display = found
?
"none"
:
"block";

}
);

</script>




<script>

function toggleMenu(){

var menu = document.getElementById("dropdownMenu");

if(menu.style.display=="block"){

menu.style.display="none";

}

else{

menu.style.display="block";

}

}

document.addEventListener("click",

function(event){

var menu = document.getElementById("dropdownMenu");

var profile = document.querySelector(".profile-menu");

if(!profile.contains(event.target)
){

menu.style.display="none";

}

}
);

</script>

</body>

</html>
