
<?php

session_start();


if(!isset($_SESSION['Role'])||$_SESSION['Role']!="Admin"){

    header("Location: ../index.php");

    exit();
}




include("../db.php");


$adminID = $_SESSION['UserID'];

$name = $_SESSION['UserName'];

$adminQuery = mysqli_query(
$conn,
"SELECT Admin_profile
FROM admin
WHERE AdminID='$adminID'"
);

$admin = mysqli_fetch_assoc($adminQuery);



$profileImage = !empty($admin['Admin_profile'])
?
"../uploads/profile/".$admin['Admin_profile']
:
"../images/default-profile.png";





$query = mysqli_query(
$conn,
"SELECT

c.ComplaintID,
c.Complaint_locationLat,
c.Complaint_locationLong,
c.ReferenceNumber,
c.Complaint_locationName,
c.Complaint_status,
cs.Subcategory_risk

FROM complaint c

INNER JOIN subcategory cs
ON c.SubcategoryID = cs.SubcategoryID

WHERE

c.Complaint_locationLat IS NOT NULL

AND

c.Complaint_locationLong IS NOT NULL

AND

Complaint_status IN
(
'Pending',
'Warning Sent',
'In Progress',
'Warning Sent'
)"

);


?>





<!DOCTYPE html>

<html>

<head>

<link rel="icon" type="image/png" href="../images/logo.png">

<title>Heat Map</title>

<link
rel="stylesheet"
href="https://unpkg.com/leaflet/dist/leaflet.css">

<script
src="https://unpkg.com/leaflet/dist/leaflet.js">
</script>

<link
rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/leaflet.awesome-markers/2.0.4/leaflet.awesome-markers.css">

<script
src="https://cdnjs.cloudflare.com/ajax/libs/leaflet.awesome-markers/2.0.4/leaflet.awesome-markers.js">
</script>

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:Arial,sans-serif;
}

body{
background:#f4f6f9;
}

/* Sidebar */

.sidebar{
width:250px;
height:100vh;
background:#5E2D91;
position:fixed;
left:0;
top:0;
box-shadow:2px 0 10px rgba(0,0,0,0.1);
}

.logo-section{
text-align:center;
padding:20px;
border-bottom:1px solid rgba(255,255,255,0.15);
}

.sidebar-logo{
width:80px;
height:80px;
object-fit:contain;
}

.sidebar h2{
color:white;
font-size:20px;
margin-top:10px;
}

.sidebar a{
display:block;
padding:15px 20px;
color:white;
text-decoration:none;
font-size:15px;
transition:0.3s;
}

.sidebar a:hover{
background:#4b2374;
}

.active{
background:#4b2374;
border-left:5px solid white;
}

.content{
margin-left:250px;
padding:30px;
margin-top:20px;
}



.dashboard-header{
background:white;
padding:25px 30px;
border-radius:15px;
margin-bottom:25px;
box-shadow:0 2px 10px rgba(0,0,0,0.08);
border-left:5px solid #5E2D91;
}

.dashboard-header h1{
margin-bottom:8px;
font-size:38px;
}

.dashboard-header p{
color:#666;
margin:0;
}



#map{
height:700px;
width:100%;
border-radius:10px;
box-shadow:0 2px 10px rgba(0,0,0,0.1);
}


.legend{
background:white;
padding:15px;
border-radius:10px;
margin-top:15px;
width:250px;
box-shadow:0 2px 10px rgba(0,0,0,0.1);
}





.topbar{
height:70px;
background:white;
display:flex;
justify-content:flex-end;
align-items:center;
padding:0 30px;
box-shadow:0 2px 10px rgba(0,0,0,0.1);
margin-left:250px;
}

.profile-menu{
display:flex;
align-items:center;
gap:10px;
position:relative;
}

.username{
font-weight:bold;
color:#5E2D91;
}

.profile-menu img{
width:45px;
height:45px;
border-radius:50%;
object-fit:cover;
cursor:pointer;
border:2px solid #5E2D91;
}

.dropdown{
display:none;
position:absolute;
right:0;
top:55px;
background:white;
width:180px;
border-radius:10px;
box-shadow:0 5px 15px rgba(0,0,0,0.15);
overflow:hidden;
z-index:999;
}

.dropdown a{
display:block;
padding:12px 15px;
text-decoration:none;
color:#333;
}

.dropdown a:hover{
background:#f5f5f5;
}


</style>

</head>







<body>

<div class="sidebar">

    <div class="logo-section">

        <img
        src="../images/logo.png"
        class="sidebar-logo">

        <h2>SafeRoad UiTM</h2>

        <p class="sidebar-role">
            Administrator
        </p>

    </div>

    <a href="dashboard.php">
        Dashboard
    </a>

    <a href="manage_complaints.php">
        Manage Complaints
    </a>

    <a href="heatmap.php" class="active">
        Complaint Heatmap
    </a>

    <a href="reports.php">
        Reports
    </a>

</div>



<div class="topbar">

    <div class="profile-menu">

        <span class="username">
            <?php echo $name; ?>
        </span>

        <img
        src="<?php echo $profileImage; ?>"
        alt="Profile"
        onclick="toggleMenu()">

        <div
        id="dropdownMenu"
        class="dropdown">

            <a href="profile.php">
                My Profile
            </a>

            <a href="../logout.php">
                Logout
            </a>

        </div>

    </div>

</div>





<div class="content">

<div class="dashboard-header">

    <h1>Complaint Heatmap</h1>

    <p>Monitor active complaints based on their reported locations.</p>

</div>





<div id="map"></div>


<div class="legend">

🟣 Warning Sent<br>
🔹 Awaiting Police<br>
🟠 Pending<br>
🔵 In Progress<br><br>

Large Circle = High Risk<br>
Medium Circle = Medium Risk<br>
Small Circle = Low Risk

</div>

</div>





<script>

var map =
L.map('map')
.setView(
[3.0733,101.4995],
15
);

L.tileLayer(
'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png'
).addTo(map);

<?php

while(
$row =
mysqli_fetch_assoc($query)
){




$status =
$row['Complaint_status'];

$markerColor =
"blue";

if(
$status=="Pending"
){
    $markerColor = "orange";
}
elseif(
$status=="Warning Sent"
){
    $markerColor = "purple";
}
elseif(
$status=="In Progress"
){
    $markerColor = "blue";
}
elseif(
$status=="Awaiting Police"
){
    $markerColor="cyan";
}




$radius = 10;

if(
$row['Subcategory_risk']=="High"
){
    $radius = 15;
}
elseif(
$row['Subcategory_risk']=="Medium"
){
    $radius = 10;
}
else{
    $radius = 5;
}

?>



L.circleMarker(
[
<?php echo $row['Complaint_locationLat']; ?>,
<?php echo $row['Complaint_locationLong']; ?>
],
{
radius: <?php echo $radius; ?>,
color:'<?php echo $markerColor; ?>',
fillColor:'<?php echo $markerColor; ?>',
fillOpacity:0.4
}
)

.addTo(map)

.bindPopup(

"<b><?php echo addslashes($row['ReferenceNumber']); ?></b><br><br>"+

"📍 <?php echo addslashes($row['Complaint_locationName']); ?><br>"+

"📌 Status: <b><?php echo $row['Complaint_status']; ?></b><br>"+

"⚠ Risk: <b><?php echo $row['Subcategory_risk']; ?></b><br><br>"+

"<a href='view_complaint.php?id=<?php echo $row['ComplaintID']; ?>'>View Complaint →</a>"

);

<?php } ?>

</script>








<script>

function toggleMenu(){

var menu = document.getElementById("dropdownMenu");

if(menu.style.display=="block"){

menu.style.display="none";

}

else{

menu.style.display="block";

}

}

document.addEventListener("click",

function(event){

var menu = document.getElementById("dropdownMenu");

var profile = document.querySelector(".profile-menu");

if(!profile.contains(event.target)
){

menu.style.display="none";

}

}
);

</script>





</body>

</html>