<?php

session_start();




if(!isset($_SESSION['Role']) ||$_SESSION['Role'] != "Admin"){

    header("Location: ../index.php");
    exit();
}



include("../db.php");


$adminID = $_SESSION['AdminID'];

$query = mysqli_query(
$conn,
"SELECT *
FROM admin
WHERE AdminID='$adminID'"
);

$admin = mysqli_fetch_assoc($query);

$name = $admin['Admin_username'];

$profileImage = !empty($admin['Admin_profile'])
?
"../uploads/profile/".$admin['Admin_profile']
:
"../images/default-profile.png";

?>




<!DOCTYPE html>

<html>

<head>

<link rel="icon" type="image/png" href="../images/logo.png">

<title>Admin Profile</title>

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:Arial,sans-serif;
}

body{
background:#f4f6f9;
}

/* Sidebar */

.sidebar{
width:250px;
height:100vh;
background:#5E2D91;
position:fixed;
left:0;
top:0;
box-shadow:2px 0 10px rgba(0,0,0,0.1);
}

.logo-section{
text-align:center;
padding:20px;
border-bottom:1px solid rgba(255,255,255,0.15);
}

.sidebar-logo{
width:80px;
height:80px;
object-fit:contain;
}

.sidebar h2{
color:white;
font-size:20px;
margin-top:10px;
}

.sidebar a{
display:block;
padding:15px 20px;
color:white;
text-decoration:none;
font-size:15px;
transition:0.3s;
}

.sidebar a:hover{
background:#4b2374;
}

.active{
background:#4b2374;
border-left:5px solid white;
}

.content{
margin-left:250px;
padding:30px;
margin-top:20px;
}


/* Topbar */

.topbar{
height:70px;
background:white;
display:flex;
justify-content:flex-end;
align-items:center;
padding:0 30px;
box-shadow:0 2px 10px rgba(0,0,0,0.1);
margin-left:250px;
}

.profile-menu{
display:flex;
align-items:center;
gap:10px;
position:relative;
}

.username{
font-weight:bold;
color:#5E2D91;
}

.profile-menu img{
width:45px;
height:45px;
border-radius:50%;
object-fit:cover;
cursor:pointer;
border:2px solid #5E2D91;
}

.dropdown{
display:none;
position:absolute;
right:0;
top:55px;
background:white;
width:180px;
border-radius:10px;
box-shadow:0 5px 15px rgba(0,0,0,0.15);
overflow:hidden;
z-index:999;
}

.dropdown a{
display:block;
padding:12px 15px;
text-decoration:none;
color:#333;
}

.dropdown a:hover{
background:#f5f5f5;
}


/* Header */

.dashboard-header{
background:white;
padding:25px 30px;
border-radius:15px;
margin-bottom:25px;
box-shadow:0 2px 10px rgba(0,0,0,0.08);
border-left:5px solid #5E2D91;
}

.dashboard-header h1{
margin-bottom:8px;
font-size:38px;
}

.dashboard-header p{
color:#666;
margin:0;
}


.card{
background:white;
padding:20px;
border-radius:10px;
margin-bottom:20px;
box-shadow:0 2px 10px rgba(0,0,0,0.1);
}

.card h3{
margin-bottom:15px;
color:#5E2D91;
}



table{
width:100%;
}

td{
padding:12px;
border-bottom:1px solid #ddd;
}

td:first-child{
font-weight:bold;
width:200px;
}

input{
width:100%;
padding:10px;
border:1px solid #ccc;
border-radius:5px;
margin-bottom:10px;
}


.btn{
background:#5E2D91;
color:white;
border:none;
padding:10px 20px;
border-radius:5px;
cursor:pointer;
}

.btn:hover{
background:#4b2374;
}

</style>

</head>






<body>

<div class="sidebar">

    <div class="logo-section">

        <img
        src="../images/logo.png"
        class="sidebar-logo">

        <h2>SafeRoad UiTM</h2>

        <p class="sidebar-role">
            Administrator
        </p>

    </div>

    <a href="dashboard.php">
        Dashboard
    </a>

    <a href="manage_complaints.php">
        Manage Complaints
    </a>

    <a href="heatmap.php">
        Complaint Heatmap
    </a>

    <a href="reports.php">
        Reports
    </a>

</div>



<div class="topbar">

    <div class="profile-menu">

        <span class="username">
            <?php echo $name; ?>
        </span>

        <img
        src="<?php echo $profileImage; ?>"
        alt="Profile"
        onclick="toggleMenu()">

        <div
        id="dropdownMenu"
        class="dropdown">

            <a href="profile.php">
                My Profile
            </a>

            <a href="../logout.php">
                Logout
            </a>

        </div>

    </div>

</div>





<div class="content">

<div class="dashboard-header">

   <h1>Administrator Profile</h1>

    <p>
        View your account information and manage your account password.
    </p>

</div>






<div class="card" style="text-align:center;">

<img
src="<?php echo $profileImage; ?>"
style="
width:130px;
height:130px;
border-radius:50%;
object-fit:cover;
border:4px solid #5E2D91;
box-shadow:0 5px 15px rgba(0,0,0,0.15);
">

<h3 style="margin-top:15px;color:#5E2D91;">

<?php echo htmlspecialchars($admin['Admin_username']); ?>

</h3>

<p style="color:#777;">

Administrator

</p>

</div>

<br>






<div class="card">

<h3>🔒 Security Settings</h3>

<p style="color:#777;margin-bottom:20px;">

Update your password to keep your administrator account secure.

</p>

<form
action="change_password.php"
method="POST">

<input
type="password"
name="current_password"
placeholder="Current Password"
required>

<input
type="password"
name="new_password"
placeholder="New Password"
required>

<input
type="password"
name="confirm_password"
placeholder="Confirm New Password"
required>

<button
type="submit"
class="btn">

Save New Password

</button>

</form>

</div>

</div>





<script>

function toggleMenu(){

var menu = document.getElementById("dropdownMenu");

if(menu.style.display=="block"){

menu.style.display="none";

}

else{

menu.style.display="block";

}

}

document.addEventListener("click",

function(event){

var menu = document.getElementById("dropdownMenu");

var profile = document.querySelector(".profile-menu");

if(!profile.contains(event.target)
){

menu.style.display="none";

}

}
);

</script>

</body>

</html>