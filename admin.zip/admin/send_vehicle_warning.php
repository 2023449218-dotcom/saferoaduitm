<?php

session_start();



date_default_timezone_set('Asia/Kuala_Lumpur');




if(!isset($_SESSION['Role']) || $_SESSION['Role'] != "Admin"){
    
    header("Location: ../index.php");
    exit();
}





include("../db.php");

include("../includes/send_email.php");

include("../includes/send_telegram.php");



if(!isset($_POST['ComplaintID'])||!isset($_POST['VehiclePlate'])){
    header("Location: manage_complaints.php");

    exit();
}

$complaintID = $_POST['ComplaintID'];

$vehiclePlate = $_POST['VehiclePlate'];




//Get complaint Information
$complaintQuery = mysqli_query(
$conn,
"SELECT
c.*,
cc.CategoryName,
cs.Subcategory_name,
cs.AllowWarning
FROM Complaint c
INNER JOIN Category cc
ON c.CategoryID = cc.CategoryID
INNER JOIN subcategory cs
ON c.SubcategoryID = cs.SubcategoryID
WHERE c.ComplaintID='$complaintID'"
);

$complaint = mysqli_fetch_assoc($complaintQuery);



if(!$complaint){

    die("Complaint not found.");
}


if($complaint['AllowWarning'] != 1){

    die("Warning notice is not allowed for this complaint.");

}


//Find vehicle owner
$vehicleQuery = mysqli_query($conn,
"SELECT *
FROM vehicle
WHERE Vehicle_plateNum ='$vehiclePlate'
LIMIT 1"
);

$vehicle = mysqli_fetch_assoc($vehicleQuery);

if(!$vehicle){

    die("Vehicle owner not found.");
}




//If owner student
if(!empty($vehicle['StudentID'])){

$userQuery = mysqli_query(
$conn,
"SELECT *
FROM student
WHERE StudentID='".
$vehicle['StudentID']."'"
);

$user = mysqli_fetch_assoc($userQuery);

$name = $user['Student_fullName'];

$email = $user['Student_email'];

}





//If owner staff

else{

$userQuery = mysqli_query($conn,
"SELECT *
FROM staff
WHERE StaffID='".
$vehicle['StaffID']."'"
);

$user = mysqli_fetch_assoc($userQuery);

$name = $user['Staff_fullName'];

$email = $user['Staff_email'];

}




//Warning Message
$message = "

<h2 style='color:#d63031;'>
⚠ Vehicle Warning Notice
</h2>

<p>
Dear <b>".$name."</b>,
</p>

<p>
This email is to inform you that a traffic-related complaint has been received regarding your registered vehicle within the UiTM Shah Alam campus.
</p>

<hr>

<table cellpadding='8' style='border-collapse:collapse;'>

<tr>
<td><b>Vehicle Plate Number</b></td>
<td>".$vehiclePlate."</td>
</tr>

<tr>
<td><b>Complaint Reference Number</b></td>
<td>".$complaint['ReferenceNumber']."</td>
</tr>

<tr>
<td><b>Date Issued</b></td>
<td>".date("d M Y h:i A")."</td>
</tr>

</table>

<hr>

<p>
You are advised to check your vehicle immediately and move it if it is causing an obstruction or violating campus traffic regulations.
</p>

<p>
Failure to take appropriate action may result in further administrative action by the UiTM Auxiliary Police.
</p>

<p>
If you believe this notice was sent in error or the issue has already been resolved, please contact the UiTM Auxiliary Police for assistance.
</p>

<br>

<p>
Thank you for your cooperation in maintaining a safe and orderly campus environment.
</p>

<br>

<p>
Kind regards,<br>
<b>SafeRoad UiTM System</b><br>
UiTM Auxiliary Police<br>
Universiti Teknologi MARA Shah Alam
</p>

";





//Send Notification
if($user['notification_preference'] == "Email"){

sendEmail(
$email,
$name,
"SafeRoad UiTM - Vehicle Warning Notice",
$message
);

}

else{if(!empty($user['telegram_chatID'])){

sendTelegram(
$user['telegram_chatID'],
$message
);

}

}


if($complaint['Complaint_status'] != "Warning Sent"){

    mysqli_query(
        $conn,
        "UPDATE complaint
        SET
        Complaint_status='Warning Sent',
        WaitingFeedback = 1
        WHERE ComplaintID='$complaintID'"
    );

}



$complainantEmail = "";
$complainantName = "";
$complainantTelegram = "";
$complainantPreference = "";


if(!empty($complaint['StudentID'])
){

$cQuery = mysqli_query($conn,
"SELECT *
FROM student
WHERE StudentID='".
$complaint['StudentID']."'"
);

$cUser =
mysqli_fetch_assoc($cQuery);

$complainantName = $cUser['Student_fullName'];

$complainantEmail = $cUser['Student_email'];

$complainantTelegram = $cUser['telegram_chatID'];

$complainantPreference = $cUser['notification_preference'];

}






else{

$cQuery = mysqli_query($conn,
"SELECT *
FROM staff
WHERE StaffID='".
$complaint['StaffID']."'"
);

$cUser = mysqli_fetch_assoc($cQuery);

$complainantName = $cUser['Staff_fullName'];

$complainantEmail = $cUser['Staff_email'];

$complainantTelegram = $cUser['telegram_chatID'];

$complainantPreference = $cUser['notification_preference'];

}





$complainantMessage =
"📢 Vehicle Warning Notice

Dear ".$complainantName.",

A warning notice has been sent to the owner of the reported vehicle regarding your complaint.

📋 Reference Number: ".$complaint['ReferenceNumber']."
🚗 Vehicle Plate: ".$vehiclePlate."
⚠️ Status: Warning Notice Sent
📅 Date: ".date("d M Y h:i A")."

The vehicle owner has been notified and advised to move the vehicle if necessary.

If the issue has been resolved, you can update warning feedback of your complaint through SafeRoad UiTM. Otherwise, the complaint will continue to be handled by the Auxiliary Police.

Thank you.

SafeRoad UiTM System";




if($complainantPreference=="Email"){

sendEmail(

$complainantEmail,

$complainantName,

"SafeRoad UiTM - Vehicle Warning Notice Issued",

nl2br($complainantMessage)

);

}

else{

if(!empty($complainantTelegram)){

sendTelegram(

$complainantTelegram,

strip_tags($complainantMessage)

);

}

}






//Add Timeline Record
$adminID = $_SESSION['AdminID'];

mysqli_query($conn,

"INSERT INTO Complaint_timeline
(
ComplaintID,
AdminID,
TimelineDesc,
TimelineDate
)

VALUES
(
'$complaintID',
'$adminID',
'Warning notice sent to the reported vehicle owner. The system is now waiting for feedback from the complainant.',
NOW()
)

"

);




//Success Message
$_SESSION['success_message'] =
"Warning notice sent successfully.";



//Redirect Back
header("Location: view_complaint.php?id=".$complaintID);

exit();