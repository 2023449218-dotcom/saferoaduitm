<?php



session_start();


date_default_timezone_set('Asia/Kuala_Lumpur');



if(!isset($_SESSION['Role']) || $_SESSION['Role'] != "Admin"){

    header("Location: ../index.php");

    exit();
}



include("../db.php");


/*=====================================================
    Validate Complaint ID

    Ensure a complaint ID is provided before
    displaying complaint details.
=====================================================*/
if(!isset($_GET['id'])){

    header("Location: manage_complaints.php");

    exit();
}


$adminID = $_SESSION['UserID'];

$name = $_SESSION['UserName'];


/* Retrieve administrator profile information */
$adminQuery = mysqli_query(
$conn,
"SELECT Admin_profile
FROM admin
WHERE AdminID='$adminID'"
);

$admin = mysqli_fetch_assoc($adminQuery);


$profileImage = !empty($admin['Admin_profile'])
?
"../uploads/profile/".$admin['Admin_profile']
:
"../images/default-profile.png";



$complaintID =mysqli_real_escape_string($conn,
$_GET['id']
);


/*=====================================================
    Retrieve Complaint Information

    Retrieve complaint details together with
    category and subcategory information.
=====================================================*/
$query = mysqli_query($conn,
"SELECT
c.*,
cc.CategoryName,
cs.Subcategory_name,
cs.AllowWarning,
cs.Subcategory_risk
FROM complaint c
INNER JOIN category cc
ON c.CategoryID = cc.CategoryID
INNER JOIN subcategory cs
ON c.SubcategoryID = cs.SubcategoryID
WHERE c.ComplaintID='$complaintID'"
);




$complaint = mysqli_fetch_assoc($query);

if(!$complaint){

    die("Complaint not found.");
}



$complainant = [];
$type = "";

/*=====================================================
    Retrieve Complainant Information

    Determine whether the complainant is
    a student or staff member and retrieve
    the corresponding profile information.
=====================================================*/
if(!empty($complaint['StudentID'])){

$type = "Student";

$studentQuery = mysqli_query(
$conn,
"SELECT *
FROM student
WHERE StudentID='
".$complaint['StudentID']."'"
);

$complainant = mysqli_fetch_assoc(
$studentQuery
);

}

else{

$type = "Staff";


$staffQuery = mysqli_query(
$conn,
"SELECT *
FROM staff
WHERE StaffID='
".$complaint['StaffID']."'"
);

$complainant = mysqli_fetch_assoc(
$staffQuery
);

}




/* Retrieve reported vehicle information */
$vehicleQuery = mysqli_query($conn,
"SELECT *
FROM complaintvehicle
WHERE ComplaintID='$complaintID'"
);

$vehicle = mysqli_fetch_assoc($vehicleQuery);




/* Retrieve complaint evidence uploaded by the complainant */
$userEvidenceQuery = mysqli_query(
$conn,
"SELECT *
FROM evidence
WHERE ComplaintID='$complaintID'
AND Evidence_type='Complaint'"
);


/* Retrieve resolution evidence uploaded by the Auxiliary Police */
$resolutionEvidenceQuery = mysqli_query(
$conn,
"SELECT *
FROM evidence
WHERE ComplaintID='$complaintID'
AND Evidence_type='Resolution'"
);




/* Retrieve complaint activity timeline */
$timelineQuery = mysqli_query(
$conn,
"SELECT *
FROM complaint_timeline
WHERE ComplaintID='$complaintID'
ORDER BY TimelineDate ASC"
);




$statusClass = "";

/* Determine badge colour based on complaint status */
switch($complaint['Complaint_status']){

case "Pending":
$statusClass = "pending";
break;

case "In Progress":
$statusClass = "progress";
break;

case "Resolved":
$statusClass = "resolved";
break;

case "Warning Sent":
$statusClass = "warning";
break;

case "Awaiting Police":
$statusClass = "awaiting";
break;

}

?>








<!DOCTYPE html>

<html>

<head>

<link rel="icon" type="image/png" href="../images/logo.png">

<title>Complaint Details</title>

<link
rel="stylesheet"
href="https://unpkg.com/leaflet/dist/leaflet.css">

<script
src="https://unpkg.com/leaflet/dist/leaflet.js">
</script>

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:Arial,sans-serif;
}

body{
background:#f4f6f9;
}

/* Sidebar */

.sidebar{
width:250px;
height:100vh;
background:#5E2D91;
position:fixed;
left:0;
top:0;
box-shadow:2px 0 10px rgba(0,0,0,0.1);
}

.logo-section{
text-align:center;
padding:20px;
border-bottom:1px solid rgba(255,255,255,0.15);
}

.sidebar-logo{
width:80px;
height:80px;
object-fit:contain;
}

.sidebar h2{
color:white;
font-size:20px;
margin-top:10px;
}

.sidebar a{
display:block;
padding:15px 20px;
color:white;
text-decoration:none;
font-size:15px;
transition:0.3s;
}

.sidebar a:hover{
background:#4b2374;
}

.active{
background:#4b2374;
border-left:5px solid white;
}

.content{
margin-left:250px;
padding:30px;
margin-top:20px;
}


.topbar{
height:70px;
background:white;
display:flex;
justify-content:flex-end;
align-items:center;
padding:0 30px;
box-shadow:0 2px 10px rgba(0,0,0,0.1);
margin-left:250px;
}

.profile-menu{
display:flex;
align-items:center;
gap:10px;
position:relative;
}

.username{
font-weight:bold;
color:#5E2D91;
}

.profile-menu img{
width:45px;
height:45px;
border-radius:50%;
object-fit:cover;
cursor:pointer;
border:2px solid #5E2D91;
}

.dropdown{
display:none;
position:absolute;
right:0;
top:55px;
background:white;
width:180px;
border-radius:10px;
box-shadow:0 5px 15px rgba(0,0,0,0.15);
overflow:hidden;
z-index:999;
}

.dropdown a{
display:block;
padding:12px 15px;
text-decoration:none;
color:#333;
}

.dropdown a:hover{
background:#f5f5f5;
}

.dashboard-header{
background:white;
padding:25px 30px;
border-radius:15px;
margin-bottom:25px;
box-shadow:0 2px 10px rgba(0,0,0,0.08);
border-left:5px solid #5E2D91;
}

.dashboard-header h1{
margin-bottom:8px;
font-size:38px;
}

.dashboard-header p{
color:#666;
margin:0;
}


.card{
background:white;
padding:25px;
border-radius:10px;
margin-bottom:20px;
box-shadow:0 2px 8px rgba(0,0,0,0.1);
}



h2{
color:#5E2D91;
}

table{
width:100%;
border-collapse:collapse;
}

td{
padding:12px;
border-bottom:1px solid #ddd;
}

td:first-child{
font-weight:bold;
width:250px;
}




#map{
height:400px;
border-radius:10px;
}

.badge{
padding:8px 15px;
border-radius:20px;
color:white;
font-weight:bold;
}




.pending{
background:#f39c12;
}

.progress{
background:#1f4e79;
}

.resolved{
background:#27ae60;
}

.warning{
background:#9b59b6;
}

.awaiting{
background:#17a2b8;
}



.btn{
background:#5E2D91;
color:white;
padding:10px 20px;
border:none;
border-radius:5px;
cursor:pointer;
}

.btn:hover{
background:#4b2374;
}


.risk-high{
background:#ffe5e5;
color:#d63031;
padding:6px 12px;
border-radius:20px;
font-weight:bold;
display:inline-block;
}

.risk-medium{
background:#fff4d6;
color:#e67e22;
padding:6px 12px;
border-radius:20px;
font-weight:bold;
display:inline-block;
}

.risk-low{
background:#e8f8e8;
color:#27ae60;
padding:6px 12px;
border-radius:20px;
font-weight:bold;
display:inline-block;
}



.timeline{
position:relative;
margin-top:20px;
}

.timeline-item{
position:relative;
padding-left:50px;
margin-bottom:25px;
}

.timeline-item::before{
content:"";
position:absolute;
left:14px;
top:35px;
width:3px;
height:100%;
background:#d8d8d8;
}

.timeline-item:last-child::before{
display:none;
}

.timeline-icon{
width:30px;
height:30px;
border-radius:50%;
background:#5E2D91;
color:white;
display:flex;
align-items:center;
justify-content:center;
font-size:14px;
font-weight:bold;
position:absolute;
left:0;
top:0;
}

.timeline-content{
background:#fafafa;
padding:15px;
border-radius:10px;
box-shadow:0 2px 6px rgba(0,0,0,0.08);
}

.timeline-content b{
display:block;
margin-bottom:8px;
}

.timeline-content small{
color:#666;
}


.evidence{
width:220px;
height:220px;
object-fit:cover;
border-radius:10px;
margin:10px;
transition:0.3s;
}

.evidence:hover{
transform:scale(1.05);
}

.evidence-grid{
display:grid;
grid-template-columns:1fr 1fr;
gap:20px;
margin-top:20px;

}

.evidence-grid .card{
margin-bottom:0;
}


.upload-box{
display:flex;
flex-direction:column;
justify-content:center;
align-items:center;
width:100%;
min-height:180px;
border:2px dashed #5E2D91;
border-radius:10px;
background:#faf7ff;
cursor:pointer;
transition:0.3s;
box-sizing:border-box;
}

.upload-box:hover{
    background:#f3ebff;
}

.upload-box p{
margin:0;
color:#5E2D91;
font-weight:bold;
}

.upload-box small{
color:#777;
}

#resolutionPreview{
display:none;
width:220px;
height:220px;
object-fit:cover;
border-radius:10px;
border:2px solid #ddd;
margin:0 auto;
}

input[type=file]{
display:none;
}

</style>

</head>

<body>

<div class="sidebar">

    <div class="logo-section">

        <img
        src="../images/logo.png"
        class="sidebar-logo">

        <h2>SafeRoad UiTM</h2>

        <p class="sidebar-role">
        Administrator
        </p>

    </div>

        <a href="dashboard.php">
        Dashboard
        </a>

        <a href="manage_complaints.php" class="active">
        Manage Complaints
        </a>

        <a href="heatmap.php">
        Complaint Heatmap
        </a>

        <a href="reports.php">
        Reports
        </a>

</div>



<div class="topbar">

    <div class="profile-menu">

        <span class="username">
        <?php echo $name; ?>
        </span>

        <img
        src="<?php echo $profileImage; ?>"
        alt="Profile"
        onclick="toggleMenu()">

        <div
        id="dropdownMenu"
        class="dropdown">

        <a href="profile.php">
        My Profile
        </a>

        <a href="../logout.php">
        Logout
        </a>

        </div>

    </div>

</div>





<div class="content">

<div class="dashboard-header">


    <h1>Complaint Details</h1>

    <p>Review complaint information, evidence, location, assigned officer and complaint progress.</p>

</div>



<a
href="manage_complaints.php"
style="
display:inline-block;
margin-bottom:15px;
background:#5E2D91;
color:white;
padding:10px 15px;
text-decoration:none;
border-radius:5px;">

← Back to Manage Complaints

</a>



<!-- =====================================================
     Complainant Information
===================================================== -->
<div class="card">

    <h2>Complainant Information</h2>

    <br>

    <table>

    <?php if($type=="Student"){ ?>

    <tr>
    <td>Name</td>
    <td><?php echo $complainant['Student_fullName']; ?></td>
    </tr>

    <tr>
    <td>Role</td>
    <td><?php echo $type; ?></td>
    </tr>

    <tr>
    <td>Matric Number</td>
    <td><?php echo $complainant['Student_matricNum']; ?></td>
    </tr>

    <tr>
    <td>Email</td>
    <td><?php echo $complainant['Student_email']; ?></td>
    </tr>

    <tr>
    <td>Phone Number</td>
    <td><?php echo $complainant['Student_phoneNumber']; ?></td>
    </tr>

    <?php } 

    else { ?>

    <tr>
    <td>Name</td>
    <td><?php echo $complainant['Staff_fullName']; ?></td>
    </tr>

    <tr>
    <td>Staff Number</td>
    <td><?php echo $complainant['Staff_Num']; ?></td>
    </tr>

    <tr>
    <td>Email</td>
    <td><?php echo $complainant['Staff_email']; ?></td>
    </tr>

    <tr>
    <td>Phone Number</td>
    <td><?php echo $complainant['Staff_phoneNumber']; ?></td>
    </tr>

    <?php } ?>

    </table>

</div>





<!-- =====================================================
     Complaint Information
===================================================== -->
<div class="card">
    
    <h2>Complaint Information</h2>

    <br>

    <?php
    if($complaint['Complaint_status']=="Resolved"){
    ?>

    <p
    style="
    padding:15px;
    background:#d4edda;
    color:#155724;
    border-radius:5px;
    margin-bottom:15px;">

    ✅ This complaint has been resolved.
    </p>

    <?php } ?>



    <table>

    <tr>
    <td>Reference Number</td>
    <td><?php echo $complaint['ReferenceNumber']; ?></td>
    </tr>

    <tr>
    <td>Category</td>
    <td><?php echo $complaint['CategoryName']; ?></td>
    </tr>

    <tr>
    <td>Subcategory</td>
    <td><?php echo $complaint['Subcategory_name']; ?></td>
    </tr>

    <tr>
    <td>Description</td>
    <td>

    <?php echo nl2br($complaint['Complaint_desc']); ?>

    </td>
    </tr>



    <tr>
    <td>Risk Level</td>
    <td>

    <?php
    $riskClass = "";

    if($complaint['Subcategory_risk']=="High"){
        $riskClass = "risk-high";
    }

    elseif($complaint['Subcategory_risk']=="Medium"){
        $riskClass = "risk-medium";
    }

    else{
        $riskClass = "risk-low";
    }
    ?>

    <span class="<?php echo $riskClass; ?>">
    <?php echo $complaint['Subcategory_risk']; ?>
    </span>
    </td>
    </tr>


    <tr>
    <td>Status</td>
    <td>

    <span class="badge <?php echo $statusClass; ?>">
    <?php echo $complaint['Complaint_status']; ?>
    </span>

    </td>
    </tr>


    <tr>
    <td>Assigned Police</td>
    <td>

    <?php
    if(empty($complaint['PoliceID'])){

        echo "Not Assigned";

    }

    else{

    $policeQuery = mysqli_query($conn,
    "SELECT *
    FROM auxiliary_police
    WHERE PoliceID='".
    $complaint['PoliceID']."'"
    );

    $police = mysqli_fetch_assoc($policeQuery);

    echo $police['Police_fullName'];

    }
    ?>

    </td>
    </tr>


    <tr>
    <td>Created Date</td>
    <td>

    <?php
    echo date("d M Y h:i A",
    strtotime($complaint['Complaint_createdAt']));
    ?>

    </td>
    </tr>




    <tr>
    <td>Deadline</td>
    <td>

    <?php
    echo date("d M Y h:i A",
    strtotime($complaint['Complaint_deadline']));

    $deadline = strtotime($complaint['Complaint_deadline']);

    if($deadline < time()
    &&
    $complaint['Complaint_status']!="Resolved"
    &&
    $complaint['Complaint_status']!="Cancelled"){

    $daysLate = floor((time() - $deadline)/86400);

    echo
    "<br><span style='color:#dc3545;font-weight:bold;'>
    ⚠ Overdue by ".$daysLate." day(s)
    </span>";

    }

    elseif($complaint['Complaint_status']!="Resolved"
    &&
    $complaint['Complaint_status']!="Cancelled"
    ){

    echo
    "<br><span style='color:#28a745;font-weight:bold;'>
    ✓ Within Deadline
    </span>";

    }
    ?>

    </td>
    </tr>



    <?php
    if(!empty($complaint['Complaint_resolvedAt'])){
    ?>

    <tr>
    <td>Resolved Date</td>
    <td>

    <?php
    echo date("d M Y h:i A",
    strtotime($complaint['Complaint_resolvedAt']));
    ?>

    </td>
    </tr>


    <?php } ?>

    </table>




<hr style="margin:25px 0;">


<!-- =====================================================
     Quick Actions

     Allow administrator to:
     - Assign police
     - Update complaint status
===================================================== -->
<h3 style="color:#5E2D91;">Quick Actions</h3>

<?php
if($complaint['Complaint_status']!="Resolved"){
?>

<div style="margin-top:20px;">





<label><b>Assign Auxiliary Police</b></label>

<br><br>

<?php
/* Check whether an Auxiliary Police has already been assigned */
if(empty($complaint['PoliceID'])){
?>

<form
action="assign_police.php"
method="POST">

    <input
    type="hidden"
    name="ComplaintID"
    value="<?php echo $complaintID; ?>">

        <select
        name="PoliceID"
        required>

        <option value="">
        Select Auxiliary Police
        </option>


        <?php
        $policeList = mysqli_query($conn,
        "SELECT *
        FROM auxiliary_police
        ORDER BY Police_fullName"
        );

        while($police = mysqli_fetch_assoc($policeList)){
        ?>



        <option
        value="<?php echo $police['PoliceID']; ?>">

        <?php echo $police['Police_fullName']; ?>
        </option>


        <?php } ?>
        </select>

    <br><br>


    <button
    type="submit"
    class="btn">

    Assign Police

    </button>

</form>

<?php

}


else{

?>

<p style="
padding:12px;
background:#e8f5e9;
border-left:5px solid #27ae60;
border-radius:5px;
">

✅ Assigned to

<b>
<?php echo $police['Police_fullName']; ?>
</b>
</p>

<?php } ?>

</div>

<?php } ?>


<?php

/* Display additional fields when resolving a complaint */
if($complaint['Complaint_status']!="Resolved"
&&
!empty($complaint['PoliceID'])){

?>

<div style="margin-top:25px;">

<label>

<b>Update Complaint Status</b>

</label>

<br><br>

<form
action="update_status.php"
method="POST"
enctype="multipart/form-data">

<input
type="hidden"
name="ComplaintID"
value="<?php echo $complaintID; ?>">

<select
name="Complaint_status"
required>

<option value="">
Select Status
</option>

<?php

if($complaint['Complaint_status']=="Pending"){
?>

<option value="In Progress">In Progress</option>

<?php
}

elseif($complaint['Complaint_status']=="In Progress"){
?>

<option value="Resolved">Resolved</option>

<?php } ?>

</select>

<br><br>





<div id="resolutionSection" style="display:none;">

<label><b>Resolution Remarks</b></label>

<br><br>

<textarea

name="Subcategory_resolutionRemark"

rows="4"

style="
width:100%;
padding:10px;
border:1px solid #ccc;
border-radius:8px;
resize:none;
"

placeholder="Describe the action taken by the auxiliary police..."></textarea>

</div>

<br>






<div id="resolutionImage" style="display:none;">


<label><b>Resolution Evidence</b></label>

<br><br>

<label for="resolutionFile" class="upload-box">

    <div style="font-size:55px;">📷</div>

    <p>Click to Upload Resolution Photo</p>

    <small>PNG, JPG or JPEG</small>


<input
type="file"
id="resolutionFile"
name="ResolutionImage"
accept="image/*">

<div style="text-align:center; margin-top:15px;">

    <img
    id="resolutionPreview"
    src=""
    alt="Preview">

    <p
    id="selectedFileName"
    style="
    margin-top:10px;
    font-weight:bold;
    color:#5E2D91;
    ">
        No file selected
    </p>

</div>

<p style="color:#777;font-size:13px; margin-top:10px;">
Upload a photo showing that the complaint has been resolved.
</p>

<br>

</div>

</label>


<br>

<button
type="submit"
class="btn">

Update Status

</button>

</form>

</div>

<?php } ?>

</div>





<!-- =====================================================
     Complaint Location
===================================================== -->
<div class="card">

    <h2>Location</h2>

    <br>

    <table>

    <tr>
    <td>Location Name</td>
    <td><?php echo $complaint['Complaint_locationName']; ?></td>
    </tr>

    <tr>
    <td>Specific Location Description</td>
    <td><?php echo $complaint['Complaint_locationDesc']; ?></td>
    </tr>

    </table>

    <br>

    <div id="map"></div>

</div>





<?php if($vehicle){ ?>

<!-- =====================================================
     Reported Vehicle Information
===================================================== -->
<div class="card">

<h2>Vehicle Information</h2>

<br>

<?php if($vehicle){ ?>

<table>

<tr>
<td>Plate Number</td>
<td><?php echo $vehicle['Reported_plateNum']; ?></td>
</tr>

<tr>
<td>Vehicle Type</td>
<td><?php echo $vehicle['Reported_type']; ?></td>
</tr>

<tr>
<td>Vehicle Color</td>
<td><?php echo !empty($vehicle['Reported_color']) ? $vehicle['Reported_color'] : "-"; ?></td>
</tr>

<tr>
<td>Vehicle Model</td>
<td><?php echo !empty($vehicle['Reported_model']) ? $vehicle['Reported_model'] : "-"; ?></td>
</tr>

</table>

<?php } ?>

</div>

<?php

if(!empty($vehicle['Reported_plateNum'])){

$plate = $vehicle['Reported_plateNum'];

$ownerQuery = mysqli_query($conn,
"SELECT *
FROM vehicle
WHERE Vehicle_plateNum ='$plate'
LIMIT 1"
);

$ownerVehicle = mysqli_fetch_assoc($ownerQuery);

if($ownerVehicle){

?>






<div class="card">

<h2>Vehicle Owner Lookup</h2>

<?php

$ownerFound = false;


/* =========================================
   STUDENT VEHICLE OWNER
========================================= */

if(!empty($ownerVehicle['StudentID'])){

    $ownerQuery = mysqli_query(
        $conn,
        "SELECT *
        FROM student
        WHERE StudentID='".$ownerVehicle['StudentID']."'"
    );

    $owner = mysqli_fetch_assoc($ownerQuery);

    if($owner){

        $ownerFound = true;

?>

<table>

<tr>
<td>Name</td>
<td><?php echo htmlspecialchars($owner['Student_fullName']); ?></td>
</tr>

<tr>
<td>Email</td>
<td><?php echo htmlspecialchars($owner['Student_email']); ?></td>
</tr>

<tr>
<td>Phone Number</td>
<td><?php echo htmlspecialchars($owner['Student_phoneNumber']); ?></td>
</tr>

</table>

<?php

    }

}


/* =========================================
   STAFF VEHICLE OWNER
========================================= */

elseif(!empty($ownerVehicle['StaffID'])){

    $ownerQuery = mysqli_query(
        $conn,
        "SELECT *
        FROM staff
        WHERE StaffID='".$ownerVehicle['StaffID']."'"
    );

    $owner = mysqli_fetch_assoc($ownerQuery);

    if($owner){

        $ownerFound = true;

?>

<table>

<tr>
<td>Name</td>
<td><?php echo htmlspecialchars($owner['Staff_fullName']); ?></td>
</tr>

<tr>
<td>Email</td>
<td><?php echo htmlspecialchars($owner['Staff_email']); ?></td>
</tr>

<tr>
<td>Phone Number</td>
<td><?php echo htmlspecialchars($owner['Staff_phoneNumber']); ?></td>
</tr>

</table>

<?php

    }

}


/* =========================================
   OWNER NOT FOUND
========================================= */

if(!$ownerFound){

?>

<p style="color:red;">
Vehicle owner not found in database.
</p>

<?php

}


/* =========================================
   WARNING NOTICE

   Only available when:
   1. Vehicle owner is found
   2. Warning is allowed for this complaint
========================================= */

if($ownerFound && $complaint['AllowWarning'] == 1){

?>

<form
action="send_vehicle_warning.php"
method="POST">

<input
type="hidden"
name="ComplaintID"
value="<?php echo $complaintID; ?>">

<input
type="hidden"
name="VehiclePlate"
value="<?php echo htmlspecialchars($plate); ?>">

<br>

<?php

if($complaint['Complaint_status'] == "Pending"){

?>

<button
type="submit"
class="btn"
onclick="return confirm('Send warning notice to vehicle owner?')">

⚠ Send Warning Notice

</button>

<?php

}else{

?>

<button
type="button"
class="btn"
disabled
style="
background:#bdbdbd;
cursor:not-allowed;
opacity:0.7;">

✓ Warning Already Sent

</button>

<p style="
margin-top:10px;
color:#666;
font-size:14px;">

A warning notice has already been sent to the vehicle owner.
Waiting for the complainant's feedback.

</p>

<?php

}

?>

</form>

<?php

}

?>

</div>



<?php
} // Close if($ownerVehicle)

} // Close if(!empty($vehicle['Reported_plateNum']))

} // Close if($vehicle)
?>



<div class="evidence-grid">

    
<!-- Evidence -->
<div class="card">

<h2>Complaint Evidence</h2>

<?php

if(mysqli_num_rows($userEvidenceQuery)==0){

    echo "<p>No complaint evidence uploaded.</p>";

}


else{

    while($file=mysqli_fetch_assoc($userEvidenceQuery)){

        $extension = strtolower(pathinfo(
        $file['Evidence_fileName'],PATHINFO_EXTENSION));

        if(in_array($extension,['jpg','jpeg','png'])){

?>

<img
src="../uploads/evidence/<?php 
echo $file['Evidence_fileName']; ?>"
class="evidence"
onclick="window.open(this.src)"
style="cursor:pointer;">

<?php

}

else{

?>

<p>

🎥

<a
href="../uploads/evidence/<?php 
echo $file['Evidence_fileName']; ?>"
target="_blank">

<?php echo $file['Evidence_fileName']; ?>

</a>

</p>

<?php

        }

    }

}

?>

</div>






<div class="card">

    <h2>Resolution Evidence</h2>

    <?php

    if(mysqli_num_rows($resolutionEvidenceQuery)==0){

    ?>

    <p style="color:#777;">

    No resolution evidence uploaded yet.

    </p>

    <?php

    }

    else{

    while($file=mysqli_fetch_assoc($resolutionEvidenceQuery)){

    ?>

    <p><b>Resolution Remarks</b></p>

    <p>
    <?php
    echo nl2br($file['Evidence_resolutionRemark']);
    ?>
    </p>

    <br>

    <img
    src="../uploads/evidence/<?php echo $file['Evidence_fileName']; ?>"
    class="evidence"
    onclick="window.open(this.src)"
    style="cursor:pointer;">

    <?php

    }

    }

    ?>

    </div>

</div>

<?php

if($complaint['Complaint_status'] != "Resolved"){

?>

<?php } ?>



<br>



<div class="card">

<h2>Timeline</h2>

<?php

if(mysqli_num_rows($timelineQuery) == 0){

echo "<p>No timeline available.</p>";

}

else{

?>


<div class="timeline">

    <?php

    while( $timeline = mysqli_fetch_assoc($timelineQuery)){

    ?>

    <div class="timeline-item">

        <div class="timeline-icon">
        ✓
        </div>

            <div class="timeline-content">

                <b><?php echo $timeline['TimelineDesc']; ?></b>

                <br><br>

                <small>

                <?php
                echo date("d M Y h:i A",strtotime($timeline['TimelineDate']));?>

                </small>

            </div>

    </div>

    <?php
    }
    ?>

</div>

<?php
}
?>

</div>






<script>

var map = L.map('map')
.setView(
[
<?php echo $complaint['Complaint_locationLat']; ?>,
<?php echo $complaint['Complaint_locationLong']; ?>
],
17
);

L.tileLayer(
'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png'
).addTo(map);

L.marker(
[
<?php echo $complaint['Complaint_locationLat']; ?>,
<?php echo $complaint['Complaint_locationLong']; ?>
]
)
.addTo(map)
.bindPopup(
"<?php echo addslashes($complaint['Complaint_locationName']); ?>"
)
.openPopup();

</script>






<script>

const statusSelect = document.querySelector(
'select[name="Complaint_status"]');

if(statusSelect){

    statusSelect.addEventListener('change',

function(){

if(this.value=="Resolved"){

    document.getElementById('resolutionSection'
    ).style.display="block";

    document.getElementById('resolutionImage'
    ).style.display="block";

}

else{

    document.getElementById('resolutionSection')
    .style.display="none";

    document.getElementById('resolutionImage')
    .style.display="none";

}

});

}

</script>




<script>

const resolutionInput = 
document.getElementById("resolutionFile");

if (resolutionInput) {

    const preview = document.getElementById("resolutionPreview");
    const fileName = document.getElementById("selectedFileName");

    resolutionInput.addEventListener("change", function () {

        const file = this.files[0];

        if (!file) {
            preview.src = "";
            preview.style.display = "none";
            fileName.innerHTML = "No file selected";
            return;
        }

        fileName.innerHTML = file.name;

        const reader = new FileReader();

        reader.onload = function (e) {
            preview.src = e.target.result;
            preview.style.display = "block";
        };

        reader.readAsDataURL(file);

    });

}

</script>



<script>

function toggleMenu(){

var menu = document.getElementById("dropdownMenu");

if(menu.style.display=="block"){

    menu.style.display="none";

}

else{

menu.style.display="block";

}

}

document.addEventListener("click",

function(event){

var menu = document.getElementById("dropdownMenu");

var profile = document.querySelector(".profile-menu");

if(!profile.contains(event.target)){

    menu.style.display="none";

}

}

);

</script>

</body>

</html>
