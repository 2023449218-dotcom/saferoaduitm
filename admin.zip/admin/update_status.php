<?php

session_start();

date_default_timezone_set('Asia/Kuala_Lumpur');

if(!isset($_SESSION['Role']) || $_SESSION['Role'] != "Admin"){

    header("Location: ../index.php");
    exit();
}




include("../db.php");

include("../includes/send_email.php");

include("../includes/send_telegram.php");



if(!isset($_POST['ComplaintID']) || !isset($_POST['Complaint_status'])){

    header("Location: manage_complaints.php");
    exit();
}




$complaintID = $_POST['ComplaintID'];

$status = $_POST['Complaint_status'];



$resolutionRemarks = "";

if(isset($_POST['Subcategory_resolutionRemark'])){

$resolutionRemarks = mysqli_real_escape_string($conn,
$_POST['Subcategory_resolutionRemark']
);

}


$adminID = $_SESSION['AdminID'];





$complaintQuery = mysqli_query($conn,
"SELECT *
FROM complaint
WHERE ComplaintID='$complaintID'"
);

$complaint = mysqli_fetch_assoc($complaintQuery);

$categoryQuery = mysqli_query(

$conn,

"SELECT

cc.CategoryName,
cs.Subcategory_name

FROM complaint c

JOIN category cc
ON c.CategoryID = cc.CategoryID

JOIN subcategory cs
ON c.SubcategoryID = cs.SubcategoryID

WHERE c.ComplaintID='$complaintID'"

);

$categoryData = mysqli_fetch_assoc($categoryQuery);




if(
$complaint['Complaint_status']=="In Progress"
&&
$status=="Pending"
){

header(
"Location: view_complaint.php?id=".$complaintID
);

exit();

}


if(!$complaint){

    die("Complaint not found.");
}

if($complaint['Complaint_status'] == "Resolved"){

    header(
    "Location: view_complaint.php?id=".$complaintID
    );

    exit();

}


if(
$complaint['Complaint_status'] == $status){

    header(
    "Location: view_complaint.php?id=".$complaintID
    );

    exit();

}



if($status == "Resolved"){

mysqli_query($conn,

"UPDATE complaint

SET

Complaint_status='$status',

Complaint_resolvedAt=NOW()

WHERE ComplaintID='$complaintID'"

);




/* Upload Resolution Evidence */

if(isset($_FILES['ResolutionImage'])

&&

$_FILES['ResolutionImage']['error']==0

){

    $folder =
    "../uploads/evidence/";

    $fileName = time()."_".
    basename($_FILES['ResolutionImage']['name']);

    move_uploaded_file(

    $_FILES['ResolutionImage']['tmp_name'],

    $folder.$fileName


    );

    $imagePath = $folder.$fileName;

    mysqli_query($conn,

    "INSERT INTO evidence

    (

        ComplaintID,

        Evidence_fileName,

        Evidence_fileType,

        Evidence_type,

        Evidence_resolutionRemark

    )

    VALUES

    (

    '$complaintID',

    '$fileName',

    'Image',

    'Resolution',

    '$resolutionRemarks'

    )"

    );

    }

}




else{

    mysqli_query(

    $conn,

    "UPDATE complaint

    SET

    Complaint_status='$status',

    Complaint_resolvedAt=NULL

    WHERE ComplaintID='$complaintID'"

    );

}






if($status=="Resolved"){

$timelineText =
"Complaint marked as Resolved by Admin.Resolution evidence uploaded.";

}

else{

$timelineText = "Complaint status updated to ".$status.".";

}

mysqli_query($conn,

"INSERT INTO Complaint_timeline
(
ComplaintID,
AdminID,
TimelineDesc,
TimelineDate
)

VALUES
(
'$complaintID',
'$adminID',
'$timelineText',
NOW()
)"

);




if(
!empty($complaint['StudentID'])
){

$userQuery = mysqli_query($conn,
"SELECT *
FROM student
WHERE StudentID='".
$complaint['StudentID']."'"
);

$user =
mysqli_fetch_assoc(
$userQuery
);

$email =
$user['Student_email'];

$name =
$user['Student_fullName'];

}




else{

$userQuery = mysqli_query($conn,
"SELECT *
FROM staff
WHERE StaffID='".
$complaint['StaffID']."'"
);

$user = mysqli_fetch_assoc($userQuery);

$email = $user['Staff_email'];

$name = $user['Staff_fullName'];

}






$message = "

<h2 style='color:#5E2D91;'>

✅ Complaint Successfully Resolved

</h2>

<p>

Dear <b>".$name."</b>,

</p>

<p>

Your complaint has been successfully resolved by the Auxiliary Police.

</p>

<hr>

<table cellpadding='8'>

<tr>

<td><b>Reference Number</b></td>

<td>".$complaint['ReferenceNumber']."</td>

</tr>

<tr>

<td><b>Category</b></td>

<td>".$categoryData['CategoryName']."</td>

</tr>

<tr>

<td><b>Issue</b></td>

<td>".$categoryData['Subcategory_name']."</td>

</tr>

<tr>

<td><b>Status</b></td>

<td style='color:green;'><b>".$status." ✅</b></td>

</tr>

</table>

<br>

<p>

Thank you for helping improve traffic safety at UiTM Shah Alam.

</p>

<hr>

<h3 style='color:#5E2D91;'>

📷 Resolution Evidence

</h3>

<p>

The Auxiliary Police uploaded the following evidence after resolving your complaint.

</p>

<img
src='cid:resolutionImage'
style='
max-width:500px;
width:100%;
border-radius:10px;
border:1px solid #ddd;
'>

";







if($user['notification_preference'] =="Email"){

if($status=="Resolved"){

    sendEmailWithImage(

        $email,

        $name,

        "Complaint Successfully Resolved",

        $message,

        $imagePath

    );

}

else{

    sendEmail(

        $email,

        $name,

        "Complaint Status Updated",

        $message

    );

}

}



else{

if(!empty($user['telegram_chatID'])){

if($status=="Resolved"){

$telegramCaption =

"✅ Complaint Successfully Resolved\n\n".

"Reference Number: ".
$complaint['ReferenceNumber'].

"\n\nCategory: ".
$categoryData['CategoryName'].

"\n\nIssue: ".
$categoryData['Subcategory_name'].

"\n\n📝 Resolution Remarks:\n".
$resolutionRemarks.

"\n\n📅 Resolved On: ".
date("d M Y h:i A").

"\n\nThank you for using SafeRoad UiTM.";


sendTelegramPhoto(

$user['telegram_chatID'],

$imagePath,

$telegramCaption

);

}


else{

sendTelegram(

$user['telegram_chatID'],

$message

);

}

}

}






header(
"Location: view_complaint.php?id=".$complaintID
);

exit();




