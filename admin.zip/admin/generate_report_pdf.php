<?php

session_start();

date_default_timezone_set('Asia/Kuala_Lumpur');




if(!isset($_SESSION['Role']) || $_SESSION['Role']!="Admin"){

    header("Location: ../index.php");
    exit();
}



include("../db.php");

require_once '../dompdf/autoload.inc.php';

use Dompdf\Dompdf;


$currentMonth = isset($_GET['month']) ? (int)$_GET['month'] : date("n");
$currentYear  = isset($_GET['year']) ? (int)$_GET['year'] : date("Y");



$summaryQuery = mysqli_query($conn,
"SELECT
Complaint_status,
COUNT(*) AS Total
FROM complaint
WHERE
MONTH(Complaint_createdAt)='$currentMonth'
AND
YEAR(Complaint_createdAt)='$currentYear'
GROUP BY Complaint_status"
);

$summary = [];

while($row = mysqli_fetch_assoc($summaryQuery)){

    $summary[
    $row['Complaint_status']
    ] =
    $row['Total'];
}


$resolved = $summary['Resolved'] ?? 0;

$cancelled = $summary['Cancelled'] ?? 0;

$totalComplaint = array_sum($summary);

$totalForRate = $totalComplaint - $cancelled;

$resolutionRate = $totalForRate > 0 
? 
round(($resolved/$totalForRate)*100) : 0;





$categoryQuery = mysqli_query(
$conn,
"SELECT
cc.CategoryName,
COUNT(*) AS Total

FROM complaint c

INNER JOIN category cc
ON c.CategoryID=cc.CategoryID

WHERE

MONTH(c.Complaint_createdAt)='$currentMonth'

AND

YEAR(c.Complaint_createdAt)='$currentYear'

GROUP BY c.CategoryID

ORDER BY
Total DESC,
cc.CategoryName ASC"
);





$riskQuery = mysqli_query($conn,

"SELECT

cs.Subcategory_risk,

COUNT(*) AS Total

FROM complaint c

INNER JOIN subcategory cs
ON c.SubcategoryID = cs.SubcategoryID

WHERE

MONTH(c.Complaint_createdAt)='$currentMonth'

AND

YEAR(c.Complaint_createdAt)='$currentYear'

GROUP BY cs.Subcategory_risk

ORDER BY FIELD(
cs.Subcategory_risk,
'High',
'Medium',
'Low'
)"
);






$policeQuery = mysqli_query(
$conn,
"SELECT
ap.Police_fullName,

COUNT(c.ComplaintID) AS Assigned,

SUM(
CASE
WHEN c.Complaint_status='Resolved'
THEN 1
ELSE 0
END
) AS Resolved,

SUM(
CASE
WHEN c.Complaint_status='Escalated'
THEN 1
ELSE 0
END
) AS Escalated

FROM auxiliary_police ap

LEFT JOIN complaint c
ON ap.PoliceID = c.PoliceID
AND MONTH(c.Complaint_createdAt) = '$currentMonth'
AND YEAR(c.Complaint_createdAt) = '$currentYear'

GROUP BY ap.PoliceID
"
);





$escalatedQuery = mysqli_query(
$conn,
"SELECT
c.ReferenceNumber,
cc.CategoryName,
ap.Police_fullName,
c.Complaint_deadline,

DATEDIFF(
CURDATE(),
DATE(c.Complaint_deadline)
) AS OverdueDays

FROM complaint c

LEFT JOIN category cc
ON c.CategoryID = cc.CategoryID

LEFT JOIN auxiliary_police ap
ON c.PoliceID = ap.PoliceID

WHERE c.Complaint_status='Escalated'

AND MONTH(c.Complaint_createdAt)='$currentMonth'

AND YEAR(c.Complaint_createdAt)='$currentYear'

ORDER BY c.Complaint_deadline DESC"
);





$html = "

<h1 style='text-align:center;'>
SafeRoad UiTM
</h1>

<h2 style='text-align:center;'>
Monthly Complaint Report
</h2>

<p>

<strong>Report Period :</strong>

".date("F Y",mktime(0,0,0,$currentMonth,1,$currentYear))."

</p>

<p>

<strong>Generated On :</strong>

".date("d F Y, h:i A")."

</p>

<hr>

";




$html .= "

<h3>Dashboard Summary</h3>

<table
border='1'
cellpadding='8'
width='100%'
style='border-collapse:collapse;'>

<tr>

<th>Total Complaints</th>

<th>Resolved</th>

<th>Escalated</th>

<th>Resolution Rate</th>

</tr>

<tr>

<td align='center'>".$totalComplaint."</td>

<td align='center'>".($summary['Resolved'] ?? 0)."</td>

<td align='center'>".($summary['Escalated'] ?? 0)."</td>

<td align='center'>".$resolutionRate."%</td>

</tr>

</table>

<br>

";



$html .= "

<h3>Complaint Summary</h3>

<table
border='1'
cellpadding='8'
width='100%'
style='border-collapse:collapse;'>

<tr>

<th align='center'>Status</th>
<th>Total</th>

</tr>

<tr>
<td>Pending</td>
<td>".($summary['Pending'] ?? 0)."</td>
</tr>

<tr>
<td>Awaiting Police</td>
<td>".($summary['Awaiting Police'] ?? 0)."</td>
</tr>
<tr>

<tr>
<td>Warning Sent</td>
<td>".($summary['Warning Sent'] ?? 0)."</td>
</tr>

<tr>
<td>In Progress</td>
<td>".($summary['In Progress'] ?? 0)."</td>
</tr>

<tr>
<td>Resolved</td>
<td>".($summary['Resolved'] ?? 0)."</td>
</tr>

<tr>
<td>Escalated</td>
<td>".($summary['Escalated'] ?? 0)."</td>
</tr>

<tr>
<td>Cancelled</td>
<td>".($summary['Cancelled'] ?? 0)."</td>
</tr>

</table>

";

$html .= "

<h3>Complaint Categories</h3>

<table
border='1'
cellpadding='8'
width='100%'
style='border-collapse:collapse;'>

<tr>

<th>Category</th>
<th>Total</th>

</tr>
";


if(mysqli_num_rows($categoryQuery) > 0){

    while($row = mysqli_fetch_assoc($categoryQuery)){

        $html .= "

        <tr>

        <td>".$row['CategoryName']."</td>

        <td align='center'>".$row['Total']."</td>

        </tr>";

    }

}

else{

    $html .= "

    <tr>

    <td colspan='2' align='center'>

    No data available for the selected month.

    </td>

    </tr>";

}

$html .= "

</table>

<br>

";


$html .= "

<h3>Risk Level Analysis</h3>

<table
border='1'
cellpadding='8'
width='100%'
style='border-collapse:collapse;'>

<tr>

<th>Risk Level</th>

<th>Total</th>

</tr>";

if(mysqli_num_rows($riskQuery)>0){

while($row=mysqli_fetch_assoc($riskQuery)){

$html.="

<tr>

<td>".$row['Subcategory_risk']."</td>

<td align='center'>".$row['Total']."</td>

</tr>";

}

}

else{

$html.="

<tr>

<td colspan='2' align='center'>

No data available for the selected month.

</td>

</tr>";

}

$html.="</table>";


$html .= "

<h3>Auxiliary Police Performance</h3>

<table
border='1'
cellpadding='8'
width='100%'
style='border-collapse:collapse;'>

<tr>

<th>Police Officer</th>
<th>Assigned Cases</th>
<th>Resolved Cases</th>
<th>Escalated Cases</th>
<th>Performance</th>

</tr>

";


if(mysqli_num_rows($policeQuery) > 0){

    while($row = mysqli_fetch_assoc($policeQuery)){

        if($row['Assigned'] == 0){

            $performance = "-";

        }

        else{

            $rate = ($row['Resolved'] / $row['Assigned']) * 100;

            if($rate >= 80){

                $performance = "Excellent";

            }
            elseif($rate >= 50){

                $performance = "Good";

            }
            else{

                $performance = "Poor";

            }

        }

        $html .= "

        <tr>

        <td>".$row['Police_fullName']."</td>

        <td align='center'>".$row['Assigned']."</td>

        <td align='center'>".$row['Resolved']."</td>

        <td align='center'>".$row['Escalated']."</td>

        <td align='center'>".$performance."</td>

        </tr>

        ";

    }

}

else{

    $html .= "

    <tr>

    <td colspan='5' align='center'>

    No data available for the selected month.

    </td>

    </tr>

    ";

}


$html .= "

</table>

<br>

";


$html .= "

<h3>Escalated Complaints</h3>

<table
border='1'
cellpadding='8'
width='100%'
style='border-collapse:collapse;'>

<tr>

<th>Reference No</th>

<th>Category</th>

<th>Assigned Police</th>

<th>Deadline</th>

<th>Overdue Days</th>

</tr>

";


if(mysqli_num_rows($escalatedQuery) > 0){

    while($row = mysqli_fetch_assoc($escalatedQuery)){

        $days = max(0, $row['OverdueDays']);

        $html .= "

        <tr>

        <td>".$row['ReferenceNumber']."</td>

        <td>".$row['CategoryName']."</td>

        <td>".($row['Police_fullName'] ?: "Not Assigned")."</td>

        <td>".date(
            "d M Y",
            strtotime($row['Complaint_deadline'])
        )."</td>

        <td>".$days." day".($days==1 ? "" : "s")."</td>

        </tr>

        ";

    }

}

else{

    $html .= "

    <tr>

    <td colspan='5' align='center'>

    No escalated complaints for the selected month.

    </td>

    </tr>

    ";

}


$html .= "

</table>

<br>

";



$html .= "

<hr>

<p>

This report summarizes the traffic complaints received during the selected month. It provides an overview of complaint statistics, complaint categories, risk level analysis, auxiliary police performance, and escalated complaints.

</p>

<br>

<p
style='
text-align:center;
font-size:12px;
color:gray;
'>

<b>SafeRoad UiTM</b><br>

Traffic Complaint Management System<br>

This report was automatically generated by the SafeRoad UiTM system.<br>

Generated on ".date("d F Y, h:i A")."

</p>

";


$dompdf = new Dompdf();

$dompdf->loadHtml($html);

$dompdf->setPaper('A4','landscape');

$dompdf->render();

$filename ="Monthly_Complaint_Report_".date("F_Y",mktime(0,0,0,
$currentMonth,1,
$currentYear)).".pdf";

$dompdf->stream($filename,['Attachment' => true]);

exit();

?>