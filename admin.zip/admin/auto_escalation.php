<?php


date_default_timezone_set('Asia/Kuala_Lumpur');



include("../db.php");

include("../includes/send_email.php");

include("../includes/send_telegram.php");



$query = mysqli_query(
$conn,
"SELECT *
FROM complaint
WHERE Complaint_status 
IN ('Pending','In Progress','Warning Sent','Awaiting Police')
AND Complaint_deadline < NOW()"
);

if(!$query){

    die(mysqli_error($conn));

}


$count = 0;

while($complaint = mysqli_fetch_assoc($query)){

$count++;

$complaintID = $complaint['ComplaintID'];

$result = mysqli_query(
$conn,
"UPDATE complaint
SET Complaint_status='Escalated'
WHERE ComplaintID='$complaintID'"
);

if(!$result){

    die(mysqli_error($conn));

}


mysqli_query(
$conn,
"INSERT INTO complaint_timeline
(
    ComplaintID,
    AdminID,
    TimelineDesc,
    TimelineDate
)
VALUES
(
    '$complaintID',NULL,
    'Complaint automatically escalated due to missed deadline.',NOW() )"

);




    if(!empty($complaint['StudentID'])){

    $userQuery = mysqli_query(
    $conn,
    "SELECT *
    FROM student
    WHERE StudentID='".
    $complaint['StudentID']."'"
    );

    $user = mysqli_fetch_assoc(
    $userQuery
    );

    $email = $user['Student_email'];

    $name = $user['Student_fullName'];

}

else{

    $userQuery = mysqli_query(
    $conn,
    "SELECT *
    FROM staff
    WHERE StaffID='".
    $complaint['StaffID']."'"
    );

    $user = mysqli_fetch_assoc(
    $userQuery
    );

    $email = $user['Staff_email'];

    $name = $user['Staff_fullName'];

}




$message =

"SafeRoad UiTM

Complaint Escalated

Reference Number:
".$complaint['ReferenceNumber']."

Your complaint has been automatically escalated because the resolution deadline has been exceeded.

A superior officer will review the case and assign appropriate action.

Current Status:
Escalated

Thank you.";



if($user['notification_preference'] == "Email"){

    sendEmail(
    $email,
    $name,
    "Complaint Escalated",
    $message
    );

}

else{

    if(!empty($user['telegram_chatID'])){

        sendTelegram(
        $user['telegram_chatID'],
        $message
        );

    }

}


}


echo $count.
" complaint(s) escalated successfully.";













