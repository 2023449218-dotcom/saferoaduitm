<?php

session_start();

date_default_timezone_set('Asia/Kuala_Lumpur');

if(!isset($_SESSION['Role']) || $_SESSION['Role'] != "Admin"){

    header("Location: ../index.php");
    exit();
}




include("../db.php");



if(!isset($_POST['ComplaintID']) || !isset($_POST['PoliceID'])){

    header("Location: manage_complaints.php");

    exit();
}




include("../includes/send_email.php");

include("../includes/send_telegram.php");




$complaintID = $_POST['ComplaintID'];

$policeID = $_POST['PoliceID'];





$policeQuery = mysqli_query(
$conn,
"SELECT *
FROM auxiliary_police
WHERE PoliceID='$policeID'"
);

$police = mysqli_fetch_assoc($policeQuery);




if(!$police){

    die("Police not found.");
}

$policeName = $police['Police_fullName'];




$checkQuery = mysqli_query(
$conn,
"SELECT PoliceID
FROM complaint
WHERE ComplaintID='$complaintID'"
);

$check = mysqli_fetch_assoc($checkQuery);

if(!empty($check['PoliceID'])){

    header("Location: view_complaint.php?id=".$complaintID);

exit();

}


$result = mysqli_query(
$conn,
"UPDATE Complaint
SET PoliceID='$policeID',
Complaint_status='In Progress'
WHERE ComplaintID='$complaintID'"
);

if(!$result){
    die(mysqli_error($conn));
}




$adminID = $_SESSION['AdminID'];




$timelineDesc =
"Complaint assigned to ".$policeName.". Status updated to In Progress.";

$result = mysqli_query(
$conn,
"INSERT INTO Complaint_timeline
(
    ComplaintID,
    AdminID,
    TimelineDesc,
    TimelineDate
)
VALUES
(
    '$complaintID',
    '$adminID',
    '$timelineDesc',
    NOW()
)"
);

if(!$result){
    die(mysqli_error($conn));
}





$complaintQuery = mysqli_query(
$conn,
"SELECT
c.*,
cc.CategoryName,
cs.Subcategory_name,
cs.Subcategory_risk

FROM Complaint c

INNER JOIN Category cc
ON c.CategoryID = cc.CategoryID

INNER JOIN Subcategory cs
ON c.SubcategoryID = cs.SubcategoryID

WHERE c.ComplaintID='$complaintID'"
);

$complaint = mysqli_fetch_assoc($complaintQuery);





if(!empty($complaint['StudentID'])){

$userQuery = mysqli_query(
$conn,
"SELECT *
FROM student
WHERE StudentID='".
$complaint['StudentID']."'"
);

$user = mysqli_fetch_assoc(
$userQuery
);

}


else{

$userQuery = mysqli_query(
$conn,
"SELECT *
FROM staff
WHERE StaffID='".
$complaint['StaffID']."'"
);

$user = mysqli_fetch_assoc(
$userQuery
);

}


if(!empty($complaint['StudentID'])){

    $complainantName = $user['Student_fullName'];
    $complainantRole = "Student";

}

else{

    $complainantName = $user['Staff_fullName'];
    $complainantRole = "Staff";

}


$vehicleQuery = mysqli_query(
$conn,
"SELECT *
FROM ComplaintVehicle
WHERE ComplaintID='$complaintID'"
);

$vehicle = mysqli_fetch_assoc($vehicleQuery);





$emailMessage = "

<h2 style='color:#5E2D91;'>📢 Complaint Assignment Notification</h2>

<p>
Dear <b>".$complainantName."</b>,
</p>

<p>
We would like to inform you that your complaint has been successfully assigned to an Auxiliary Police officer for further investigation and action.
</p>

<table cellpadding='8' style='border-collapse:collapse;'>

<tr>
<td><b>Reference Number</b></td>
<td>".$complaint['ReferenceNumber']."</td>
</tr>

<tr>
<td><b>Assigned Officer</b></td>
<td>".$policeName."</td>
</tr>

<tr>
<td><b>Status</b></td>
<td><b style='color:#1f4e79;'>In Progress</b></td>
</tr>

</table>

<p>
The assigned officer will investigate your complaint and take the necessary action. You may track the latest progress through the SafeRoad UiTM system.
</p>

<p>
Thank you for helping us improve traffic safety at UiTM Shah Alam.
</p>

<p>
Kind regards,<br>
<b>SafeRoad UiTM System</b><br>
UiTM Auxiliary Police
</p>

";



$telegramMessage =
"📢 COMPLAINT ASSIGNMENT

Dear ".$complainantName.",

Your complaint has been assigned to an Auxiliary Police officer for further action.

📋 Reference Number:
".$complaint['ReferenceNumber']."

👮 Assigned Officer:
".$policeName."

🔄 Status:
In Progress

The assigned officer will review your complaint and take the necessary action.

You can track the latest progress through the SafeRoad UiTM system.

Thank you.

SafeRoad UiTM System";




if($user['notification_preference'] == "Email"){

if(!empty($complaint['StudentID'])){

$email = $user['Student_email'];

$name = $user['Student_fullName'];

}

else{

$email = $user['Staff_email'];

$name = $user['Staff_fullName'];

}

sendEmail(
$email,
$name,
"Complaint Assigned",
$emailMessage
);

}

else{

if(

$user['notification_preference'] == "Telegram"
&&
!empty($user['telegram_chatID'])
){

sendTelegram(
$user['telegram_chatID'],
$telegramMessage
);

}

} // CLOSE ELSE




$policeEmailMessage = "

<h2 style='color:#5E2D91;'>
🚨 New Complaint Assigned
</h2>

<p>
Dear <b>".$police['Police_fullName']."</b>,
</p>

<p>
A new traffic complaint has been assigned to you for further action.
</p>

<table cellpadding='8' style='border-collapse:collapse;'>

<tr>
<td><b>Reference Number</b></td>
<td>".$complaint['ReferenceNumber']."</td>
</tr>

<tr>
<td><b>Complainant</b></td>
<td>".$complainantName." (".$complainantRole.")</td>
</tr>

<tr>
<td><b>Category</b></td>
<td>".$complaint['CategoryName']."</td>
</tr>

<tr>
<td><b>Subcategory</b></td>
<td>".$complaint['Subcategory_name']."</td>
</tr>

<tr>
<td><b>Risk Level</b></td>
<td>".$complaint['Subcategory_risk']."</td>
</tr>

<tr>
<td><b>Location</b></td>
<td>".$complaint['Complaint_locationName']."</td>
</tr>

<tr>
<td><b>Specific Location</b></td>
<td>".$complaint['Complaint_locationDesc']."</td>
</tr>

<tr>
<td><b>Description</b></td>
<td>".$complaint['Complaint_desc']."</td>
</tr>

</table>
";


if($vehicle){

$policeEmailMessage .=

"

Vehicle Information

Plate Number:
".$vehicle['Reported_plateNum']."

Vehicle Type:
".$vehicle['Reported_type']."

Vehicle Colour:
".$vehicle['Reported_color']."

Vehicle Model:
".$vehicle['Reported_model'];

}

$policeEmailMessage .=

"

Please log in to SafeRoad UiTM immediately to review and take appropriate action.

Thank you.";




if(!empty($police['Police_email'])){

    sendEmail(
        $police['Police_email'],
        $police['Police_fullName'],
        "New Complaint Assigned - ".$complaint['ReferenceNumber'],
        $policeEmailMessage
    );

}



header("Location: view_complaint.php?id=".$complaintID);

exit();



