<?php



session_start();



if(!isset($_SESSION['Role'])||$_SESSION['Role'] != "Staff"){

    header("Location: ../index.php");

    exit();
}



include("../db.php");



$staffID = $_SESSION['UserID'];

$notification = $_POST['notification_preference'];

$chatID = trim($_POST['telegram_chatID']);


if($notification == "Email"){

    $chatID = "";
}

$sql = "
UPDATE staff
SET
notification_preference='$notification',
telegram_chatID='$chatID'
WHERE StaffID='$staffID'
";

if(mysqli_query($conn,$sql)){

echo "

<script>

alert('Notification Settings Updated Successfully');

window.location='profile.php';

</script>

";

}

else{

echo "

<script>

alert('Update Failed');

window.location='profile.php';

</script>

";

}

?>