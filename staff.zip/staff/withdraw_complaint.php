<?php

session_start();

if(
!isset($_SESSION['Role'])
||
$_SESSION['Role']!="Staff"
){
    header("Location: ../index.php");
    exit();
}



include("../db.php");




if(
!isset($_GET['id'])
){
    header("Location: my_complaints.php");
    exit();
}


$complaintID = (int)$_GET['id'];



$userID =
$_SESSION['UserID'];




$query =
mysqli_query(

$conn,

"SELECT *

FROM complaint

WHERE

ComplaintID='$complaintID'

AND

StaffID='$userID'"

);





$complaint =
mysqli_fetch_assoc(
$query
);

if(
!$complaint
){
    die("Access Denied");
}

if(
$complaint['Complaint_status']!="Pending"
||
!empty($complaint['PoliceID'])
){
    header("Location: view_complaint.php?id=".$complaintID);
    exit();
}



$result = mysqli_query(

$conn,

"UPDATE Complaint

SET

Complaint_status='Cancelled'

WHERE ComplaintID='$complaintID'"

);

if(!$result){

    die(mysqli_error($conn));

}





$result = mysqli_query(

$conn,

"INSERT INTO Complaint_timeline
(
    ComplaintID,
    TimelineDesc,
    TimelineDate
)

VALUES
(
    '$complaintID',
    'Complaint withdrawn by complainant because issue already resolved.',
    NOW()
)"

);

if(!$result){

    die(mysqli_error($conn));

}




header(
"Location: my_complaints.php"
);

exit();