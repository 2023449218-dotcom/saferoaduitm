<?php

session_start();

$name = $_SESSION['UserName'];

if(!isset($_SESSION['Role']) || $_SESSION['Role'] != "Staff"){

    header("Location: ../index.php");
    exit();
}




include("../db.php");


$staffID = $_SESSION['UserID'];

$evidence1 = $_SESSION['Evidence1'] ?? "";


$evidence2 = $_SESSION['Evidence2'] ?? "";


$evidence3 = $_SESSION['Evidence3'] ?? "";





$staffQuery = mysqli_query(
$conn,
"SELECT *
FROM staff
WHERE StaffID='$staffID'"
);

$staff = mysqli_fetch_assoc(
$staffQuery
);


$profileImage = !empty($staff['Staff_profile'])
?
"../uploads/profile/".$staff['Staff_profile']
:
"../images/default-profile.png";

?>








<!DOCTYPE html>

<html>

<head>

<link rel="icon" type="image/png" href="../images/logo.png">

<title>Evidence Upload</title>

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:Arial,sans-serif;
}

body{
background:#f4f6f9;
}

/* Sidebar */

.sidebar{
width:250px;
height:100vh;
background:#5E2D91;
position:fixed;
left:0;
top:0;
box-shadow:2px 0 10px rgba(0,0,0,0.1);
}

.logo-section{
text-align:center;
padding:20px;
border-bottom:1px solid rgba(255,255,255,0.15);
}

.sidebar-logo{
width:80px;
height:80px;
object-fit:contain;
}

.sidebar h2{
color:white;
font-size:20px;
margin-top:10px;
}

.sidebar a{
display:block;
padding:15px 20px;
color:white;
text-decoration:none;
font-size:15px;
transition:0.3s;
}

.sidebar a:hover{
background:#4b2374;
}

.active{
background:#4b2374;
border-left:5px solid white;
}

/* Topbar */

.topbar{
height:70px;
background:white;
display:flex;
justify-content:flex-end;
align-items:center;
padding:0 30px;
margin-left:250px;
box-shadow:0 2px 10px rgba(0,0,0,0.08);
}

.profile-menu{
display:flex;
align-items:center;
gap:10px;
position:relative;
cursor:pointer;
}

.username{
font-weight:bold;
color:#333;
}

.profile-menu img{
width:45px;
height:45px;
border-radius:50%;
object-fit:cover;
border:2px solid #5E2D91;
}

.dropdown{
display:none;
position:absolute;
right:0;
top:55px;
background:white;
width:180px;
border-radius:10px;
box-shadow:0 5px 15px rgba(0,0,0,0.15);
overflow:hidden;
z-index:9999;
}

.dropdown a{
display:block;
padding:12px 15px;
text-decoration:none;
color:#333;
}

.dropdown a:hover{
background:#f5f5f5;
}

.container{
width:calc(100% - 320px);
margin-left:280px;
margin-top:30px;
background:white;
padding:30px;
border-radius:10px;
}

.step-bar{
display:flex;
margin-bottom:30px;
}

.step{
flex:1;
padding:12px;
text-align:center;
background:#e9ecef;
margin-right:5px;
border-radius:8px;
}


.form-group{
margin-bottom:20px;
}



.btn{
background:#5E2D91;
color:white;
padding:12px 25px;
border:none;
border-radius:5px;
cursor:pointer;
}

.btn:hover{
background:#4b2374;
}

.back-btn{
background:#6c757d;
margin-right:10px;
}

.progress-container{
display:flex;
align-items:center;
justify-content:space-between;
margin-bottom:40px;
}

.progress-step{
text-align:center;
display:flex;
flex-direction:column;
align-items:center;
}

.circle{
width:50px;
height:50px;
border-radius:50%;
background:#d8d8d8;
color:#555;
font-weight:bold;
font-size:18px;
display:flex;
align-items:center;
justify-content:center;
}

.progress-step.current .circle{
background:#5E2D91;
color:white;
box-shadow:0 4px 10px rgba(94,45,145,0.3);
}

.progress-step.completed .circle{
background:#28a745;
color:white;
}

.progress-step p{
margin-top:8px;
font-size:13px;
font-weight:500;
color:#666;
}

.line{
flex:1;
height:3px;
background:#d8d8d8;
margin:0 10px;
margin-bottom:25px;
border-radius:10px;
}

.upload-card{
border:2px dashed #d0d0d0;
border-radius:12px;
padding:20px;
text-align:center;
background:#fafafa;
transition:0.3s;
margin-bottom:20px;
}

.upload-card:hover{
border-color:#5E2D91;
background:#f8f5fc;
}

.upload-icon{
font-size:40px;
margin-bottom:10px;
}

.preview-image{
max-width:250px;
border-radius:10px;
margin-top:15px;
box-shadow:0 2px 8px rgba(0,0,0,0.15);
}

.delete-btn{
display:inline-block;
margin-top:10px;
background:#dc3545;
color:white;
padding:10px 15px;
border-radius:6px;
text-decoration:none;
}

.evidence-grid{
display:grid;
grid-template-columns:repeat(3,1fr);
gap:20px;
margin-bottom:30px;
}

.upload-card{
position:relative;
border:2px dashed #d0d0d0;
border-radius:12px;
padding:20px;
background:#fafafa;
text-align:center;
min-height:300px;
}

.preview-image,
#preview1,
#preview2,
#preview3{
display:block;
margin:15px auto;
max-width:100%;
max-height:180px;
object-fit:cover;
border-radius:10px;
}

.delete-circle{
position:absolute;
top:10px;
right:10px;
width:32px;
height:32px;
background:#dc3545;
color:white;
border-radius:50%;
text-decoration:none;
display:flex;
align-items:center;
justify-content:center;
font-size:18px;
font-weight:bold;
box-shadow:0 2px 6px rgba(0,0,0,0.2);
}

.delete-circle:hover{
background:#c82333;
}

.button-group{
display:flex;
justify-content:space-between;
margin-top:30px;
}

</style>

</head>





<body>

<div class="sidebar">

<div class="logo-section">

<img
src="../images/logo.png"
class="sidebar-logo">




<h2>SafeRoad UiTM</h2>

</div>

<a href="dashboard.php" >Dashboard</a>

<a href="submit_complaint_step1.php" class="active" >Submit Complaint</a>

<a href="my_complaints.php">My Complaints</a>

</div>




<div class="topbar">

<div class="profile-menu">

<span class="username">
<?php echo $name; ?>
</span>

<img
src="<?php echo $profileImage; ?>"
alt="Profile"
onclick="toggleMenu()">




<div
id="dropdownMenu"

class="dropdown">

<a href="profile.php">My Profile</a>

<a href="../logout.php">Logout</a>

</div>

</div>

</div>





<div class="container"> 

<h2>Submit Complaint</h2>

<p style="
color:#666;
margin-top:10px;
margin-bottom:25px;
">
Step 2 of 5: Upload at least one evidence.
</p>

<br>

<div class="progress-container">

<div class="progress-step completed">
<div class="circle">1</div>
<p>Details</p>
</div>

<div class="line"></div>

<div class="progress-step current">
<div class="circle">2</div>
<p>Evidence</p>
</div>

<div class="line"></div>

<div class="progress-step">
<div class="circle">3</div>
<p>Vehicle</p>
</div>

<div class="line"></div>

<div class="progress-step">
<div class="circle">4</div>
<p>Location</p>
</div>

<div class="line"></div>

<div class="progress-step">
<div class="circle">5</div>
<p>Review</p>
</div>


</div>






<form
action="save_step2.php"
method="POST"
enctype="multipart/form-data">





<div class="evidence-grid">

<div class="form-group">

<div class="upload-card">

<div class="upload-icon">📷</div>



<h3>Evidence 1</h3>

<p>Upload photo or video evidence</p>

<input
type="file"
id="evidence1"
name="evidence1"
accept="image/*,video/*"
<?php if($evidence1==""){ ?>
required
<?php } ?>>

<br><br>

<a
id="delete1"
href="delete_evidence.php?slot=1"
class="delete-circle"
style="<?php echo ($evidence1!="") ? 'display:flex;' : 'display:none;'; ?>">
×
</a>

<div id="previewContainer1">

<?php
if($evidence1!=""){

$fileExtension =
strtolower(pathinfo($evidence1, PATHINFO_EXTENSION));

if(in_array($fileExtension,['jpg','jpeg','png','gif','webp'])){
?>

<img
id="preview1"
class="preview-image"
src="../uploads/evidence/<?php echo $evidence1; ?>">

<?php
}
else{
?>

<video
id="preview1"
class="preview-image"
controls>

<source
src="../uploads/evidence/<?php echo $evidence1; ?>"
type="video/mp4">

</video>

<?php
}
}
?>

</div>

</div>

</div>







<div class="form-group">

<div class="upload-card">

<div class="upload-icon">📷</div>




<h3>Evidence 2</h3>

<p>Upload photo or video evidence</p>

<input
type="file"
id="evidence2"
name="evidence2"
accept="image/*,video/*"
<?php if($evidence2==""){ ?>
<?php } ?>>

<br><br>

<a
id="delete2"
href="delete_evidence.php?slot=2"
class="delete-circle"
style="<?php echo ($evidence2!="") ? 'display:flex;' : 'display:none;'; ?>">
×
</a>

<div id="previewContainer2">

<?php
if($evidence2!=""){

$fileExtension =
strtolower(pathinfo($evidence2, PATHINFO_EXTENSION));

if(in_array($fileExtension,['jpg','jpeg','png','gif','webp'])){
?>

<img
id="preview2"
class="preview-image"
src="../uploads/evidence/<?php echo $evidence2; ?>">

<?php
}
else{
?>

<video
id="preview2"
class="preview-image"
controls>

<source
src="../uploads/evidence/<?php echo $evidence2; ?>"
type="video/mp4">

</video>

<?php
}
}
?>

</div>

</div>

</div>







<div class="form-group">

<div class="upload-card">

<div class="upload-icon">
📷
</div>

<h3>Evidence 3</h3>

<p>Upload photo or video evidence</p>

<input
type="file"
id="evidence3"
name="evidence3"
accept="image/*,video/*"
<?php if($evidence3==""){ ?>
<?php } ?>>

<br><br>

<a
id="delete3"
href="delete_evidence.php?slot=3"
class="delete-circle"
style="<?php echo ($evidence3!="") ? 'display:flex;' : 'display:none;'; ?>">
×
</a>

<div id="previewContainer3">

<?php
if($evidence3!=""){

$fileExtension =
strtolower(pathinfo($evidence1, PATHINFO_EXTENSION));

if(in_array($fileExtension,['jpg','jpeg','png','gif','webp'])){
?>

<img
id="preview3"
class="preview-image"
src="../uploads/evidence/<?php echo $evidence3; ?>">

<?php
}
else{
?>

<video
id="preview3"
class="preview-image"
controls>

<source
src="../uploads/evidence/<?php echo $evidence3; ?>"
type="video/mp4">

</video>

<?php
}
}
?>

</div>

</div>
</div>
</div>


<div class="button-group">

<a
href="submit_complaint_step1.php"
class="btn back-btn"
style="text-decoration:none;">

← Previous

</a>

<button
type="submit"
class="btn">

Next Step →

</button>

</div>








<script>

function toggleMenu(){

var menu = document.getElementById(
"dropdownMenu"
);

if(
menu.style.display=="block"
){
menu.style.display="none";
}
else{
menu.style.display="block";
}

}

document.addEventListener(
"click",
function(event){

var menu = document.getElementById(
"dropdownMenu"
);

var profile = document.querySelector(
".profile-menu"
);

if(
!profile.contains(
event.target
)
){
menu.style.display="none";
}

}
);
</script>






<script>

function previewFile(inputId, containerId){

    var input = document.getElementById(inputId);

    if(!input){
        return;
    }

    input.addEventListener("change", function(){

        if(this.files.length==0){
            return;
        }

        var file = this.files[0];

        var reader = new FileReader();

        reader.onload = function(e){

            var container =
            document.getElementById(containerId);

            container.innerHTML="";

            if(file.type.startsWith("image/")){

                container.innerHTML =
                "<img src='"+e.target.result+"' class='preview-image'>";

            }
            else if(file.type.startsWith("video/")){

                container.innerHTML =
                "<video controls class='preview-image'>" +
                "<source src='"+e.target.result+"'>" +
                "</video>";

            }

            var deleteBtn =
            document.getElementById(
            "delete"+
            inputId.replace("evidence","")
            );

            deleteBtn.style.display="flex";

        };

        reader.readAsDataURL(file);

    });

}

previewFile(
"evidence1",
"previewContainer1"
);

previewFile(
"evidence2",
"previewContainer2"
);

previewFile(
"evidence3",
"previewContainer3"
);

</script>






</body>

</html>