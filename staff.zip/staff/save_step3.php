<?php

session_start();

$_SESSION['Vehicle_plateNum'] =
$_POST['Vehicle_plateNum'];

$_SESSION['Vehicle_type'] =
$_POST['Vehicle_type'];

$_SESSION['Vehicle_color'] =
$_POST['Vehicle_color'];

$_SESSION['Vehicle_model'] =
$_POST['Vehicle_model'];

header(
"Location: submit_complaint_step4.php"
);

exit();

?>