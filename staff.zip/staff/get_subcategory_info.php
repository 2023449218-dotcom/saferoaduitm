<?php

include("../db.php");

$subcategoryID =
$_GET['SubcategoryID'];

$query =
mysqli_query(

$conn,

"SELECT
Subcategory_risk,
Subcategory_resolutionTime

FROM subcategory

WHERE SubcategoryID='$subcategoryID'"

);

$row =
mysqli_fetch_assoc($query);

echo json_encode($row);

?>