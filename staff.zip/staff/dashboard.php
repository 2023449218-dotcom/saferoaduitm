<?php

/* Start user session */
session_start();


/*=====================================================
    Session Validation

    Allow access only to authenticated Staff users.
=====================================================*/
if(!isset($_SESSION['Role']) || $_SESSION['Role'] != "Staff"){

    header("Location: ../index.php");

    exit();
}


/* Load database connection */
include("../db.php");


/* Retrieve logged-in student information */
$staffID = $_SESSION['UserID'];

$name = $_SESSION['UserName'];




/*=====================================================
    Retrieve Student Profile Picture
=====================================================*/
$staffQuery = mysqli_query(
$conn,
"SELECT Staff_profile
FROM staff
WHERE StaffID='$staffID'"
);

$staff = mysqli_fetch_assoc($staffQuery);



/* Set default profile image if none exists */
$profileImage = !empty($staff['Staff_profile'])
?
"../uploads/profile/".$staff['Staff_profile']
:
"../images/default-profile.png";






/*=====================================================
    Dashboard Statistics

    Count complaints based on their current status.
=====================================================*/

// Pending Complaints

$pendingQuery = mysqli_query($conn,"
SELECT COUNT(*) AS total
FROM complaint
WHERE StaffID='$staffID'
AND Complaint_status='Pending'
");

$pendingRow = mysqli_fetch_assoc($pendingQuery);

$pending = $pendingRow['total'];



// In Progress Complaints

$progressQuery = mysqli_query($conn,"
SELECT COUNT(*) AS total
FROM complaint
WHERE StaffID='$staffID'
AND Complaint_status='In Progress'
");

$progressRow = mysqli_fetch_assoc($progressQuery);

$inProgress = $progressRow['total'];



// Resolved Complaints

$resolvedQuery = mysqli_query($conn,"
SELECT COUNT(*) AS total
FROM complaint
WHERE StaffID='$staffID'
AND Complaint_status='Resolved'
");

$resolvedRow = mysqli_fetch_assoc($resolvedQuery);

$resolved = $resolvedRow['total'];



// Escalated Complaints

$escalatedQuery = mysqli_query($conn,"
SELECT COUNT(*) AS total
FROM complaint
WHERE StaffID='$staffID'
AND Complaint_status='Escalated'
");

$escalatedRow = mysqli_fetch_assoc($escalatedQuery);

$escalated = $escalatedRow['total'];


// Cancelled Complaints

$cancelledQuery = mysqli_query($conn,"
SELECT COUNT(*) AS total
FROM complaint
WHERE StaffID='$staffID'
AND Complaint_status='Cancelled'
");

$cancelledRow = mysqli_fetch_assoc($cancelledQuery);

$cancelled = $cancelledRow['total'];



// Warning Sent Complaints

$warningQuery = mysqli_query($conn,"
SELECT COUNT(*) AS total
FROM complaint
WHERE StaffID='$staffID'
AND Complaint_status='Warning Sent'
");

$warningRow = mysqli_fetch_assoc($warningQuery);

$warning = $warningRow['total'];



// Awaiting Police Complaints

$awaitingQuery = mysqli_query($conn,"
SELECT COUNT(*) AS total
FROM complaint
WHERE StaffID='$staffID'
AND Complaint_status='Awaiting Police'
");

$awaitingRow = mysqli_fetch_assoc($awaitingQuery);

$awaiting = $awaitingRow['total'];



/*=====================================================
    Retrieve the latest five complaints submitted by
    the staff.
=====================================================*/

$recentQuery = mysqli_query(
$conn,
"SELECT
c.ComplaintID,
c.ReferenceNumber,
c.Complaint_status,
c.Complaint_createdAt,
cc.CategoryName,
cs.Subcategory_name
FROM complaint c
INNER JOIN category cc
ON c.CategoryID = cc.CategoryID
INNER JOIN subcategory cs
ON c.SubcategoryID = cs.SubcategoryID
WHERE c.StaffID='$staffID'
ORDER BY c.Complaint_createdAt DESC
LIMIT 5"
);

?>






<!DOCTYPE html>

<html>

<head>

<link rel="icon" type="image/png" href="../images/logo.png">

<title>Staff Dashboard</title>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:Arial,sans-serif;
}

body{
background:#f4f6f9;
}

/* Sidebar */

.sidebar{
width:250px;
height:100vh;
background:#5E2D91;
position:fixed;
left:0;
top:0;
box-shadow:2px 0 10px rgba(0,0,0,0.1);
}

.logo-section{
text-align:center;
padding:20px;
border-bottom:1px solid rgba(255,255,255,0.15);
}

.sidebar-logo{
width:80px;
height:80px;
object-fit:contain;
}

.sidebar h2{
color:white;
font-size:20px;
margin-top:10px;
}

.sidebar a{
display:block;
padding:15px 20px;
color:white;
text-decoration:none;
font-size:15px;
transition:0.3s;
}

.sidebar a:hover{
background:#4b2374;
}

.active{
background:#4b2374;
border-left:5px solid white;
}


/* Topbar */

.topbar{
height:70px;
background:white;
display:flex;
justify-content:flex-end;
align-items:center;
padding:0 30px;
margin-left:250px;
box-shadow:0 2px 10px rgba(0,0,0,0.08);
}

.profile-menu{
display:flex;
align-items:center;
gap:10px;
position:relative;
cursor:pointer;
}

.username{
font-weight:bold;
color:#333;
}

.profile-menu img{
width:45px;
height:45px;
border-radius:50%;
object-fit:cover;
border:2px solid #5E2D91;
}

.dropdown{
display:none;
position:absolute;
right:0;
top:55px;
background:white;
width:180px;
border-radius:10px;
box-shadow:0 5px 15px rgba(0,0,0,0.15);
overflow:hidden;
z-index:9999;
}

.dropdown a{
display:block;
padding:12px 15px;
text-decoration:none;
color:#333;
}

.dropdown a:hover{
background:#f5f5f5;
}

/* Content */

.content{
margin-left:250px;
padding:30px;
}



/* Welcome Card */

.welcome{
background:white;
padding:25px;
border-radius:12px;
box-shadow:0 2px 10px rgba(0,0,0,0.08);
margin-bottom:25px;
}

.welcome h1{
color:#5E2D91;
margin-bottom:10px;
}

.welcome p{
color:#555;
line-height:1.6;
}


/* Cards */

.cards{
display:flex;
gap:20px;
flex-wrap:wrap;
margin-bottom:30px;
}

.card{
background:white;
width:220px;
padding:20px;
border-radius:12px;
box-shadow:0 2px 10px rgba(0,0,0,0.08);
transition:0.3s;
}

.card:hover{
transform:translateY(-3px);
}

.card h3{
font-size:16px;
margin-bottom:10px;
color:#333;
}

.card p{
font-size:30px;
font-weight:bold;
}


/* Card Colors */

.pending{
border-left:5px solid #f39c12;
}

.progress{
border-left:5px solid #1f4e79;
}

.resolved{
border-left:5px solid #27ae60;
}

.escalated{
border-left:5px solid #e74c3c;
}

.cancelled{
border-left:5px solid #7f8c8d;
}

.warning{
border-left:5px solid #9b59b6;
}

.awaiting{
border-left:5px solid #17a2b8;
}


/* Status Text */

.status-pending{
color:#f39c12;
font-weight:bold;
}

.status-progress{
color:#1f4e79;
font-weight:bold;
}

.status-resolved{
color:#27ae60;
font-weight:bold;
}

.status-escalated{
color:#e74c3c;
font-weight:bold;
}

.status-cancelled{
color:#7f8c8d;
font-weight:bold;
}

.status-warning{
color:#9b59b6;
font-weight:bold;
}

.status-awaiting{
color:#17a2b8;
font-weight:bold;
}


/* Table Card */

.recent-card{
background:white;
padding:20px;
border-radius:12px;
box-shadow:0 2px 10px rgba(0,0,0,0.08);
}

.recent-card h3{
color:#5E2D91;
margin-bottom:15px;
}


table{
width:100%;
border-collapse:collapse;
}

th{
background:#5E2D91;
color:white;
padding:12px;
text-align:left;
}

td{
padding:12px;
border-bottom:1px solid #ddd;
}

tbody tr{
transition:0.2s;
}

tbody tr:hover{
background:#f3eef9;
cursor:pointer;
transform:scale(1.003);
}

</style>

</head>

<body>

<!-- Sidebar Navigation -->

<div class="sidebar">

<div class="logo-section">

<img
src="../images/logo.png"
class="sidebar-logo">


<h2>SafeRoad UiTM</h2>

</div>

<a href="dashboard.php" class="active">Dashboard</a>

<a href="submit_complaint_step1.php">Submit Complaint</a>

<a href="my_complaints.php">My Complaints</a>

</div>




<!-- Top Navigation Bar -->

<div class="topbar">

    <div class="profile-menu">

    <span class="username">
    <?php echo $name; ?>
    </span>

    <img
    src="<?php echo $profileImage; ?>"
    alt="Profile"
    onclick="toggleMenu()">


        <div
            id="dropdownMenu"
            class="dropdown">

            <a href="profile.php">My Profile</a>

            <a href="../logout.php">Logout</a>

        </div>

    </div>

</div>




<!-- Dashboard Content -->

<div class="content">

    <div class="welcome">

    <h1>Welcome Back, <?php echo $name; ?></h1>

        <br>

        <p>Monitor your traffic complaints, track progress, and help improve road safety within UiTM Shah Alam.</p>

        <br>

</div>



<!-- Complaint Statistics Cards -->

    <div class="cards">

        <div class="card pending">
        <h3>Pending</h3>
        <p><?php echo $pending; ?></p>
        </div>

        <div class="card progress">
        <h3>In Progress</h3>
        <p><?php echo $inProgress; ?></p>
        </div>

        <div class="card resolved">
        <h3>Resolved</h3>
        <p><?php echo $resolved; ?></p>
        </div>

        <div class="card escalated">
        <h3>Escalated</h3>
        <p><?php echo $escalated; ?></p>
        </div>

        <div class="card cancelled">
        <h3>Cancelled</h3>
        <p><?php echo $cancelled; ?></p>
        </div>

        <div class="card warning">
        <h3>Warning Sent</h3>
        <p><?php echo $warning; ?></p>
        </div>

        <div class="card awaiting">
        <h3>Awaiting Police</h3>
        <p><?php echo $awaiting; ?></p>
        </div>


    </div>
    
<br><br>



<!-- Recent Complaint Table -->

    <div class="recent-card">

    <h3>Recent Complaints</h3>

    <table>

    <tr>

    <th>Reference No</th>

    <th>Category</th>

    <th>Subcategory</th>

    <th>Status</th>

    <th>Date</th>

    </tr>

    <?php

    while($row = mysqli_fetch_assoc($recentQuery)){

    ?>

    <tr
        onclick="window.location='view_complaint.php?id=<?php echo $row['ComplaintID']; ?>';"
        style="cursor:pointer;"
    >

    <td>

    <?php
    echo $row['ReferenceNumber'];
    ?>

    </td>

    <td>

    <?php
    echo $row['CategoryName'];
    ?>

    </td>

    <td>

    <?php
    echo $row['Subcategory_name'];
    ?>

    </td>

       <td>

            <?php

            /* Determine badge colour based on complaint status */
            $statusClass = "";

           if($row['Complaint_status']=="Pending"){
            $statusClass="status-pending";
            }
            elseif($row['Complaint_status']=="In Progress"){
            $statusClass="status-progress";
            }
            elseif($row['Complaint_status']=="Resolved"){
            $statusClass="status-resolved";
            }
            elseif($row['Complaint_status']=="Escalated"){
            $statusClass="status-escalated";
            }
            elseif($row['Complaint_status']=="Cancelled"){
            $statusClass="status-cancelled";
            }
            elseif($row['Complaint_status']=="Warning Sent"){
            $statusClass="status-warning";
            }
            elseif($row['Complaint_status']=="Awaiting Police"){
            $statusClass="status-awaiting";
            }
            ?>

            <span class="<?php echo $statusClass; ?>">

            <?php echo $row['Complaint_status']; ?>

            </span>

        </td>

    <td>

    <?php

    echo date("d M Y",
    strtotime($row['Complaint_createdAt']));

    ?>

    </td>

    </tr>

    <?php } ?>

    </table>

    </div>

</div>




<script>

/*=====================================================
    Toggle Profile Dropdown Menu
=====================================================*/
function toggleMenu(){

var menu = document.getElementById(
"dropdownMenu"
);

if(menu.style.display=="block"){

    menu.style.display="none";

}

else{

        menu.style.display="block";
    }

}


/* Close dropdown menu when clicking outside */
document.addEventListener("click",

function(event){

                    var menu = document.getElementById("dropdownMenu");

                    var profile = document.querySelector(".profile-menu");

                    if(!profile.contains(event.target)){

                        menu.style.display="none";

                    }

                }
);

</script>

</body>

</html>