<?php

session_start();




if(!isset($_SESSION['Role']) || $_SESSION['Role'] != "Staff"){

    header("Location: ../index.php");
    exit();
}




include("../db.php");




$staffID = $_SESSION['UserID'];

$name = $_SESSION['UserName'];


$vehiclePlateNum = $_SESSION['Vehicle_plateNum'] ?? "";
$vehicleType     = $_SESSION['Vehicle_type'] ?? "";
$vehicleColor    = $_SESSION['Vehicle_color'] ?? "";
$vehicleModel    = $_SESSION['Vehicle_model'] ?? "";



$staffQuery = mysqli_query(
$conn,
"SELECT *
FROM staff
WHERE StaffID='$staffID'"
);

$staff = mysqli_fetch_assoc(
$staffQuery
);


$profileImage = !empty($staff['Staff_profile'])
?
"../uploads/profile/".$staff['Staff_profile']
:
"../images/default-profile.png";

?>



<!DOCTYPE html>

<html>

<head>

<link rel="icon" type="image/png" href="../images/logo.png">

<title>Vehicle Information</title>

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:Arial,sans-serif;
}

body{
background:#f4f6f9;
}

/* Sidebar */

.sidebar{
width:250px;
height:100vh;
background:#5E2D91;
position:fixed;
left:0;
top:0;
box-shadow:2px 0 10px rgba(0,0,0,0.1);
}

.logo-section{
text-align:center;
padding:20px;
border-bottom:1px solid rgba(255,255,255,0.15);
}

.sidebar-logo{
width:80px;
height:80px;
object-fit:contain;
}

.sidebar h2{
color:white;
font-size:20px;
margin-top:10px;
}

.sidebar a{
display:block;
padding:15px 20px;
color:white;
text-decoration:none;
font-size:15px;
transition:0.3s;
}

.sidebar a:hover{
background:#4b2374;
}

.active{
background:#4b2374;
border-left:5px solid white;
}

/* Topbar */

.topbar{
height:70px;
background:white;
display:flex;
justify-content:flex-end;
align-items:center;
padding:0 30px;
margin-left:250px;
box-shadow:0 2px 10px rgba(0,0,0,0.08);
}

.profile-menu{
display:flex;
align-items:center;
gap:10px;
position:relative;
cursor:pointer;
}

.username{
font-weight:bold;
color:#333;
}

.profile-menu img{
width:45px;
height:45px;
border-radius:50%;
object-fit:cover;
border:2px solid #5E2D91;
}

.dropdown{
display:none;
position:absolute;
right:0;
top:55px;
background:white;
width:180px;
border-radius:10px;
box-shadow:0 5px 15px rgba(0,0,0,0.15);
overflow:hidden;
z-index:9999;
}

.dropdown a{
display:block;
padding:12px 15px;
text-decoration:none;
color:#333;
}

.dropdown a:hover{
background:#f5f5f5;
}

.container{
width:calc(100% - 320px);
margin-left:280px;
margin-top:30px;
background:white;
padding:30px;
border-radius:10px;
}

.step-bar{
display:flex;
margin-bottom:30px;
}

.step{
flex:1;
padding:12px;
text-align:center;
background:#e9ecef;
margin-right:5px;
border-radius:8px;
}


.form-group{
margin-bottom:20px;
}



input,
select{
width:100%;
padding:12px;
border:1px solid #ccc;
border-radius:5px;
}

.btn{
background:#5E2D91;
color:white;
padding:12px 25px;
border:none;
border-radius:5px;
cursor:pointer;
}

.back-btn{
background:#6c757d;
}


.progress-container{
display:flex;
align-items:center;
justify-content:space-between;
margin-bottom:40px;
}

.progress-step{
text-align:center;
display:flex;
flex-direction:column;
align-items:center;
}

.circle{
width:50px;
height:50px;
border-radius:50%;
background:#d8d8d8;
color:#555;
font-weight:bold;
font-size:18px;
display:flex;
align-items:center;
justify-content:center;
}

.progress-step.current .circle{
background:#5E2D91;
color:white;
box-shadow:0 4px 10px rgba(94,45,145,0.3);
}

.progress-step.completed .circle{
background:#28a745;
color:white;
}

.progress-step p{
margin-top:8px;
font-size:13px;
font-weight:500;
color:#666;
}

.line{
flex:1;
height:3px;
background:#d8d8d8;
margin:0 10px;
margin-bottom:25px;
border-radius:10px;
}

.button-group{
display:flex;
justify-content:space-between;
margin-top:30px;
}

</style>

</head>





<body>

<div class="sidebar">

<div class="logo-section">

<img
src="../images/logo.png"

class="sidebar-logo">



<h2>SafeRoad UiTM</h2>

</div>

<a href="dashboard.php" >Dashboard</a>

<a href="submit_complaint_step1.php" class="active" >Submit Complaint</a>

<a href="my_complaints.php">My Complaints</a>

</div>




<div class="topbar">

<div class="profile-menu">

<span class="username">
<?php echo $name; ?>
</span>

<img
src="<?php echo $profileImage; ?>"
alt="Profile"
onclick="toggleMenu()">


<div
id="dropdownMenu"

class="dropdown">

<a href="profile.php">My Profile</a>

<a href="../logout.php">Logout</a>

</div>

</div>

</div>




<div class="container">

<h2>Submit Complaint</h2>

<p style="
color:#666;
margin-top:10px;
margin-bottom:25px;
">
Step 3 of 5: Enter vehicle information.
</p>

<div class="progress-container">

<div class="progress-step completed">
<div class="circle">1</div>
<p>Details</p>
</div>

<div class="line"></div>

<div class="progress-step completed">
<div class="circle">2</div>
<p>Evidence</p>
</div>

<div class="line"></div>

<div class="progress-step current">
<div class="circle">3</div>
<p>Vehicle</p>
</div>

<div class="line"></div>

<div class="progress-step">
<div class="circle">4</div>
<p>Location</p>
</div>

<div class="line"></div>

<div class="progress-step">
<div class="circle">5</div>
<p>Review</p>
</div>

</div>






<form
action="save_step3.php"
method="POST">




<div class="form-group">

<label>Vehicle Plate Number</label>

<input
type="text"
name="Vehicle_plateNum"
value="<?php echo $vehiclePlateNum; ?>"
placeholder="Example: ABC1234"
maxlength="10"
required>

</div>

<div class="form-group">

<label>Vehicle Type</label>

<select
name="Vehicle_type"
required>

<option value="">
Select Vehicle Type
</option>

<option
value="Car"
<?php if($vehicleType=="Car") echo "selected"; ?>>
Car
</option>

<option
value="Motorcycle"
<?php if($vehicleType=="Motorcycle") echo "selected"; ?>>
Motorcycle
</option>

<option
value="Van"
<?php if($vehicleType=="Van") echo "selected"; ?>>
Van
</option>

<option
value="Bas"
<?php if($vehicleType=="Bas") echo "selected"; ?>>
Bas
</option>

<option
value="Lorry"
<?php if($vehicleType=="Lorry") echo "selected"; ?>>
Lorry
</option>

</select>




<div class="form-group">

<br>

<label>Vehicle Color (Optional)</label>

<input
type="text"
name="Vehicle_color"
value="<?php echo $vehicleColor; ?>"
placeholder="Example: Red"
maxlength="10">

</div>




<div class="form-group">

<br>

<label>Vehicle Model (Optional)</label>

<input
type="text"
name="Vehicle_model"
value="<?php echo $vehicleModel; ?>"
placeholder="Example: Myvi"
maxlength="10">

</div>

</div>




<div class="button-group">

<a
href="submit_complaint_step2.php"
class="btn back-btn"
style="text-decoration:none;">

← Previous

</a>

<button
type="submit"
class="btn">

Next Step →

</button>

</div>

</div>





<script>

function toggleMenu(){

var menu = document.getElementById("dropdownMenu");

if(menu.style.display=="block"){
menu.style.display="none";
}

else{
menu.style.display="block";
}

}

document.addEventListener("click",

function(event){

var menu = document.getElementById("dropdownMenu");

var profile = document.querySelector(".profile-menu");

if(!profile.contains(event.target)){
menu.style.display="none";
}

}
);

</script>


<script>

document.querySelector('input[name="Vehicle_plateNum"]')
.addEventListener('input',

function(){

    this.value = this.value.toUpperCase();

}
);

</script>



</body>

</html>
