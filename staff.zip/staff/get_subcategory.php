<?php

session_start();



include("../db.php");




$categoryID =
$_GET['CategoryID'];



$selectedSubcategory =
$_GET['selected'] ?? "";




$query =
mysqli_query(

$conn,

"SELECT *
FROM subcategory
WHERE CategoryID='$categoryID'
ORDER BY Subcategory_name"

);

echo
"<option value=''>
Select Subcategory
</option>";

while(
$row =
mysqli_fetch_assoc($query)
){

$selected = "";

if(
$row['SubcategoryID']
==
$selectedSubcategory
){
$selected = "selected";
}

echo

"<option value='".$row['SubcategoryID']."' ".$selected.">"

.$row['Subcategory_name'].

"</option>";

}

?>