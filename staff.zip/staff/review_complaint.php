<?php

session_start();



if(!isset($_SESSION['Role']) || $_SESSION['Role']!="Staff"){

    header("Location: ../index.php");
    exit();

}




include("../db.php");



$name = $_SESSION['UserName'];

$staffID = $_SESSION['UserID'];

$categoryID = $_SESSION['CategoryID'];

$subcategoryID = $_SESSION['SubcategoryID'];

$description = $_SESSION['Complaint_desc'];

$vehiclePlateNo = $_SESSION['Vehicle_plateNum'] ?? "";

$vehicleType = $_SESSION['Vehicle_type'] ?? "";

$vehicleColor = $_SESSION['Vehicle_color'] ?? "";

$vehicleModel = $_SESSION['Vehicle_model'] ?? "";

$locationName = $_SESSION['Complaint_locationName'];

$latitude = $_SESSION['Complaint_locationLat'];

$longitude = $_SESSION['Complaint_locationLong'];

$evidence1 = $_SESSION['Evidence1'] ?? "";

$evidence2 = $_SESSION['Evidence2'] ?? "";

$evidence3 = $_SESSION['Evidence3'] ?? "";

$specificLocation = $_SESSION['Complaint_locationDesc'] ?? "";


$staffQuery = mysqli_query(
$conn,
"SELECT *
FROM staff
WHERE StaffID='$staffID'"
);

$staff = mysqli_fetch_assoc(
$staffQuery
);


$profileImage = !empty($staff['Staff_profile'])
?
"../uploads/profile/".$staff['Staff_profile']
:
"../images/default-profile.png";






$categoryQuery = mysqli_query(
$conn,
"SELECT CategoryName
FROM category
WHERE CategoryID='$categoryID'"
);

$category = mysqli_fetch_assoc(
$categoryQuery
);





$subcategoryQuery = mysqli_query(
$conn,
"SELECT Subcategory_name
FROM subcategory
WHERE SubcategoryID='$subcategoryID'"
);

$subcategory = mysqli_fetch_assoc(
$subcategoryQuery
);

?>


<!DOCTYPE html>

<html>

<head>

<link rel="icon" type="image/png" href="../images/logo.png">

<link
rel="stylesheet"
href="https://unpkg.com/leaflet/dist/leaflet.css">

<script
src="https://unpkg.com/leaflet/dist/leaflet.js">
</script>


<title>Location</title>

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:Arial,sans-serif;
}

body{
background:#f4f6f9;
}

/* Sidebar */

.sidebar{
width:250px;
height:100vh;
background:#5E2D91;
position:fixed;
left:0;
top:0;
box-shadow:2px 0 10px rgba(0,0,0,0.1);
}

.logo-section{
text-align:center;
padding:20px;
border-bottom:1px solid rgba(255,255,255,0.15);
}

.sidebar-logo{
width:80px;
height:80px;
object-fit:contain;
}

.sidebar h2{
color:white;
font-size:20px;
margin-top:10px;
}

.sidebar a{
display:block;
padding:15px 20px;
color:white;
text-decoration:none;
font-size:15px;
transition:0.3s;
}

.sidebar a:hover{
background:#4b2374;
}

.active{
background:#4b2374;
border-left:5px solid white;
}

/* Topbar */

.topbar{
height:70px;
background:white;
display:flex;
justify-content:flex-end;
align-items:center;
padding:0 30px;
margin-left:250px;
box-shadow:0 2px 10px rgba(0,0,0,0.08);
}

.profile-menu{
display:flex;
align-items:center;
gap:10px;
position:relative;
cursor:pointer;
}

.username{
font-weight:bold;
color:#333;
}

.profile-menu img{
width:45px;
height:45px;
border-radius:50%;
object-fit:cover;
border:2px solid #5E2D91;
}

.dropdown{
display:none;
position:absolute;
right:0;
top:55px;
background:white;
width:180px;
border-radius:10px;
box-shadow:0 5px 15px rgba(0,0,0,0.15);
overflow:hidden;
z-index:9999;
}

.dropdown a{
display:block;
padding:12px 15px;
text-decoration:none;
color:#333;
}

.dropdown a:hover{
background:#f5f5f5;
}

.container{
width:calc(100% - 320px);
margin-left:280px;
margin-top:30px;
background:white;
padding:30px;
border-radius:10px;
}

.step-bar{
display:flex;
margin-bottom:30px;
}

.step{
flex:1;
padding:12px;
text-align:center;
background:#e9ecef;
margin-right:5px;
border-radius:8px;
}

.form-group{
margin-bottom:20px;
}

input,
select{
width:100%;
padding:12px;
border:1px solid #ccc;
border-radius:5px;
}

.btn{
background:#5E2D91;
color:white;
padding:12px 25px;
border:none;
border-radius:5px;
cursor:pointer;
}

.back-btn{
background:#6c757d;
}

.container{
width:calc(100% - 320px);
margin-left:280px;
margin-top:30px;
background:white;
padding:30px;
border-radius:10px;
}

.progress-container{
display:flex;
align-items:center;
justify-content:space-between;
margin-bottom:40px;
}

.progress-step{
text-align:center;
display:flex;
flex-direction:column;
align-items:center;
}

.circle{
width:50px;
height:50px;
border-radius:50%;
background:#d8d8d8;
color:#555;
font-weight:bold;
font-size:18px;
display:flex;
align-items:center;
justify-content:center;
}

.progress-step.current .circle{
background:#5E2D91;
color:white;
box-shadow:0 4px 10px rgba(94,45,145,0.3);
}

.progress-step.completed .circle{
background:#28a745;
color:white;
}

.progress-step p{
margin-top:8px;
font-size:13px;
font-weight:500;
color:#666;
}

.line{
flex:1;
height:3px;
background:#d8d8d8;
margin:0 10px;
margin-bottom:25px;
border-radius:10px;
}

.button-group{
display:flex;
justify-content:space-between;
margin-top:30px;
}


.evidence-gallery{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(150px,1fr));
    gap:15px;
    margin-top:15px;
}


.preview-image,
.preview-video{

width:100%;
height:150px;

object-fit:cover;

border-radius:10px;

border:1px solid #ddd;

transition:.25s;

}

.preview-image:hover,
.preview-video:hover{
transform:scale(1.04);
box-shadow:0 6px 18px rgba(0,0,0,.18);
}



.review-card{
background:#fafafa;
border-left:5px solid #5E2D91;
padding:20px;
margin-bottom:20px;
border-radius:10px;
box-shadow:0 2px 8px rgba(0,0,0,0.08);
}

.info-table{
    width:100%;
    border-collapse:collapse;
    margin-top:10px;
}

.info-table td{
    padding:12px 8px;
    border-bottom:1px solid #ececec;
    vertical-align:top;
}

.info-table td:first-child{
    width:170px;
    font-weight:bold;
    color:#555;
}

.info-table td:last-child{
    color:#333;
}



.review-card h3{
margin-bottom:15px;
color:#5E2D91;
}

.review-card p{
margin-bottom:10px;
line-height:1.6;
}


.review-grid{
    display:grid;
    grid-template-columns:42% 58%;
    gap:25px;
    align-items:start;
}

.left-column{
    display:flex;
    flex-direction:column;
    gap:20px;
}

.right-column{
    display:flex;
    flex-direction:column;
}


#reviewMap{
    width:100%;
    height:500px;
    border-radius:12px;
    margin-top:20px;
    border:2px solid #e5e5e5;
    overflow:hidden;
}


.review-banner{
    background:#eef4ff;
    border-left:6px solid #5E2D91;
    padding:22px;
    border-radius:12px;
    margin-bottom:25px;
    box-shadow:0 2px 8px rgba(0,0,0,.08);
}

.review-banner h2{
    color:#5E2D91;
    margin-bottom:8px;
    font-size:26px;
}

.review-banner p{
    color:#555;
    line-height:1.6;
    margin:0;
}

.review-banner .note{
    margin-top:15px;
    background:#fff;
    border:1px solid #ddd;
    border-radius:8px;
    padding:12px 15px;
    color:#666;
    font-size:14px;
}

.card-header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:15px;
}

</style>

</head>





<body>

<div class="sidebar">

<div class="logo-section">

<img
src="../images/logo.png"

class="sidebar-logo">




<h2>SafeRoad UiTM</h2>

</div>

<a href="dashboard.php" >Dashboard</a>

<a href="submit_complaint_step1.php" class="active" >Submit Complaint</a>

<a href="my_complaints.php">My Complaints</a>

</div>




<div class="topbar">

<div class="profile-menu">

<span class="username">
<?php echo $name; ?>
</span>

<img
src="<?php echo $profileImage; ?>"
alt="Profile"
onclick="toggleMenu()">


<div
id="dropdownMenu"

class="dropdown">

<a href="profile.php">My Profile</a>

<a href="../logout.php">Logout</a>

</div>

</div>

</div>





<div class="container">

<div class="progress-container">

<div class="progress-step completed">
<div class="circle">1</div>
<p>Details</p>
</div>

<div class="line"></div>

<div class="progress-step completed">
<div class="circle">2</div>
<p>Evidence</p>
</div>

<div class="line"></div>

<div class="progress-step completed">
<div class="circle">3</div>
<p>Vehicle</p>
</div>

<div class="line"></div>

<div class="progress-step completed">
<div class="circle">4</div>
<p>Location</p>
</div>

<div class="line"></div>

<div class="progress-step current">
<div class="circle">5</div>
<p>Review</p>
</div>
</div>




<div class="review-banner">

<h2>✅ Review Your Complaint</h2>

<p>

You are almost done!

Please review all the information carefully before submitting your complaint. Once submitted, your complaint will be processed by the SafeRoad UiTM system.

</p>

<div class="note">

<strong>Before submitting, please ensure that:</strong>

<ul style="margin-top:10px;padding-left:20px;line-height:1.8;">

<li>All complaint details are accurate.</li>

<li>The selected location is correct.</li>

<li>The uploaded evidence is clear and relevant.</li>

<li>Vehicle information is correct.</li>

</ul>

</div>

</div>





<div class="review-grid">

<div class="left-column">

<div class="review-card">

<h3>📝 Complaint Summary</h3>

<table class="info-table">

<tr>
<td>Category</td>
<td><?php echo $category['CategoryName']; ?></td>
</tr>

<tr>
<td>Subcategory</td>
<td><?php echo $subcategory['Subcategory_name']; ?></td>
</tr>

<tr>
<td>Description</td>
<td><?php echo nl2br(htmlspecialchars($description)); ?></td>
</tr>

<?php
if(
!empty($vehiclePlateNo)
||
!empty($vehicleType)
||
!empty($vehicleColor)
||
!empty($vehicleModel)
){
?>

<tr>
<td colspan="2">

<hr style="margin:10px 0;border:0;border-top:1px solid #ddd;">

<strong style="color:#5E2D91;">

🚗 Vehicle Information

</strong>

</td>

</tr>

<?php
function displayValue($value){
    return !empty(trim($value)) ? htmlspecialchars($value) : "-";
}
?>

<tr>
<td>Plate Number</td>
<td><?php echo displayValue($vehiclePlateNo); ?></td>
</tr>

<tr>
<td>Vehicle Type</td>
<td><?php echo displayValue($vehicleType); ?></td>
</tr>

<tr>
<td>Vehicle Colour</td>
<td><?php echo displayValue($vehicleColor); ?></td>
</tr>

<tr>
<td>Vehicle Model</td>
<td><?php echo displayValue($vehicleModel); ?></td>
</tr>

<?php
}
?>

</table>




<hr style="margin:25px 0;border:0;border-top:1px solid #ddd;">

<div class="card-header">


<h3 style="margin:0;">
📷 Evidence
</h3>

<span
style="
background:#eef4ff;
color:#5E2D91;
padding:6px 12px;
border-radius:20px;
font-size:12px;
font-weight:bold;">

Upload Evidence

</span>

</div>


<div class="evidence-gallery">


<?php if($evidence1!=""){ ?>

<?php
$extension = strtolower(pathinfo($evidence1, PATHINFO_EXTENSION));

if(in_array($extension,['jpg','jpeg','png','gif','webp'])){
?>

<img
src="../uploads/evidence/<?php echo $evidence1; ?>"
class="preview-image"
onclick="window.open(this.src)">

<?php
}
else{
?>

<video
controls
class="preview-video">
    <source
    src="../uploads/evidence/<?php echo $evidence1; ?>">
</video>

<?php
}
?>

<?php } ?>




<?php if($evidence2!=""){ ?>

<?php
$extension = strtolower(pathinfo($evidence2, PATHINFO_EXTENSION));

if(in_array($extension,['jpg','jpeg','png','gif','webp'])){
?>

<img
src="../uploads/evidence/<?php echo $evidence2; ?>"
class="preview-image"
onclick="window.open(this.src)">

<?php
}
else{
?>

<video
controls
class="preview-video">
    <source
    src="../uploads/evidence/<?php echo $evidence2; ?>">
</video>

<?php
}
?>

<?php } ?>




<?php if($evidence3!=""){ ?>

<?php
$extension = strtolower(pathinfo($evidence3, PATHINFO_EXTENSION));

if(in_array($extension,['jpg','jpeg','png','gif','webp'])){
?>

<img
src="../uploads/evidence/<?php echo $evidence3; ?>"
class="preview-image"
onclick="window.open(this.src)">

<?php
}
else{
?>

<video
controls
class="preview-video">
    <source
    src="../uploads/evidence/<?php echo $evidence3; ?>">
</video>

<?php
}
?>

<?php } ?>

</div>

</div>

</div>



<div class="right-column">

<div class="review-card">

<div class="card-header">

<h3 style="margin:0;">

📍 Location Information

</h3>

<span
style="
background:#eef4ff;
color:#5E2D91;
padding:6px 12px;
border-radius:20px;
font-size:12px;
font-weight:bold;">

Map Preview

</span>

</div>


<table class="info-table">

<tr>
<td>Location</td>
<td><?php echo htmlspecialchars($locationName); ?></td>
</tr>

<tr>
<td>Specific Location</td>
<td>

<?php

if(empty($specificLocation)){

    echo "<span style='color:#888;'>Not provided</span>";

}else{

    echo nl2br(htmlspecialchars($specificLocation));

}

?>

</td>
</tr>

</table>

<div id="reviewMap"></div>

</div>

</div>

</div>



<form
action="submit_complaint_final.php"
method="POST">

<div class="button-group">

<a
href="submit_complaint_step4.php"
class="btn back-btn"
style="text-decoration:none;">

← Previous

</a>

<button
type="submit"
class="btn">

Submit Complaint

</button>

</div>

</form>

</div>





<script>

var lat = <?php echo $latitude; ?>;
var lon = <?php echo $longitude; ?>;

var map = L.map('reviewMap').setView([lat, lon], 17);

L.tileLayer(
'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
{
    attribution:'© OpenStreetMap contributors'
}
).addTo(map);

L.marker([lat, lon]).addTo(map);

</script>




</body>

</html>








