<?php

session_start();

$_SESSION['Complaint_locationLat'] =
$_POST['Complaint_locationLat'];

$_SESSION['Complaint_locationLong'] =
$_POST['Complaint_locationLong'];

$_SESSION['Complaint_locationName'] =
$_POST['Complaint_locationName'];

$_SESSION['Complaint_locationDesc'] =
$_POST['Complaint_locationDesc'];

header(
"Location: review_complaint.php"
);

exit();

?>