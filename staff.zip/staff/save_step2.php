<?php

session_start();




$uploadPath =
"../uploads/evidence/";


if(!empty($_FILES['evidence1']['name'])){

$file1 = uniqid()."_".$_FILES['evidence1']['name'];

if(
move_uploaded_file(
$_FILES['evidence1']['tmp_name'],
$uploadPath.$file1
)
){
    $_SESSION['Evidence1']=$file1;
}

}



if(!empty($_FILES['evidence2']['name'])){

$file2 = uniqid()."_".$_FILES['evidence2']['name'];

if(
move_uploaded_file(
$_FILES['evidence2']['tmp_name'],
$uploadPath.$file2
)
){
    $_SESSION['Evidence2']=$file2;
}

}



if(!empty($_FILES['evidence3']['name'])){

$file3 = uniqid()."_".$_FILES['evidence3']['name'];

if(
move_uploaded_file(
$_FILES['evidence3']['tmp_name'],
$uploadPath.$file3
)
){
    $_SESSION['Evidence3']=$file3;
}

}




header(
"Location: submit_complaint_step3.php"
);

exit();

?>