<?php

session_start();

$_SESSION['CategoryID'] =
$_POST['CategoryID'];

$_SESSION['SubcategoryID'] =
$_POST['SubcategoryID'];

$_SESSION['Complaint_desc'] =
$_POST['Complaint_desc'];

header(
"Location: submit_complaint_step2.php"
);

exit();

?>