<?php

session_start();




date_default_timezone_set('Asia/Kuala_Lumpur');


$name = $_SESSION['UserName'];

if(!isset($_SESSION['Role'])){

    header("Location: ../index.php");
    exit();
}




include("../db.php");




$role = $_SESSION['Role'];

$userID = $_SESSION['UserID'];



if($role == "Staff")
{

$sql = "

SELECT
c.*,
cc.CategoryName,
cs.Subcategory_name,
cs.Subcategory_risk
FROM complaint c
INNER JOIN category cc
ON c.CategoryID = cc.CategoryID
INNER JOIN subcategory cs
ON c.SubcategoryID = cs.SubcategoryID
WHERE c.StaffID='$userID'
ORDER BY c.Complaint_createdAt DESC
";
}

else
{

$sql = "

SELECT
c.*,
cc.Category_name,
cs.Subcategory_name
FROM complaint c
INNER JOIN category cc
ON c.CategoryID = cc.CategoryID
INNER JOIN subcategory cs
ON c.SubcategoryID = cs.SubcategoryID
WHERE c.StaffID='$userID'
ORDER BY c.Complaint_createdAt DESC
";
}

$complaints = mysqli_query(
$conn,
$sql
);




$staffID = $_SESSION['UserID'];

$staffQuery = mysqli_query(
$conn,

"SELECT *
FROM staff
WHERE StaffID='$staffID'"
);

$staff = mysqli_fetch_assoc(
$staffQuery
);


$profileImage = !empty($staff['Staff_profile'])
?
"../uploads/profile/".$staff['Staff_profile']
:
"../images/default-profile.png";

?>




<!DOCTYPE html>

<html>

<head>

<link rel="icon" type="image/png" href="../images/logo.png">

<title>My Complaints</title>

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:Arial,sans-serif;
}


/* Sidebar */

.sidebar{
width:250px;
height:100vh;
background:#5E2D91;
position:fixed;
left:0;
top:0;
box-shadow:2px 0 10px rgba(0,0,0,0.1);
}

.logo-section{
text-align:center;
padding:20px;
border-bottom:1px solid rgba(255,255,255,0.15);
}

.sidebar-logo{
width:80px;
height:80px;
object-fit:contain;
}

.sidebar h2{
color:white;
font-size:20px;
margin-top:10px;
}

.sidebar a{
display:block;
padding:15px 20px;
color:white;
text-decoration:none;
font-size:15px;
transition:0.3s;
}

.sidebar a:hover{
background:#4b2374;
}

.active{
background:#4b2374;
border-left:5px solid white;
}




/* Topbar */

.topbar{
height:70px;
background:white;
display:flex;
justify-content:flex-end;
align-items:center;
padding:0 30px;
margin-left:250px;
box-shadow:0 2px 10px rgba(0,0,0,0.08);
}

.profile-menu{
display:flex;
align-items:center;
gap:10px;
position:relative;
cursor:pointer;
}

.username{
font-weight:bold;
color:#333;
}

.profile-menu img{
width:45px;
height:45px;
border-radius:50%;
object-fit:cover;
border:2px solid #5E2D91;
}

.dropdown{
display:none;
position:absolute;
right:0;
top:55px;
background:white;
width:180px;
border-radius:10px;
box-shadow:0 5px 15px rgba(0,0,0,0.15);
overflow:hidden;
z-index:9999;
}

.dropdown a{
display:block;
padding:12px 15px;
text-decoration:none;
color:#333;
}

.dropdown a:hover{
background:#f5f5f5;
}

.container{
width:calc(100% - 320px);
margin-left:280px;
margin-top:30px;
background:white;
padding:30px;
border-radius:10px;
}

body{
font-family:Arial,sans-serif;
background:#f5f5f5;
margin:0;
padding:0;
}

h2{
color:#5E2D91;
margin-bottom:20px;
}

.stats{
display:flex;
gap:15px;
margin-bottom:25px;
}

.card{
flex:1;
background:white;
padding:20px;
border-radius:10px;
box-shadow:0 2px 8px rgba(0,0,0,0.1);
text-align:center;
}

.card h3{
margin-bottom:10px;
color:#5E2D91;
}

table{
width:100%;
background:white;
border-collapse:collapse;
border-radius:10px;
overflow:hidden;
box-shadow:0 2px 8px rgba(0,0,0,0.1);
}

th{
background:#5E2D91;
color:white;
padding:12px;
}

td{
padding:12px;
border-bottom:1px solid #ddd;
}

.badge{
padding:6px 12px;
border-radius:20px;
color:white;
font-size:13px;
font-weight:bold;
}



.pending{
background:#f39c12;
}

.progress{
background:#3498db;
}

.resolved{
background:#27ae60;
}

.escalated{
background:#e74c3c;
}

.cancelled{
background:#7f8c8d;
}

.warning{
background:#9b59b6;
}

.awaiting{
background:#20c997;
}

.btn{
background:#5E2D91;
color:white;
padding:8px 15px;
text-decoration:none;
border-radius:5px;
}

.btn:hover{
background:#4b2374;
}



.content{
margin-left:250px;
padding:30px;
}



.search-box{
margin-bottom:20px;
}

.search-box input{
width:300px;
padding:10px;
border:1px solid #ccc;
border-radius:5px;
}





.page-header{
margin-bottom:25px;
}

.page-header h2{
margin-bottom:5px;

}

.page-header p{
color:#666;

}

</style>

</head>






<body>

<div class="sidebar">

<div class="logo-section">

<img
src="../images/logo.png"
class="sidebar-logo">



<h2>SafeRoad UiTM</h2>

</div>

<a href="dashboard.php" >Dashboard</a>

<a href="submit_complaint_step1.php">Submit Complaint</a>

<a href="my_complaints.php" class="active" >My Complaints</a>

</div>




<div class="topbar">

<div class="profile-menu">

<span class="username">
<?php echo $name; ?>
</span>

<img
src="<?php echo $profileImage; ?>"
alt="Profile"
onclick="toggleMenu()">


<div
id="dropdownMenu"
class="dropdown">

<a href="profile.php">My Profile</a>

<a href="../logout.php">Logout</a>

</div>

</div>

</div>







<div class="content">

<div class="page-header">

<div>

<h2>My Complaints</h2>

<p>

View and track all complaints you have submitted.

</p>

</div>

</div>

<?php

?>


<div class="search-box">

<input
type="text"
id="searchInput"
placeholder="Search...">

</div>



<table>

<tr>

<th>Reference No</th>

<th>Category</th>

<th>Subcategory</th>

<th>Status</th>

<th>Location</th>

<th>Date</th>

<th>Action</th>

</tr>

<?php

if(mysqli_num_rows($complaints) > 0){

while($row = mysqli_fetch_assoc($complaints)){

$statusClass = "";

switch($row['Complaint_status']){

case "Pending":
$statusClass = "pending";
break;

case "In Progress":
$statusClass = "progress";
break;

case "Resolved":
$statusClass = "resolved";
break;

case "Escalated":
$statusClass = "escalated";
break;

case "Cancelled":
$statusClass = "cancelled";
break;

case "Warning Sent":
$statusClass = "warning";
break;

case "Awaiting Police":
$statusClass = "awaiting";
break;

}

?>

<tr
    class="data-row"
    onclick="window.location='view_complaint.php?id=<?php echo $row['ComplaintID']; ?>';"
    style="cursor:pointer;"
>

<td>
<?php echo $row['ReferenceNumber']; ?>
</td>

<td>
<?php echo $row['CategoryName']; ?>
</td>

<td>
<?php echo $row['Subcategory_name']; ?>
</td>


<td>
<span class="badge <?php echo $statusClass; ?>">

<?php echo $row['Complaint_status']; ?>

</span>
</td>


<td>
<?php echo $row['Complaint_locationName']; ?>
</td>


<td>
<?php

echo date("d M Y",
strtotime($row['Complaint_createdAt']));

?>
</td>


<td>

<a
href="view_complaint.php?id=<?php echo $row['ComplaintID']; ?>"
class="btn">

View

</a>
</td>
</tr>

<?php
}
?>

<tr id="noResultRow" style="display:none;">

<td colspan="7" style="text-align:center;padding:30px;">

No complaints found.

</td>

</tr>

<?php

}

?>


</table>

</div>





<script>

    document.getElementById("searchInput").addEventListener("keyup", function(){

    var value = this.value.toLowerCase();

    var rows = document.querySelectorAll("tr.data-row");

    var found = false;

    rows.forEach(function(row){

        if(row.innerText.toLowerCase().includes(value)){

            row.style.display = "";
            found = true;

        }else{

            row.style.display = "none";

        }

    });

    document.getElementById("noResultRow").style.display =
        found ? "none" : "";

});

</script>





<script>

function toggleMenu(){

var menu = document.getElementById("dropdownMenu");

if(menu.style.display=="block"){

    menu.style.display="none";

}

else{

    menu.style.display="block";
}

}

document.addEventListener("click",

function(event){

var menu = document.getElementById("dropdownMenu");

var profile = document.querySelector(".profile-menu");

if(!profile.contains(event.target)){

    menu.style.display="none";
}

}
);

</script>






</body>

</html>