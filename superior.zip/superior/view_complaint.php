<?php

session_start();


date_default_timezone_set('Asia/Kuala_Lumpur');


if(!isset($_SESSION['Role']) ||$_SESSION['Role'] != "Superior"){

    header("Location: ../index.php");

    exit();
}




include("../db.php");



$superiorID = $_SESSION['UserID'];

$name = $_SESSION['UserName'];




$superiorQuery = mysqli_query(
$conn,
"SELECT Superior_profile
FROM superior
WHERE SuperiorID='$superiorID'"
);

$superior = mysqli_fetch_assoc($superiorQuery);



$profileImage = !empty($superior['Superior_profile'])
?
"../uploads/profile/".$superior['Superior_profile']
:
"../images/default-profile.png";




if(!isset($_GET['id'])){

    header("Location: manage_escalated.php");
    exit();
}




$complaintID = mysqli_real_escape_string(
$conn,
$_GET['id']
);


$query =mysqli_query(
$conn,
"SELECT
c.*,
cc.CategoryName,
cs.Subcategory_name,
cs.Subcategory_risk
FROM complaint c
INNER JOIN category cc
ON c.CategoryID = cc.CategoryID
INNER JOIN subcategory cs
ON c.SubcategoryID = cs.SubcategoryID
WHERE c.ComplaintID='$complaintID'"
);

$complaint = mysqli_fetch_assoc(
$query
);

if(!$complaint){

    die("Complaint not found.");
}


$complainant = [];
$type = "";

if(!empty($complaint['StudentID'])){

$type = "Student";



$studentQuery = mysqli_query(
$conn,
"SELECT *
FROM student
WHERE StudentID='
".$complaint['StudentID']."'"
);

$complainant = mysqli_fetch_assoc(
$studentQuery
);

}


else{

$type = "Staff";

$staffQuery = mysqli_query(
$conn,
"SELECT *
FROM staff
WHERE StaffID='
".$complaint['StaffID']."'"
);

$complainant = mysqli_fetch_assoc(
$staffQuery
);

}



$vehicleQuery = mysqli_query(
$conn,
"SELECT *
FROM complaintvehicle
WHERE ComplaintID='$complaintID'"
);

$vehicle = mysqli_fetch_assoc($vehicleQuery);




$evidenceQuery = mysqli_query(
$conn,
"SELECT *
FROM evidence
WHERE ComplaintID='$complaintID'"
);




$timelineQuery = mysqli_query(
$conn,
"SELECT *
FROM complaint_timeline
WHERE ComplaintID='$complaintID'
ORDER BY TimelineDate ASC"
);




$latestTimelineQuery = mysqli_query(
$conn,
"SELECT *
FROM complaint_timeline
WHERE ComplaintID='$complaintID'
ORDER BY TimelineDate DESC
LIMIT 1"
);

$latestTimeline = mysqli_fetch_assoc(
$latestTimelineQuery
);




$statusClass = "";

switch($complaint['Complaint_status']){

case "Pending":
$statusClass = "pending";
break;

case "In Progress":
$statusClass = "progress";
break;

case "Resolved":
$statusClass = "resolved";
break;

case "Escalated":
$statusClass = "escalated";
break;

}


$daysOverdue = max(0,floor((time()
-
strtotime($complaint['Complaint_deadline']))/86400));


$escalationReason = "";

if(empty($complaint['PoliceID'])){

    $escalationReason =
    "No auxiliary police was assigned before the complaint reached its resolution deadline.";

}

else{

    $policeQuery = mysqli_query(
        $conn,
        "SELECT *
        FROM auxiliary_police
        WHERE PoliceID='".
        $complaint['PoliceID']."'"
    );

    $police = mysqli_fetch_assoc(
    $policeQuery
    );

    $escalationReason =

    "The complaint exceeded its resolution deadline by <b>"

    .$daysOverdue.

    " day(s)</b> while assigned to <b>"

    .$police['Police_fullName'].

    "</b>. No successful resolution was recorded before the deadline.";

}

?>







<!DOCTYPE html>

<html>

<head>

<link rel="icon" type="image/png" href="../images/logo.png">

<link rel="stylesheet"
href="https://unpkg.com/leaflet/dist/leaflet.css">

<script
src="https://unpkg.com/leaflet/dist/leaflet.js"></script>

<title>Escalated Complaints</title>

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:Arial,sans-serif;
}

body{
background:#f4f6f9;
}

/* Sidebar */

.sidebar{
width:250px;
height:100vh;
background:#5E2D91;
position:fixed;
left:0;
top:0;
box-shadow:2px 0 10px rgba(0,0,0,0.1);
}

.logo-section{
text-align:center;
padding:20px;
border-bottom:1px solid rgba(255,255,255,0.15);
}

.sidebar-logo{
width:80px;
height:80px;
object-fit:contain;
}

.sidebar h2{
color:white;
font-size:20px;
margin-top:10px;
}

.sidebar a{
display:block;
padding:15px 20px;
color:white;
text-decoration:none;
font-size:15px;
transition:0.3s;
}

.sidebar a:hover{
background:#4b2374;
}

.active{
background:#4b2374;
border-left:5px solid white;
}

/* Topbar */

.topbar{
height:70px;
background:white;
display:flex;
justify-content:flex-end;
align-items:center;
padding:0 30px;
margin-left:250px;
box-shadow:0 2px 10px rgba(0,0,0,0.08);
}

.profile-menu{
display:flex;
align-items:center;
gap:10px;
position:relative;
cursor:pointer;
}

.username{
font-weight:bold;
color:#333;
}

.profile-menu img{
width:45px;
height:45px;
border-radius:50%;
object-fit:cover;
border:2px solid #5E2D91;
}

.dropdown{
display:none;
position:absolute;
right:0;
top:55px;
background:white;
width:180px;
border-radius:10px;
box-shadow:0 5px 15px rgba(0,0,0,0.15);
overflow:hidden;
z-index:9999;
}

.dropdown a{
display:block;
padding:12px 15px;
text-decoration:none;
color:#333;
}

.dropdown a:hover{
background:#f5f5f5;
}

/* Content */

.content{
margin-left:250px;
padding:30px;
}

.sidebar{

z-index:1000;

}

.content{

position:relative;

z-index:1;

}


table{
width:100%;
background:white;
border-collapse:collapse;
border-radius:10px;
overflow:hidden;
box-shadow:0 2px 10px rgba(0,0,0,0.1);
}

th{
background:#5E2D91;
color:white;
padding:12px;
}

td{
padding:12px;
border-bottom:1px solid #ddd;
}


td:first-child{
width:220px;
font-weight:bold;
background:#fafafa;
}

.btn{
background:#5E2D91;
color:white;
padding:8px 15px;
text-decoration:none;
border-radius:5px;
}

.btn:hover{
background:#4b2374;
}

.badge{
padding:5px 12px;
border-radius:20px;
color:white;
font-size:13px;
font-weight:bold;
}




.pending{
background:#f39c12;
}

.progress{
background:#3498db;
}

.resolved{
background:#27ae60;
}

.escalated{
background:#e74c3c;
}



.card{
background:white;
padding:20px;
border-radius:10px;
margin-bottom:20px;
box-shadow:0 2px 10px rgba(0,0,0,0.1);
}


#map{
height:400px;
width:100%;
}



.dashboard-header{
background:white;
padding:25px 30px;
border-radius:15px;
margin-bottom:25px;
box-shadow:0 2px 10px rgba(0,0,0,0.08);
border-left:5px solid #5E2D91;
}

.dashboard-header h1{
margin-bottom:8px;
font-size:38px;
}

.dashboard-header p{
color:#666;
margin:0;
}



.timeline{
    position:relative;
    margin-top:20px;
    margin-left:20px;
}

.timeline-item{
    display:flex;
    align-items:flex-start;
    gap:20px;
    margin-bottom:25px;
    position:relative;
}

.timeline-item::before{
    content:"";
    position:absolute;
    left:14px;
    top:30px;
    width:3px;
    height:calc(100% + 20px);
    background:#d8d8d8;
}

.timeline-item:last-child::before{
    display:none;
}

.timeline-icon{
    flex-shrink:0;

    width:30px;
    height:30px;

    border-radius:50%;

    background:#5E2D91;
    color:white;

    display:flex;
    justify-content:center;
    align-items:center;

    font-weight:bold;
}
.timeline-content{
    background:#fafafa;
    padding:15px;
    border-radius:10px;
    box-shadow:0 2px 6px rgba(0,0,0,.08);

    width:calc(100% - 70px);
}


.evidence{
width:250px;
height:180px;
object-fit:cover;
margin:10px;
border-radius:10px;
border:1px solid #ddd;
}


</style>

</head>

<body>

<div class="sidebar">

    <div class="logo-section">

        <img
        src="../images/logo.png"
        class="sidebar-logo">

        <h2>SafeRoad UiTM</h2>

        <p class="sidebar-role">
            Superior
        </p>

    </div>

         <a
        href="dashboard.php">

        Dashboard

        </a>

        <a href="manage_escalated.php"class="active">
        Escalated Complaints
        </a>

        <a href="police_performance.php">
        Police Performance
        </a>


        <a href="heatmap.php">
        Complaint Heatmap
        </a>

</div>






<div class="topbar">

    <div class="profile-menu">

        <span class="username">
            <?php echo $name; ?>
        </span>

        <img
        src="<?php echo $profileImage; ?>"
        alt="Profile"
        onclick="toggleMenu()">

        <div
        id="dropdownMenu"
        class="dropdown">

            <a href="profile.php">
                My Profile
            </a>

            <a href="../logout.php">
                Logout
            </a>

        </div>

    </div>

</div>








<div class="content">

<div class="dashboard-header">

<h1>Complaint Details</h1>

<p>Manage escalated complaints.</p>

</div>






<div class="card">

<a
href="manage_escalated.php"
style="
display:inline-block;
margin-bottom:15px;
background:#5E2D91;
color:white;
padding:10px 15px;
text-decoration:none;
border-radius:5px;">

← Back to Escalated Complaints

</a>

<h2>Complainant Information</h2>

<br>


<table>

<?php if($type=="Student"){ ?>

<tr>
<td>Name</td>
<td><?php echo $complainant['Student_fullName']; ?></td>
</tr>

<tr>
<td>Role</td>
<td><?php echo $type; ?></td>
</tr>

<tr>
<td>Matric Number</td>
<td><?php echo $complainant['Student_matricNum']; ?></td>
</tr>

<tr>
<td>Email</td>
<td><?php echo $complainant['Student_email']; ?></td>
</tr>

<tr>
<td>Phone Number</td>
<td><?php echo $complainant['Student_phoneNumber']; ?></td>
</tr>

<?php } 

else { ?>





<tr>
<td>Name</td>
<td><?php echo $complainant['Staff_fullName']; ?></td>
</tr>

<tr>
<td>Complaint Type</td>
<td><?php echo $type; ?></td>
</tr>

<tr>
<td>Staff Number</td>
<td><?php echo $complainant['Staff_Num']; ?></td>
</tr>

<tr>
<td>Email</td>
<td><?php echo $complainant['Staff_email']; ?></td>
</tr>

<tr>
<td>Phone Number</td>
<td><?php echo $complainant['Staff_phoneNumber']; ?></td>
</tr>

<?php } ?>

</table>

</div>





<div class="card">

<h2>Complaint Information</h2>

<br>

<?php

if(
$complaint['Complaint_status']=="Resolved"
){
?>

<p
style="
padding:15px;
background:#d4edda;
color:#155724;
border-radius:5px;
margin-bottom:15px;">

✅ This complaint has been resolved.

</p>

<?php } ?>

<table>

<tr>
<td>Reference Number</td>
<td><?php echo $complaint['ReferenceNumber']; ?></td>
</tr>

<tr>
<td>Category</td>
<td><?php echo $complaint['CategoryName']; ?></td>
</tr>

<tr>
<td>Subcategory</td>
<td><?php echo $complaint['Subcategory_name']; ?></td>
</tr>

<tr>
<td>Description</td>
<td>

<?php echo nl2br($complaint['Complaint_desc']); ?>

</td>
</tr>

<tr>
<td>Risk Level</td>
<td>

<?php

if($complaint['Subcategory_risk']=="High"){

echo "<span style='color:red;font-weight:bold;'>High</span>";

}
elseif($complaint['Subcategory_risk']=="Medium"){

echo "<span style='color:orange;font-weight:bold;'>Medium</span>";

}
else{

echo "<span style='color:green;font-weight:bold;'>Low</span>";

}

?>

</td>
</tr>

<tr>
<td>Status</td>
<td>

<span class="badge <?php echo $statusClass; ?>">

<?php echo $complaint['Complaint_status']; ?>

</span>

</td>
</tr>

<tr>
<td>Assigned Police</td>
<td>

<?php

if(empty($complaint['PoliceID'])){

echo "Not Assigned";

}

else{

$policeQuery = mysqli_query(
$conn,
"SELECT *
FROM auxiliary_police
WHERE PoliceID='".$complaint['PoliceID']."'"
);

$police = mysqli_fetch_assoc($policeQuery);

echo $police['Police_fullName'];

}

?>

</td>
</tr>

<tr>
<td>Created Date</td>
<td>


<?php
echo date("d M Y h:i A",
strtotime($complaint['Complaint_createdAt']));
?>

</td>
</tr>

<tr>
<td>Deadline</td>
<td>

<?php

echo date("d M Y h:i A",
strtotime($complaint['Complaint_deadline']));

if(strtotime($complaint['Complaint_deadline']) < time()
&&
$complaint['Complaint_status']!="Resolved"
){

?>

<br>

<span
style="
color:#dc3545;
font-weight:bold;
">

⚠ Overdue by

<?php echo $daysOverdue; ?>

day(s)

</span>

<?php

}


else{
?>

<br>

<span
style="
color:#27ae60;
font-weight:bold;
">

✓ Within Deadline

</span>

<?php } ?>

</td>
</tr>

<?php
if(!empty($complaint['Complaint_resolvedAt'])){
?>

<tr>
<td>Resolved Date</td>
<td>

<?php
echo date("d M Y h:i A",
strtotime($complaint['Complaint_resolvedAt']));
?>

</td>
</tr>

<?php } ?>

</table>

</div>







<div class="card">

<h2>Location</h2>

<table>

<tr>
<td>Location Name</td>
<td><?php echo $complaint['Complaint_locationName']; ?></td>
</tr>

<tr>
<td>Specific Location Description</td>
<td><?php echo $complaint['Complaint_locationDesc']; ?></td>
</tr>

</table>

</div>

<div class="card">

<h2>Location Map</h2>

<div id="map"></div>

</div>





<?php if($vehicle){ ?>

<div class="card">

<h2>Vehicle Information</h2>

<?php if($vehicle){ ?>

<table>

<tr>
<td>Plate Number</td>
<td><?php echo $vehicle['Reported_plateNum']; ?></td>
</tr>

<tr>
<td>Vehicle Type</td>
<td><?php echo $vehicle['Reported_type']; ?></td>
</tr>

<tr>
<td>Vehicle Color</td>
<td><?php echo !empty($vehicle['Reported_color']) ? $vehicle['Reported_color'] : "-"; ?></td>
</tr>

<tr>
<td>Vehicle Model</td>
<td><?php echo !empty($vehicle['Reported_model']) ? $vehicle['Reported_model'] : "-"; ?></td>
</tr>

</table>

<?php } ?>

</div>

<?php } ?>






<!-- Evidence -->
<div class="card">

<h2>Evidence</h2>

<?php

if(
mysqli_num_rows($evidenceQuery) == 0
){
echo "<p>No evidence uploaded.</p>";
}

?>

<?php

while($file = mysqli_fetch_assoc($evidenceQuery)
){

$extension = strtolower(
pathinfo($file['Evidence_fileName'],
PATHINFO_EXTENSION
)
);

if(in_array(
$extension,
['jpg','jpeg','png']
)
){

?>

<img
src="../uploads/evidence/<?php echo $file['Evidence_fileName']; ?>"
class="evidence"
onclick="window.open(this.src)"
style="cursor:pointer;">

<?php

}
else{

?>

<p>
🎥
<a href="../uploads/evidence/<?php echo $file['FileName']; ?>" target="_blank">

<?php echo $file['Evidence_fileName']; ?>

</a>
</p>

<?php

}

}

?>

</div>


<?php

if($complaint['Complaint_status']=="Escalated"){
?>



<div class="card">

<h2>Escalation Analysis</h2>

<table>

<tr>

<td>Current Status</td>

<td>

<span
style="
color:red;
font-weight:bold;">

Escalated

</span>

</td>

</tr>





<tr>

<td>Escalation Reason</td>

<td>

<div
style="
background:#fff3cd;
border-left:5px solid #ffc107;
padding:15px;
border-radius:8px;
line-height:1.6;
">

⚠ <?php echo $escalationReason; ?>

</div>

</td>

</tr>




<tr>

<td>Assigned Police</td>

<td>

<?php

if(!empty($complaint['PoliceID'])){

$policeQuery = mysqli_query(
$conn,
"SELECT *
FROM auxiliary_police
WHERE PoliceID='".$complaint['PoliceID']."'"
);

$police = mysqli_fetch_assoc($policeQuery);

echo
$police['Police_fullName'];

}
else{

echo "No Police Assigned";

}

?>

</td>

</tr>


<tr>

<td>Police Email</td>

<td>

<?php

echo
!empty($complaint['PoliceID'])
?
$police['Police_email']
:
"-";

?>

</td>

</tr>



<tr>

<td>Police Phone Number</td>

<td>

<?php

echo
!empty($complaint['PoliceID'])
?
$police['Police_phoneNum']
:
"-";

?>

</td>

</tr>


<tr>

<td>Deadline</td>

<td>

<?php

echo date("d M Y h:i A",
strtotime($complaint['Complaint_deadline']));

?>

</td>

</tr>




<tr>

<td>Days Overdue</td>


<td>

<?php echo $daysOverdue; ?>

day(s)

</td>

</tr>

<tr>

<td>

Latest Activity

</td>

<td>

<?php

if($latestTimeline){

?>

<div
style="
background:#f8f9fa;
padding:15px;
border-left:5px solid #5E2D91;
border-radius:8px;
">

<b>

<?php

echo date("d M Y h:i A",
strtotime($latestTimeline['TimelineDate']));

?>

</b>

<br><br>

<?php

echo
$latestTimeline['TimelineDesc'];

?>

</div>

<?php

}

else{

echo "-";

}

?>

</td>

</tr>

<tr>

<td>Return Count</td>

<td>

<?php echo $complaint['ReturnCount']; ?>

time(s)

</td>

</tr>

</table>

<br>

<h3
style="
margin-bottom:10px;
color:#5E2D91;
">

Supervisor Decision

</h3>

<p
style="
color:#666;
margin-bottom:20px;
line-height:1.6;
">

This complaint has been escalated because it exceeded the allocated resolution time.

Please choose the appropriate corrective action below.

</p>




<?php

// CASE 1
// No police assigned yet.
if(empty($complaint['PoliceID'])){

?>

<button
class="btn"
disabled
style="
background:#bdbdbd;
cursor:not-allowed;
opacity:0.7;">

↩ Return to Auxiliary Police

</button>

<p
style="
margin-top:10px;
margin-bottom:15px;
color:#888;">

This complaint has not been assigned to any Auxiliary Police yet.
Please assign an officer before returning the complaint.

</p>

<form
action="process_assign_police.php"
method="POST"
style="margin-top:20px;">

<input
type="hidden"
name="ComplaintID"
value="<?php echo $complaintID; ?>">

<label
style="
font-weight:bold;
display:block;
margin-bottom:10px;">

Select Auxiliary Police

</label>

<select
name="PoliceID"
required
style="
width:100%;
padding:12px;
border-radius:8px;
margin-bottom:15px;">

<option value="">Select Auxiliary Police</option>

<?php

$policeList = mysqli_query(
$conn,
"SELECT
ap.*,
COUNT(
CASE
WHEN c.Complaint_status IN ('Pending','In Progress')
THEN 1
END
) AS ActiveComplaints
FROM auxiliary_police ap
LEFT JOIN complaint c
ON ap.PoliceID=c.PoliceID
GROUP BY ap.PoliceID
ORDER BY ActiveComplaints ASC,
ap.Police_fullName ASC"
);

while($row=mysqli_fetch_assoc($policeList)){

?>

<option value="<?php echo $row['PoliceID']; ?>">

<?php

echo
$row['Police_fullName'].

" (".$row['ActiveComplaints']." Active Complaint";

if($row['ActiveComplaints']!=1){

echo "s";

}

echo ")";

?>

</option>

<?php } ?>

</select>

<button
class="btn"
type="submit"
style="background:#f39c12;">

👮 Assign Auxiliary Police

</button>

</form>

<?php

}



// CASE 2
// Police assigned but already returned twice.
elseif($complaint['ReturnCount'] >= 2){

?>

<button
class="btn"
disabled
style="
background:#bdbdbd;
cursor:not-allowed;
opacity:0.7;">

↩ Return Limit Reached

</button>

<div
style="
background:#fdecea;
border-left:5px solid #dc3545;
padding:15px;
margin-top:15px;
border-radius:8px;">

<strong>

⚠ Maximum Return Limit Reached

</strong>

<br><br>

This complaint has already been returned to the assigned Auxiliary Police twice.

Please reassign it to another available officer.

</div>

<br>




<form
action="process_assign_police.php"
method="POST"
style="margin-top:20px;">

<input
type="hidden"
name="ComplaintID"
value="<?php echo $complaintID; ?>">

<label
style="
font-weight:bold;
display:block;
margin-bottom:10px;">

Select New Auxiliary Police

</label>

<select
name="PoliceID"
required
style="
width:100%;
padding:12px;
border-radius:8px;
margin-bottom:15px;">

<option value="">Select Auxiliary Police</option>

<?php

$policeList = mysqli_query(
$conn,
"SELECT
ap.*,
COUNT(
CASE
WHEN c.Complaint_status IN ('Pending','In Progress')
THEN 1
END
) AS ActiveComplaints
FROM auxiliary_police ap
LEFT JOIN complaint c
ON ap.PoliceID=c.PoliceID
WHERE ap.PoliceID!='".$complaint['PoliceID']."''
GROUP BY ap.PoliceID
ORDER BY ActiveComplaints ASC,
ap.Police_fullName ASC"
);

while($row=mysqli_fetch_assoc($policeList)){

?>

<option value="<?php echo $row['PoliceID']; ?>">

<?php

echo
$row['Police_fullName'].

" (".$row['ActiveComplaints']." Active Complaint";

if($row['ActiveComplaints']!=1){

echo "s";

}

echo ")";

?>

</option>

<?php } ?>

</select>

<button
class="btn"
type="submit"
style="background:#f39c12;">

👮 Assign Auxiliary Police

</button>

</form>





<?php

}

// CASE 3
// Police assigned and still eligible to return.
else{

?>

<a
href="return_to_police.php?id=<?php echo $complaintID; ?>"
class="btn"
onclick="return confirm('Return this complaint to the assigned Auxiliary Police?')">

↩ Return to Auxiliary Police

</a>

<?php
}
}
?>








<div class="card">

<h2>Timeline</h2>

<?php

if(mysqli_num_rows($timelineQuery)==0){

    echo "<p>No timeline available.</p>";

}else{

?>

<div class="timeline">

<?php

mysqli_data_seek($timelineQuery,0);

while($timeline=mysqli_fetch_assoc($timelineQuery)){

?>

<div class="timeline-item">

<div class="timeline-icon">
✓
</div>

<div class="timeline-content">

<b>

<?php echo htmlspecialchars($timeline['TimelineDesc']); ?>

</b>

<br><br>

<small>

<?php
echo date("d M Y h:i A",strtotime($timeline['TimelineDate']));
?>

</small>

</div>

</div>

<?php

}

?>

</div>

<?php

}

?>

</div>





<script>

var map = L.map('map')
.setView(

    [
    <?php echo $complaint['Complaint_locationLat']; ?>,
    <?php echo $complaint['Complaint_locationLong']; ?>
    ],
    17

);

L.tileLayer(
    'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png'
).addTo(map);

L.marker(
    [
    <?php echo $complaint['Complaint_locationLat']; ?>,
    <?php echo $complaint['Complaint_locationLong']; ?>
    ]
)
.addTo(map)
.bindPopup(
    "<?php echo addslashes($complaint['Complaint_locationName']); ?>"
)
.openPopup();

</script>


<script>

function toggleMenu(){

var menu = document.getElementById(
"dropdownMenu"
);

if(menu.style.display=="block"){
menu.style.display="none";
}

else{
menu.style.display="block";
}

}

document.addEventListener("click",function(event){

var menu = document.getElementById("dropdownMenu");

var profile = document.querySelector(".profile-menu");

if(!profile.contains(event.target)){
menu.style.display="none";
}

}
);

</script>



</body>

</html>