<?php

session_start();



if(!isset($_SESSION['Role']) || $_SESSION['Role']!="Superior"){

    header("Location: ../index.php");
    exit();
}



include("../db.php");



$superiorID = $_SESSION['SuperiorID'];

$superiorQuery = mysqli_query(
$conn,
"SELECT *
FROM superior
WHERE SuperiorID='$superiorID'"
);

$superior = mysqli_fetch_assoc($superiorQuery);

$name = $superior['Superior_fullName'];

$profileImage = !empty($superior['Superior_profile'])
?
"../uploads/profile/".$superior['Superior_profile']
:
"../images/default-profile.png";




$policeID = (int)$_GET['id'];





$policeQuery = mysqli_query(
$conn,

"SELECT *

FROM auxiliary_police

WHERE PoliceID='$policeID'"

);

$police = mysqli_fetch_assoc(
$policeQuery
);

if(!$police){

    die("Police not found.");
}



$historyQuery = mysqli_query(
$conn,

"SELECT

c.*,

cc.CategoryName

FROM complaint c

INNER JOIN category cc
ON c.CategoryID = cc.CategoryID

WHERE c.PoliceID='$policeID'

ORDER BY c.Complaint_createdAt DESC"
);

?>





<!DOCTYPE html>

<html>

<head>

<link rel="icon" type="image/png" href="../images/logo.png">

<title>Police History</title>

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:Arial,sans-serif;
}

body{
background:#f4f6f9;
}

/* Sidebar */

.sidebar{
width:250px;
height:100vh;
background:#5E2D91;
position:fixed;
left:0;
top:0;
box-shadow:2px 0 10px rgba(0,0,0,0.1);
}

.logo-section{
text-align:center;
padding:20px;
border-bottom:1px solid rgba(255,255,255,0.15);
}

.sidebar-logo{
width:80px;
height:80px;
object-fit:contain;
}

.sidebar h2{
color:white;
font-size:20px;
margin-top:10px;
}

.sidebar a{
display:block;
padding:15px 20px;
color:white;
text-decoration:none;
font-size:15px;
transition:0.3s;
}

.sidebar a:hover{
background:#4b2374;
}

.active{
background:#4b2374;
border-left:5px solid white;
}

/* Topbar */

.topbar{
height:70px;
background:white;
display:flex;
justify-content:flex-end;
align-items:center;
padding:0 30px;
margin-left:250px;
box-shadow:0 2px 10px rgba(0,0,0,0.08);
}

.profile-menu{
display:flex;
align-items:center;
gap:10px;
position:relative;
cursor:pointer;
}

.username{
font-weight:bold;
color:#333;
}

.profile-menu img{
width:45px;
height:45px;
border-radius:50%;
object-fit:cover;
border:2px solid #5E2D91;
}

.dropdown{
display:none;
position:absolute;
right:0;
top:55px;
background:white;
width:180px;
border-radius:10px;
box-shadow:0 5px 15px rgba(0,0,0,0.15);
overflow:hidden;
z-index:9999;
}

.dropdown a{
display:block;
padding:12px 15px;
text-decoration:none;
color:#333;
}

.dropdown a:hover{
background:#f5f5f5;
}

/* Content */

.content{
margin-left:250px;
padding:30px;
}


.dashboard-header{
background:white;
padding:25px 30px;
border-radius:15px;
margin-bottom:25px;
box-shadow:0 2px 10px rgba(0,0,0,0.08);
border-left:5px solid #5E2D91;
}

.dashboard-header h1{
margin-bottom:8px;
font-size:38px;
}

.dashboard-header p{
    color:#666;
    margin:0;
}


.card{
background:white;
padding:20px;
border-radius:10px;
margin-bottom:20px;
box-shadow:0 2px 10px rgba(0,0,0,0.1);
}

table{
width:100%;
background:white;
border-collapse:collapse;
border-radius:10px;
overflow:hidden;
box-shadow:0 2px 10px rgba(0,0,0,0.1);
}

th{
background:#5E2D91;
color:white;
padding:12px;
}

td{
padding:12px;
border-bottom:1px solid #ddd;
}

.btn{
background:#5E2D91;
color:white;
padding:10px 15px;
text-decoration:none;
border-radius:5px;
}

.status-badge{
display:inline-block;
padding:5px 12px;
border-radius:20px;
font-size:12px;
font-weight:bold;
color:white;
}


</style>

</head>



<body>

<div class="sidebar">

    <div class="logo-section">

        <img
        src="../images/logo.png"
        class="sidebar-logo">

        <h2>SafeRoad UiTM</h2>

        <p class="sidebar-role">
            Superior
        </p>

    </div>

         <a
        href="dashboard.php">
        Dashboard
        </a>

        <a href="manage_escalated.php">
        Escalated Complaints
        </a>

        <a href="police_performance.php"class="active">
        Police Performance
        </a>


        <a href="heatmap.php">
        Complaint Heatmap
        </a>

</div>






<div class="topbar">

    <div class="profile-menu">

        <span class="username">
            <?php echo $name; ?>
        </span>

        <img
        src="<?php echo $profileImage; ?>"
        alt="Profile"
        onclick="toggleMenu()">

        <div
        id="dropdownMenu"
        class="dropdown">

            <a href="profile.php">
                My Profile
            </a>

            <a href="../logout.php">
                Logout
            </a>

        </div>

    </div>

</div>




<div class="content">

<div class="dashboard-header">

<h1>Auxiliary Police Complaint History</h1>

<p style="color:#666;">

View all complaints previously assigned to this Auxiliary Police officer.

</p>

</div>

<a
href="police_performance.php"
class="btn">

← Back

</a>

<br><br>



<br>




<div class="card">

<h2 style="color:#5E2D91;margin-bottom:15px;">

👮 <?php echo htmlspecialchars($police['Police_fullName']); ?>

</h2>

<table style="width:100%;box-shadow:none;border:none;">


<tr>

<td style="font-weight:bold;border:none;">
Email Address
</td>

<td style="border:none;">
<?php echo htmlspecialchars($police['Police_email']); ?>
</td>

</tr>

<tr>

<td style="font-weight:bold;border:none;">
Phone Number
</td>

<td style="border:none;">

<?php

echo !empty($police['Police_phoneNum'])
?
htmlspecialchars($police['Police_phoneNum'])
:
"-";

?>

</td>

</tr>

<tr>

<td style="font-weight:bold;border:none;">
Total Complaints Assigned
</td>

<td style="border:none;">

<b>

<?php echo mysqli_num_rows($historyQuery); ?>

</b>

</td>

</tr>

</table>

</div>





<table>

<tr>

<th>Reference No</th>

<th>Category</th>

<th>Status</th>

<th>Created Date</th>

<th>View</th>

</tr>








<?php

if(mysqli_num_rows($historyQuery) == 0){

?>

<tr>

<td colspan="5" style="
text-align:center;
padding:40px;
color:#777;
font-style:italic;
">

No complaint history found for this Auxiliary Police officer.

</td>

</tr>

<?php

}else{

while($row = mysqli_fetch_assoc($historyQuery)){

?>

<tr>

<td>

<?php echo htmlspecialchars($row['ReferenceNumber']); ?>

</td>

<td>

<?php echo htmlspecialchars($row['CategoryName']); ?>

</td>

<td>

<?php

$status = $row['Complaint_status'];

switch($status){

    case "Pending":
        $color="#f39c12";
        break;

    case "In Progress":
        $color="#1f4e79";
        break;

    case "Resolved":
        $color="#27ae60";
        break;

    case "Warning Sent":
        $color="#9b59b6";
        break;

    case "Awaiting Police":
        $color="#17a2b8";
        break;

    default:
        $color="#e74c3c";
}

?>

<span
class="status-badge"
style="background:<?php echo $color; ?>;">

<?php echo htmlspecialchars($status); ?>

</span>

</td>

<td>

<?php
echo date(
"d M Y h:i A",
strtotime($row['Complaint_createdAt'])
);
?>

</td>

<td>

<a
href="view_complaint.php?id=<?php echo $row['ComplaintID']; ?>"
class="btn">

View

</a>

</td>

</tr>

<?php

}

}

?>

</table>
</div>
</div>


<script>

function toggleMenu(){

var menu = document.getElementById("dropdownMenu");

if(menu.style.display=="block"){
menu.style.display="none";
}

else{
menu.style.display="block";
}

}

document.addEventListener("click",function(event){

var menu = document.getElementById("dropdownMenu");

var profile = document.querySelector(".profile-menu");

if(!profile.contains(event.target)){
menu.style.display="none";
}

}
);

</script>


</body>
</html>






