<?php

session_start();


if(!isset($_SESSION['Role']) || $_SESSION['Role'] != "Superior"){

    header("Location: ../index.php");

    exit();
}



include("../db.php");



$superiorID = $_SESSION['UserID'];

$name = $_SESSION['UserName'];


$superiorQuery = mysqli_query(
$conn,
"SELECT Superior_profile
FROM superior
WHERE SuperiorID='$superiorID'"
);

$superior = mysqli_fetch_assoc($superiorQuery);



$profileImage = !empty($superior['Superior_profile'])
?
"../uploads/profile/".$superior['Superior_profile']
:
"../images/default-profile.png";




$totalEscalatedQuery = mysqli_query(
$conn,
"SELECT COUNT(*) AS Total
FROM complaint
WHERE Complaint_status='Escalated'"
);

$totalEscalated = mysqli_fetch_assoc($totalEscalatedQuery)['Total'];



$todayEscalatedQuery = mysqli_query(
$conn,
"SELECT COUNT(*) AS Total
FROM complaint
WHERE Complaint_status='Escalated'
AND DATE(Complaint_createdAt)=CURDATE()"
);

$todayEscalated = 
mysqli_fetch_assoc($todayEscalatedQuery)['Total'];




$highQuery = mysqli_query($conn,
"SELECT COUNT(*) AS Total
FROM complaint c
INNER JOIN subcategory cs
ON c.SubcategoryID = cs.SubcategoryID
WHERE
c.Complaint_status='Escalated'
AND
cs.Subcategory_risk='High'"
);

$high = mysqli_fetch_assoc($highQuery)['Total'];





$mediumQuery = mysqli_query($conn,
"SELECT COUNT(*) AS Total
FROM complaint c
INNER JOIN subcategory cs
ON c.SubcategoryID = cs.SubcategoryID
WHERE
c.Complaint_status='Escalated'
AND
cs.Subcategory_risk='Medium'"
);

$medium = mysqli_fetch_assoc($mediumQuery)['Total'];





$lowQuery = mysqli_query($conn,
"SELECT COUNT(*) AS Total
FROM complaint c
INNER JOIN subcategory cs
ON c.SubcategoryID = cs.SubcategoryID
WHERE
c.Complaint_status='Escalated'
AND
cs.Subcategory_risk='Low'"
);

$low = mysqli_fetch_assoc($lowQuery)['Total'];

$labels = ['High','Medium','Low'];

$data = [
$high,
$medium,
$low
];




$topIssueQuery = mysqli_query($conn,
"SELECT
cs.Subcategory_name,
COUNT(*) AS Total
FROM complaint c
JOIN subcategory cs
ON c.SubcategoryID=cs.SubcategoryID
WHERE c.Complaint_status='Escalated'
GROUP BY c.SubcategoryID
ORDER BY Total DESC"
);


$issueLabels = [];
$issueData = [];

while($row = mysqli_fetch_assoc($topIssueQuery)){

$issueLabels[] = $row['Subcategory_name'];
$issueData[] = $row['Total'];

}





$workloadQuery = mysqli_query($conn,
"SELECT
ap.Police_fullName,
COUNT(c.ComplaintID) AS Total
FROM auxiliary_police ap
LEFT JOIN complaint c
ON ap.PoliceID=c.PoliceID
WHERE c.Complaint_status IN
(
    'Escalated'
)
GROUP BY ap.PoliceID
ORDER BY Total DESC"
);


$workloadLabels = [];
$workloadData = [];

while($row =mysqli_fetch_assoc($workloadQuery)){

    $workloadLabels[] = $row['Police_fullName'];

    $workloadData[] = $row['Total'];

}





$recentEscalatedQuery = mysqli_query($conn,
"SELECT
c.ComplaintID,
c.Complaint_status,
c.ReferenceNumber,
c.Complaint_deadline,
cs.Subcategory_name,
cs.Subcategory_risk,
ap.Police_fullName
FROM complaint c
LEFT JOIN subcategory cs
ON c.SubcategoryID=cs.SubcategoryID
LEFT JOIN auxiliary_police ap
ON c.PoliceID=ap.PoliceID
WHERE c.Complaint_status='Escalated'
ORDER BY c.Complaint_createdAt DESC
LIMIT 5"
);

?>





<!DOCTYPE html>

<html>

<head>

<link rel="icon" type="image/png" href="../images/logo.png">

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<title>Superior Dashboard</title>

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:Arial,sans-serif;
}

body{
background:#f4f6f9;
}

/* Sidebar */

.sidebar{
width:250px;
height:100vh;
background:#5E2D91;
position:fixed;
left:0;
top:0;
box-shadow:2px 0 10px rgba(0,0,0,0.1);
}

.logo-section{
text-align:center;
padding:20px;
border-bottom:1px solid rgba(255,255,255,0.15);
}

.sidebar-logo{
width:80px;
height:80px;
object-fit:contain;
}

.sidebar h2{
color:white;
font-size:20px;
margin-top:10px;
}

.sidebar a{
display:block;
padding:15px 20px;
color:white;
text-decoration:none;
font-size:15px;
transition:0.3s;
}

.sidebar a:hover{
background:#4b2374;
}

.active{
background:#4b2374;
border-left:5px solid white;
}

/* Topbar */

.topbar{
height:70px;
background:white;
display:flex;
justify-content:flex-end;
align-items:center;
padding:0 30px;
margin-left:250px;
box-shadow:0 2px 10px rgba(0,0,0,0.08);
}

.profile-menu{
display:flex;
align-items:center;
gap:10px;
position:relative;
cursor:pointer;
}

.username{
font-weight:bold;
color:#333;
}

.profile-menu img{
width:45px;
height:45px;
border-radius:50%;
object-fit:cover;
border:2px solid #5E2D91;
}

.dropdown{
display:none;
position:absolute;
right:0;
top:55px;
background:white;
width:180px;
border-radius:10px;
box-shadow:0 5px 15px rgba(0,0,0,0.15);
overflow:hidden;
z-index:9999;
}

.dropdown a{
display:block;
padding:12px 15px;
text-decoration:none;
color:#333;
}

.dropdown a:hover{
background:#f5f5f5;
}

/* Content */

.content{
margin-left:250px;
padding:30px;
}


.card{
background:white;
padding:25px;
border-radius:10px;
width:250px;
text-align:center;
box-shadow:0 2px 10px rgba(0,0,0,0.1);
}

.card h3{
margin-bottom:10px;
color:#5E2D91;
}

.number{
font-size:35px;
font-weight:bold;
}

.charts{
display:grid;
grid-template-columns:1fr 1fr;
gap:20px;
}

.chart-card{
background:white;
padding:20px;
border-radius:10px;
box-shadow:0 2px 10px rgba(0,0,0,0.1);
}

.chart-card canvas{
max-height:400px;
}


.dashboard-header{
background:white;
padding:25px 30px;
border-radius:15px;
margin-bottom:25px;
box-shadow:0 2px 10px rgba(0,0,0,0.08);
border-left:5px solid #5E2D91;
}

.dashboard-header h1{
margin-bottom:8px;
font-size:38px;
}

.dashboard-header p{
color:#666;
margin:0;
}


.table-card{
background:white;
padding:20px;
border-radius:10px;
box-shadow:0 2px 10px rgba(0,0,0,0.1);
}

.table-card table{
width:100%;
border-collapse:collapse;
}

.table-card th{
background:#f4f4f4;
padding:12px;
text-align:left;
}

.table-card td{
padding:12px;
border-bottom:1px solid #eee;
}

.table-card tr:hover{
background:#f8f4ff;
cursor:pointer;
}


.stats{
    display:flex;
    gap:25px;
    margin-top:20px;
    margin-bottom:30px;
}

.summary-card{
flex:1;
background:white;
padding:35px;
border-radius:15px;
box-shadow:0 2px 12px rgba(0,0,0,0.08);
border-left:6px solid #5E2D91;
}

.summary-card h3{
color:#666;
font-size:18px;
margin-bottom:15px;
}

.summary-number{
font-size:48px;
font-weight:bold;
color:#5E2D91;
}

.summary-card.total{
border-left:6px solid #dc3545;
}

.summary-card.today{
border-left:6px solid #0d6efd;
}

</style>

</head>




<body>

<div class="sidebar">

    <div class="logo-section">

        <img
        src="../images/logo.png"
        class="sidebar-logo">

        <h2>SafeRoad UiTM</h2>

        <p class="sidebar-role">
            Superior
        </p>

    </div>

         <a
        href="dashboard.php"class="active">
        Dashboard
        </a>

        <a href="manage_escalated.php">
        Escalated Complaints
        </a>

        <a href="police_performance.php">
        Police Performance
        </a>


        <a href="heatmap.php">
        Complaint Heatmap
        </a>

</div>






<div class="topbar">

    <div class="profile-menu">

        <span class="username">
            <?php echo $name; ?>
        </span>

        <img
        src="<?php echo $profileImage; ?>"
        alt="Profile"
        onclick="toggleMenu()">

        <div
        id="dropdownMenu"
        class="dropdown">

            <a href="profile.php">
                My Profile
            </a>

            <a href="../logout.php">
                Logout
            </a>

        </div>

    </div>

</div>








<div class="content">

<div class="dashboard-header">

    <h1>Superior Dashboard</h1>

    <p>Monitor escalated traffic complaints, evaluate Auxiliary Police performance, and analyse complaint trends across UiTM Shah Alam.</p>

</div>





<div class="stats">


    <div class="summary-card total">

        <h3>🚨 Total Escalated Complaints</h3>

    <div class="summary-number">

    <?php echo $totalEscalated; ?>

    </div>

    </div>


    <div class="summary-card today">

        <h3>📅 Today's Escalated Complaints</h3>

    <div class="summary-number">

    <?php echo $todayEscalated; ?>

    </div>

    </div>

</div>





<br><br>

<div class="charts">

<div class="chart-card">

<h3>Escalated Complaints by Risk Level</h3>

<canvas id="statusChart"></canvas>

</div>





<div class="chart-card">

<h3>🚧 Most Reported Escalated Issues</h3>

<canvas id="categoryChart"></canvas>

</div>




<div class="chart-card">

<h3>👮 Escalated Cases by Auxiliary Police</h3>

<canvas id="trendChart"></canvas>

</div>





<div class="table-card">

<h3 style="margin-bottom:15px;">
🚨 Recent Escalated Complaints
</h3>

<table>

<tr>
<th>Reference No</th>
<th>Issue</th>
<th>Risk</th>
<th>Assigned Police</th>
<th>Status</th>
<th>Deadline</th>
</tr>

<?php
while(
$row = mysqli_fetch_assoc($recentEscalatedQuery)){
?>

<tr
onclick="window.location='view_complaint.php?id=<?php echo $row['ComplaintID']; ?>'">

<td>
<?php echo $row['ReferenceNumber']; ?>
</td>

<td>
<?php echo $row['Subcategory_name']; ?>
</td>

<td>
<?php echo $row['Subcategory_risk']; ?>
</td>

<td>
<?php
echo
$row['Police_fullName']
??
'Not Assigned';
?>
</td>

<td>
<?php echo $row['Complaint_status']; ?>
</td>

<td>
<?php
echo date("d M Y",strtotime($row['Complaint_deadline']));
?>
</td>

</tr>

<?php } ?>

</table>

</div>

</div>







<script>

const statusChart = new Chart
(document.getElementById('statusChart'),{

type:'doughnut',
data:{
labels:
<?php echo json_encode($labels); ?>,

datasets:[{
data:
<?php echo json_encode($data); ?>

}]
}
}
);

</script>





<script>

new Chart(document.getElementById('categoryChart'),{

type:'pie',
data:{
labels:
<?php echo json_encode($issueLabels); ?>,

datasets:[{
label:'Escalated Cases',
data:
<?php echo json_encode($issueData); ?>

}]
},

options:{

    indexAxis:'y'

}

}

);

</script>











<script>

new Chart(

document.getElementById('trendChart'),{

type:'bar',

data:{

labels:
<?php echo json_encode($workloadLabels); ?>,

datasets:[{

label:'Assigned Escalated Cases',

data:
<?php echo json_encode($workloadData); ?>

}]

},

options:{

indexAxis:'y'

}

}

);

</script>



<script>

function toggleMenu(){

var menu = document.getElementById("dropdownMenu");

if(menu.style.display=="block"){
menu.style.display="none";
}

else{
menu.style.display="block";
}

}

document.addEventListener("click",function(event){

var menu = document.getElementById("dropdownMenu");

var profile = document.querySelector(".profile-menu");

if(!profile.contains(event.target)){
menu.style.display="none";
}

}
);

</script>



</body>

</html>