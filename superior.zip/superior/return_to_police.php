<?php

session_start();


/* Set Malaysia timezone */
date_default_timezone_set('Asia/Kuala_Lumpur');


if(!isset($_SESSION['Role']) || $_SESSION['Role']!="Superior"){

    header("Location: ../index.php");
    exit();
}



include("../db.php");

include("../includes/send_email.php");



if(!isset($_GET['id'])){
    header("Location: manage_escalated.php");
    exit();
}



$complaintID = mysqli_real_escape_string(
$conn,
$_GET['id']
);



$complaintQuery = mysqli_query(
$conn,

"SELECT
c.*,
cs.Subcategory_resolutionTime,
cs.Subcategory_name,
cc.CategoryName
FROM complaint c
INNER JOIN subcategory cs
ON c.SubcategoryID=cs.SubcategoryID
INNER JOIN category cc
ON c.CategoryID=cc.CategoryID
WHERE c.ComplaintID='$complaintID'"
);

$complaint = mysqli_fetch_assoc(
$complaintQuery
);


if(!$complaint){

    die("Complaint not found.");

}



if(empty($complaint['PoliceID'])){

    die("No auxiliary police assigned.");

}



$policeQuery = mysqli_query(
$conn,
"SELECT *
FROM auxiliary_police
WHERE PoliceID='".
$complaint['PoliceID']."'"
);

$police = mysqli_fetch_assoc(
$policeQuery
);





$newDeadline = date("Y-m-d H:i:s",
strtotime("+".$complaint['Subcategory_resolutionTime']." hours",
time()));



mysqli_query(
$conn,
"UPDATE complaint
SET
Complaint_status='In Progress',
Complaint_deadline='$newDeadline',
ReturnCount = ReturnCount + 1
WHERE ComplaintID='$complaintID'"
);



$timeline =

"Complaint was returned by the Superior to the assigned Auxiliary Police.

Return Count: ".($complaint['ReturnCount'] + 1)."

A new resolution deadline has been assigned.";



$superiorID = $_SESSION['UserID'];

mysqli_query(
    $conn,
    "INSERT INTO complaint_timeline
    (
        ComplaintID,
        SuperiorID,
        TimelineDesc,
        TimelineDate
    )
    VALUES
    (
        '$complaintID',
        '$superiorID',
        '".mysqli_real_escape_string($conn,$timeline)."',
        NOW()
    )"
);



$subject = "SafeRoad UiTM - Escalated Complaint Returned";

$message = "

<h2 style='color:#5E2D91;'>

Escalated Complaint Returned

</h2>

<p>

Dear <b>".$police['Police_fullName']."</b>,

</p>

<p>

A complaint has been returned by the Superior for your immediate attention.

</p>

<hr>

<table cellpadding='8'>

<tr>

<td><b>Reference Number</b></td>

<td>".$complaint['ReferenceNumber']."</td>

</tr>

<tr>

<td><b>Category</b></td>

<td>".$complaint['CategoryName']."</td>

</tr>

<tr>

<td><b>Issue</b></td>

<td>".$complaint['Subcategory_name']."</td>

</tr>

<tr>

<td><b>New Deadline</b></td>

<td>".date("d M Y h:i A",strtotime($newDeadline))."</td>

</tr>

</table>

<br>

<p>

Please resolve this complaint as soon as possible and upload the resolution evidence through the SafeRoad UiTM system.

</p>

<p>

Thank you.

</p>

";

if(!empty($police['Police_email'])){

    sendEmail(
        $police['Police_email'],
        $police['Police_fullName'],
        $subject,
        $message
    );

}



header(
"Location: view_complaint.php?id=".$complaintID."&returned=1"
);

exit();