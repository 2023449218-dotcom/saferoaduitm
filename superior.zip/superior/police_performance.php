<?php

session_start();



if(!isset($_SESSION['Role'])||$_SESSION['Role']!="Superior"){

    header("Location: ../index.php");

    exit();
}




include("../db.php");


$superiorID = $_SESSION['UserID'];

$name = $_SESSION['UserName'];

$superiorQuery = mysqli_query(
$conn,
"SELECT Superior_profile
FROM superior
WHERE SuperiorID='$superiorID'"
);

$superior = mysqli_fetch_assoc($superiorQuery);



$profileImage = !empty($superior['Superior_profile'])
?
"../uploads/profile/".$superior['Superior_profile']
:
"../images/default-profile.png";



$query = mysqli_query(

$conn,

"SELECT

ap.PoliceID,
ap.Police_fullName,

COUNT(c.ComplaintID) AS TotalAssigned,

SUM(
CASE
WHEN c.Complaint_status='Resolved'
THEN 1
ELSE 0
END
) AS TotalResolved,

SUM(
CASE
WHEN c.Complaint_status='Escalated'
THEN 1
ELSE 0
END
) AS TotalEscalated

FROM auxiliary_police ap

LEFT JOIN complaint c
ON ap.PoliceID = c.PoliceID

GROUP BY ap.PoliceID

ORDER BY TotalEscalated DESC"

);


$totalPoliceQuery = mysqli_query(
$conn,

"SELECT COUNT(*) AS Total
FROM auxiliary_police"
);

$totalPolice = mysqli_fetch_assoc(
$totalPoliceQuery)['Total'];

?>






<!DOCTYPE html>

<html>

<head>

<link rel="icon" type="image/png" href="../images/logo.png">

<title>Police performance</title>

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:Arial,sans-serif;
}

body{
background:#f4f6f9;
}

/* Sidebar */

.sidebar{
width:250px;
height:100vh;
background:#5E2D91;
position:fixed;
left:0;
top:0;
box-shadow:2px 0 10px rgba(0,0,0,0.1);
}

.logo-section{
text-align:center;
padding:20px;
border-bottom:1px solid rgba(255,255,255,0.15);
}

.sidebar-logo{
width:80px;
height:80px;
object-fit:contain;
}

.sidebar h2{
color:white;
font-size:20px;
margin-top:10px;
}

.sidebar a{
display:block;
padding:15px 20px;
color:white;
text-decoration:none;
font-size:15px;
transition:0.3s;
}

.sidebar a:hover{
background:#4b2374;
}

.active{
background:#4b2374;
border-left:5px solid white;
}

/* Topbar */

.topbar{
height:70px;
background:white;
display:flex;
justify-content:flex-end;
align-items:center;
padding:0 30px;
margin-left:250px;
box-shadow:0 2px 10px rgba(0,0,0,0.08);
}

.profile-menu{
display:flex;
align-items:center;
gap:10px;
position:relative;
cursor:pointer;
}

.username{
font-weight:bold;
color:#333;
}

.profile-menu img{
width:45px;
height:45px;
border-radius:50%;
object-fit:cover;
border:2px solid #5E2D91;
}

.dropdown{
display:none;
position:absolute;
right:0;
top:55px;
background:white;
width:180px;
border-radius:10px;
box-shadow:0 5px 15px rgba(0,0,0,0.15);
overflow:hidden;
z-index:9999;
}

.dropdown a{
display:block;
padding:12px 15px;
text-decoration:none;
color:#333;
}

.dropdown a:hover{
background:#f5f5f5;
}

/* Content */

.content{
margin-left:250px;
padding:30px;
}

table{
width:100%;
background:white;
border-collapse:collapse;
border-radius:10px;
overflow:hidden;
box-shadow:0 2px 10px rgba(0,0,0,0.1);
}

th{
background:#5E2D91;
color:white;
padding:12px;
}

td{
padding:12px;
border-bottom:1px solid #ddd;
}

.content{
margin-left:250px;
padding:30px;
}





.dashboard-header{
background:white;
padding:25px 30px;
border-radius:15px;
margin-bottom:25px;
box-shadow:0 2px 10px rgba(0,0,0,0.08);
border-left:5px solid #5E2D91;
}

.dashboard-header h1{
margin-bottom:8px;
font-size:38px;
}

.dashboard-header p{
color:#666;
margin:0;
}






.stats{

display:grid;

grid-template-columns:250px;

margin-bottom:25px;

}

.card{

background:white;

padding:25px;

border-radius:15px;

box-shadow:0 2px 10px rgba(0,0,0,0.08);

text-align:center;

border-left:5px solid #5E2D91;

}

.card-icon{

font-size:35px;

margin-bottom:10px;

}

.number{

font-size:34px;

font-weight:bold;

color:#5E2D91;

margin-top:10px;

}




.progress-bar{

width:140px;

height:10px;

background:#e5e5e5;

border-radius:20px;

overflow:hidden;

margin:auto;

}

.progress-fill{

height:100%;

background:#27ae60;

}

.excellent{

color:#27ae60;

font-weight:bold;

}

.average{

color:#f39c12;

font-weight:bold;

}

.poor{

color:#e74c3c;

font-weight:bold;

}

</style>

</head>



<body>

<div class="sidebar">

    <div class="logo-section">

        <img
        src="../images/logo.png"
        class="sidebar-logo">

        <h2>SafeRoad UiTM</h2>

        <p class="sidebar-role">
            Superior
        </p>

    </div>

         <a
        href="dashboard.php">

        Dashboard

        </a>

        <a href="manage_escalated.php">
        Escalated Complaints
        </a>

        <a href="police_performance.php" class="active">
        Police Performance
        </a>


        <a href="heatmap.php">
        Complaint Heatmap
        </a>

</div>






<div class="topbar">

    <div class="profile-menu">

        <span class="username">
            <?php echo $name; ?>
        </span>

        <img
        src="<?php echo $profileImage; ?>"
        alt="Profile"
        onclick="toggleMenu()">

        <div
        id="dropdownMenu"
        class="dropdown">

            <a href="profile.php">
                My Profile
            </a>

            <a href="../logout.php">
                Logout
            </a>

        </div>

    </div>

</div>







<div class="content">

<div class="dashboard-header">

<h1>Auxiliary Police Performance</h1>

<p>Police performance.</p>

<br>

<div class="stats">

<div class="card">

<div class="card-icon">👮</div>

<h4>Total Auxiliary Police</h4>

<div class="number">

<?php echo $totalPolice; ?>

</div>

</div>

</div>


<input

type="text"

id="searchPolice"

placeholder="🔍 Search police..."

style="
width:320px;
padding:10px 15px;
border:1px solid #ccc;
border-radius:8px;
margin-bottom:20px;
font-size:15px;
">



<br>

<table id="policeTable">

<tr>

<th>Police Name</th>

<th>Total Assigned</th>

<th>Resolved</th>

<th>Escalated</th>

<th>Performance</th>

<th>Action</th>

</tr>





<?php

while(
$row =
mysqli_fetch_assoc($query)
){

if(
$row['TotalAssigned'] > 0

){

    $rate =
    round(
    ($row['TotalResolved']/$row['TotalAssigned'])*100);

}


else{

$rate = 0;

}

// Choose progress bar color
    $barColor = "#e74c3c";   // Red

    if($rate >= 70){

        $barColor = "#27ae60";   // Green

    }
    elseif($rate >= 50){

        $barColor = "#f39c12";   // Orange

    }

?>



<tr>

<td>

<?php
echo $row['Police_fullName'];
?>

</td>




<td>

<?php
echo $row['TotalAssigned'];
?>

</td>





<td>

<?php
echo $row['TotalResolved'];
?>

</td>





<td>

<?php
echo $row['TotalEscalated'];
?>

</td>





<td>

<div class="progress-bar">

<div
class="progress-fill"
style="
width:<?php echo $rate; ?>%;
background:<?php echo $barColor; ?>;
">
</div>

</div>

<br>

<?php

if($rate>=80){

echo "<span class='excellent'>Excellent</span>";

}
elseif($rate>=50){

echo "<span class='average'>Good</span>";

}
else{

echo "<span class='poor'>Poor</span>";

}

?>

<br>

<b>

<?php echo $rate; ?>%

</b>

</td>



<td>

<a
href="police_history.php?id=<?php echo $row['PoliceID']; ?>"
class="btn">

View History

</a>

</td>

</tr>

<?php } ?>

</table>

</div>



<script>

const search =
document.getElementById("searchPolice");

search.addEventListener(

"keyup",

function(){

let keyword =
this.value.toLowerCase();

let rows =
document.querySelectorAll(
"#policeTable tr"
);

rows.forEach(function(row,index){

if(index==0) return;

let text =
row.innerText.toLowerCase();

row.style.display =
text.includes(keyword)
?
""
:
"none";

});

}

);

</script>


<script>

function toggleMenu(){

var menu = document.getElementById(
"dropdownMenu"
);

if(menu.style.display=="block"){
menu.style.display="none";
}

else{
menu.style.display="block";
}

}

document.addEventListener("click",function(event){

var menu = document.getElementById("dropdownMenu");

var profile = document.querySelector(".profile-menu");

if(!profile.contains(event.target)){
menu.style.display="none";
}

}
);

</script>



</body>

</html>







