<?php
session_start();




if (!isset($_SESSION['Role']) || $_SESSION['Role'] != "Superior") {
    
    header("Location: ../index.php");
    exit();
}



include("../db.php");



$superiorID = $_SESSION['SuperiorID'];

$current = mysqli_real_escape_string($conn, 
    trim($_POST['current_password']));

$new = mysqli_real_escape_string($conn, 
    trim($_POST['new_password']));

$confirm = mysqli_real_escape_string($conn, 
    trim($_POST['confirm_password']));


// ===============================
// Validation
// ===============================

// Empty fields
if (empty($current) || empty($new) || empty($confirm)) {

    echo "
    <script>

    alert('Please fill in all password fields.');
    window.history.back();

    </script>";
    exit();
}

// Confirm password
if ($new != $confirm) {

    echo "
    <script>

    alert('New password and Confirm password do not match.');
    window.history.back();

    </script>";
    exit();
}

// Minimum length
if (strlen($new) < 8) {

    echo "
    <script>

    alert('Password must contain at least 8 characters.');
    window.history.back();

    </script>";
    exit();
}

// Cannot reuse same password
if ($current == $new) {

    echo "
    <script>

    alert('New password must be different from the current password.');
    window.history.back();

    </script>";
    exit();
}


// ===============================
// Retrieve Superior
// ===============================

$query = mysqli_query(
    $conn,
    "SELECT *
     FROM superior
     WHERE SuperiorID='$superiorID'"
);

if (mysqli_num_rows($query) == 0) {

    echo "
    <script>

    alert('Superior account not found.');
    window.location='profile.php';

    </script>";
    exit();
}

$superior = mysqli_fetch_assoc($query);


// ===============================
// Verify Current Password
// ===============================

if ($superior['Superior_password'] != $current) {

    echo "
    <script>

    alert('Current password is incorrect.');
    window.history.back();

    </script>";
    exit();
}


// ===============================
// Update Password
// ===============================

$update = mysqli_query(
    $conn,
    "UPDATE superior
     SET Superior_password='$new'
     WHERE SuperiorID='$superiorID'"
);


if ($update) {

    echo "
    <script>

    alert('Password updated successfully.');
    window.location='profile.php';

    </script>";

} 

else {

    echo "
    <script>

    alert('Failed to update password.');
    window.history.back();

    </script>";
}
?>