<?php

session_start();


/* Set Malaysia timezone */
date_default_timezone_set('Asia/Kuala_Lumpur');


if(!isset($_SESSION['Role']) || $_SESSION['Role']!="Superior"){

    header("Location: ../index.php");

    exit();
}




include("../db.php");

include("../includes/send_email.php");



if($_SERVER['REQUEST_METHOD']!="POST"){

    header("Location: manage_escalated.php");

    exit();
}

$complaintID = mysqli_real_escape_string($conn,$_POST['ComplaintID']);

$newPoliceID = mysqli_real_escape_string($conn,$_POST['PoliceID']);

$superiorID = $_SESSION['UserID'];




$query = mysqli_query($conn,"
SELECT
c.*,
cs.Subcategory_resolutionTime,
cs.Subcategory_name,
cc.CategoryName
FROM complaint c
INNER JOIN subcategory cs
ON c.SubcategoryID=cs.SubcategoryID
INNER JOIN category cc
ON c.CategoryID=cc.CategoryID
WHERE c.ComplaintID='$complaintID'
");

$complaint = mysqli_fetch_assoc($query);

if(!$complaint){
    die("Complaint not found.");
}




$policeQuery = mysqli_query($conn,"
SELECT *
FROM auxiliary_police
WHERE PoliceID='$newPoliceID'
");

$police = mysqli_fetch_assoc($policeQuery);

if(!$police){
    die("Auxiliary Police not found.");
}


$isReassign = !empty($complaint['PoliceID']);


$resolutionHours = (int)$complaint['Subcategory_resolutionTime'];

$newDeadline = date("Y-m-d H:i:s",
                strtotime("+$resolutionHours hours")
);

if($isReassign){

    $sql = "
    UPDATE complaint
    SET
        PoliceID='$newPoliceID',
        Complaint_status='In Progress',
        Complaint_deadline='$newDeadline',
        ReturnCount=ReturnCount+1
    WHERE ComplaintID='$complaintID'
    ";

}

else{

    $sql = "
    UPDATE complaint
    SET
        PoliceID='$newPoliceID',
        Complaint_status='In Progress',
        Complaint_deadline='$newDeadline'
    WHERE ComplaintID='$complaintID'
    ";

}


if(!mysqli_query($conn,$sql)){

    die("Database Error: ".mysqli_error($conn));

}




if($isReassign){

    // Get previous police information
    $oldPoliceQuery = mysqli_query(
        $conn,
        "SELECT Police_fullName
         FROM auxiliary_police
         WHERE PoliceID='".$complaint['PoliceID']."'"
    );

    $oldPolice = mysqli_fetch_assoc($oldPoliceQuery);

    $timeline =
    "The complaint was reassigned by the Superior from Auxiliary Police <b>"
    .$oldPolice['Police_fullName'].
    "</b> to <b>"
    .$police['Police_fullName'].
    "</b> after the maximum return limit was reached.

Complaint status changed to <b>In Progress</b>.";

}


else{

    $timeline =
    "The complaint was assigned by the Superior to Auxiliary Police"
    .$police['Police_fullName'].
    " after the complaint was escalated without an assigned officer.

Complaint status changed to In Progress.";

}

mysqli_query(
    $conn,
    "INSERT INTO complaint_timeline
    (
        ComplaintID,
        SuperiorID,
        TimelineDesc,
        TimelineDate
    )
    VALUES
    (
        '$complaintID',
        '$superiorID',
        '".mysqli_real_escape_string($conn,$timeline)."',
        NOW()
    )"
);



if($isReassign){

    $subject = "Complaint Reassigned - SafeRoad UiTM";

}


else{

    $subject = "New Complaint Assignment - SafeRoad UiTM";

}

$message = "

Dear ".$police['Police_fullName'].",<br><br>

You have been assigned by the <b>Superior</b> to handle the following traffic complaint.<br><br>

<b>Reference Number:</b> ".$complaint['ReferenceNumber']."<br>

<b>Category:</b> ".$complaint['CategoryName']."<br>

<b>Subcategory:</b> ".$complaint['Subcategory_name']."<br>

<b>Location:</b> ".$complaint['Complaint_locationName']."<br>

<b>Deadline:</b> ".date("d M Y h:i A",strtotime($newDeadline))."<br><br>

Please log in to the SafeRoad UiTM system and take the necessary action as soon as possible.<br><br>

Thank you.<br><br>

<b>SafeRoad UiTM</b><br>
Traffic Complaint Management System

";



if(!empty($police['Police_email'])){

    sendEmail(

        $police['Police_email'],

        $police['Police_fullName'],

        $subject,

        $message

    );

}




header("Location: view_complaint.php?id=".$complaintID);

exit();