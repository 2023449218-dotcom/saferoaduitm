
<?php

session_start();



if(!isset($_SESSION['Role']) || $_SESSION['Role']!="Superior"){

    header("Location: ../index.php");
    exit();
}



include("../db.php");


$superiorID = $_SESSION['SuperiorID'];

$name = $_SESSION['UserName'];



$superiorQuery = mysqli_query(
$conn,
"SELECT *
FROM superior
WHERE SuperiorID='$superiorID'"
);

$superior = mysqli_fetch_assoc($superiorQuery);



$profileImage = !empty($superior['Superior_profile'])
?
"../uploads/profile/".$superior['Superior_profile']
:
"../images/default-profile.png";





$query = mysqli_query(
$conn,
"SELECT
ComplaintID,
Complaint_locationLat,
Complaint_locationLong,
ReferenceNumber,
Complaint_locationName,
Complaint_status
FROM complaint
WHERE
Complaint_locationLat IS NOT NULL
AND
Complaint_locationLong IS NOT NULL
AND
Complaint_status IN
(
'Escalated'
)"
);


$totalMarkers = mysqli_num_rows($query);

?>





<!DOCTYPE html>

<html>

<head>

<title>Escalated Complaint Heatmap | SafeRoad UiTM</title>

<link
rel="stylesheet"
href="https://unpkg.com/leaflet/dist/leaflet.css">

<script
src="https://unpkg.com/leaflet/dist/leaflet.js">
</script>

<link
rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/leaflet.awesome-markers/2.0.4/leaflet.awesome-markers.css">

<script
src="https://cdnjs.cloudflare.com/ajax/libs/leaflet.awesome-markers/2.0.4/leaflet.awesome-markers.js">
</script>

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:Arial,sans-serif;
}

body{
background:#f4f6f9;
}

/* Sidebar */

.sidebar{
width:250px;
height:100vh;
background:#5E2D91;
position:fixed;
left:0;
top:0;
box-shadow:2px 0 10px rgba(0,0,0,0.1);
}

.logo-section{
text-align:center;
padding:20px;
border-bottom:1px solid rgba(255,255,255,0.15);
}

.sidebar-logo{
width:80px;
height:80px;
object-fit:contain;
}

.sidebar h2{
color:white;
font-size:20px;
margin-top:10px;
}

.sidebar a{
display:block;
padding:15px 20px;
color:white;
text-decoration:none;
font-size:15px;
transition:0.3s;
}

.sidebar a:hover{
background:#4b2374;
}

.active{
background:#4b2374;
border-left:5px solid white;
}

/* Topbar */

.topbar{
height:70px;
background:white;
display:flex;
justify-content:flex-end;
align-items:center;
padding:0 30px;
margin-left:250px;
box-shadow:0 2px 10px rgba(0,0,0,0.08);
}

.profile-menu{
display:flex;
align-items:center;
gap:10px;
position:relative;
cursor:pointer;
}

.username{
font-weight:bold;
color:#333;
}

.profile-menu img{
width:45px;
height:45px;
border-radius:50%;
object-fit:cover;
border:2px solid #5E2D91;
}

.dropdown{
display:none;
position:absolute;
right:0;
top:55px;
background:white;
width:180px;
border-radius:10px;
box-shadow:0 5px 15px rgba(0,0,0,0.15);
overflow:hidden;
z-index:9999;
}

.dropdown a{
display:block;
padding:12px 15px;
text-decoration:none;
color:#333;
}

.dropdown a:hover{
background:#f5f5f5;
}

/* Content */

.content{
margin-left:250px;
padding:30px;
}


#map{
height:700px;
width:100%;
border-radius:10px;
box-shadow:0 2px 10px rgba(0,0,0,0.1);
}

.legend{
background:white;
padding:15px;
border-radius:10px;
margin-top:15px;
width:250px;
box-shadow:0 2px 10px rgba(0,0,0,0.1);
}




.dashboard-header{
background:white;
padding:25px 30px;
border-radius:15px;
margin-bottom:25px;
box-shadow:0 2px 10px rgba(0,0,0,0.08);
border-left:5px solid #5E2D91;
}

.dashboard-header h1{
margin-bottom:8px;
font-size:38px;
}

.dashboard-header p{
color:#666;
margin:0;
}

</style>

</head>






<body>

<div class="sidebar">

    <div class="logo-section">

        <img
        src="../images/logo.png"
        class="sidebar-logo">

        <h2>SafeRoad UiTM</h2>

        <p class="sidebar-role">
            Superior
        </p>

    </div>

         <a
        href="dashboard.php">
        Dashboard
        </a>

        <a href="manage_escalated.php">
        Escalated Complaints
        </a>

        <a href="police_performance.php">
        Police Performance
        </a>


        <a href="heatmap.php" class="active">
        Complaint Heatmap
        </a>

</div>






<div class="topbar">

    <div class="profile-menu">

        <span class="username">
            <?php echo $name; ?>
        </span>

        <img
        src="<?php echo $profileImage; ?>"
        alt="Profile"
        onclick="toggleMenu()">

        <div
        id="dropdownMenu"
        class="dropdown">

            <a href="profile.php">
                My Profile
            </a>

            <a href="../logout.php">
                Logout
            </a>

        </div>

    </div>

</div>






<div class="content">

<div class="dashboard-header">

   <h1>Escalated Complaint Heatmap</h1>

    <p>
        Monitor the location of escalated complaints across UiTM Shah Alam.
    </p>

<br>

</div>


<?php if($totalMarkers == 0){ ?>

<div style="
background:#eef8ff;
padding:15px;
border-left:5px solid #0d6efd;
border-radius:10px;
margin-bottom:20px;
color:#0d6efd;
">

ℹ There are currently no escalated complaints to display.

</div>

<?php } ?>


<div id="map"></div>


<div class="legend">

<h3 style="margin-bottom:12px;">

🗺 Map Legend

</h3>

<div style="display:flex;align-items:center;gap:10px;">

<div style="
width:15px;
height:15px;
background:#dc3545;
border-radius:50%;
"></div>

<span>

Escalated Complaint

</span>

</div>

</div>





<script>
var map = L.map('map')
.setView([3.0733,101.4995],15);

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);

</script>




<script>

<?php

mysqli_data_seek($query,0);

while($row =mysqli_fetch_assoc($query)){


$status = $row['Complaint_status'];

if($status=="Escalated"){

   $markerColor = "#dc3545";
}

?>

L.circleMarker(
[
<?php echo $row['Complaint_locationLat']; ?>,
<?php echo $row['Complaint_locationLong']; ?>
],
{
radius:10,
color:'<?php echo $markerColor; ?>',
fillColor:'<?php echo $markerColor; ?>',
fillOpacity:0.8
}
)

.addTo(map)

.bindPopup(
"<b><?php echo addslashes($row['ReferenceNumber']); ?></b><br><br>" +
"📍 <?php echo addslashes($row['Complaint_locationName']); ?><br>" +
"🚨 Status: <b><?php echo $row['Complaint_status']; ?></b><br><br>" +
"<a href='view_complaint.php?id=<?php echo $row['ComplaintID']; ?>'>View Complaint →</a>"
);

<?php } ?>

</script>





<script>

function toggleMenu(){

var menu = document.getElementById("dropdownMenu");

if(menu.style.display=="block"){
menu.style.display="none";
}

else{
menu.style.display="block";
}

}

document.addEventListener("click",function(event){

var menu = document.getElementById("dropdownMenu");

var profile = document.querySelector(".profile-menu");

if(!profile.contains(event.target)){
menu.style.display="none";
}

}
);

</script>




</body>

</html>