<?php



session_start();



if(!isset($_SESSION['Role']) || $_SESSION['Role'] != "Superior"){

    header("Location: ../index.php");
    exit();
}



include("../db.php");



$superiorID = $_SESSION['UserID'];

$name = $_SESSION['UserName'];

$superiorQuery = mysqli_query(
$conn,
"SELECT Superior_profile
FROM superior
WHERE SuperiorID='$superiorID'"
);

$superior = mysqli_fetch_assoc($superiorQuery);



$profileImage = !empty($superior['Superior_profile'])
?
"../uploads/profile/".$superior['Superior_profile']
:
"../images/default-profile.png";



$sql = "
SELECT
c.*,
cc.CategoryName,
cs.Subcategory_name,
cs.Subcategory_risk,
ap.Police_fullName
FROM complaint c
INNER JOIN category cc
ON c.CategoryID = cc.CategoryID
INNER JOIN subcategory cs
ON c.SubcategoryID = cs.SubcategoryID
LEFT JOIN auxiliary_police ap
ON c.PoliceID = ap.PoliceID
WHERE c.Complaint_status='Escalated'
ORDER BY
FIELD(
cs.Subcategory_risk,
'High',
'Medium',
'Low'
),
c.Complaint_deadline ASC
";

$complaints = mysqli_query($conn,$sql);

$totalEscalated = mysqli_num_rows($complaints);

mysqli_data_seek($complaints,0);

?>







<!DOCTYPE html>

<html>

<head>

<link rel="icon" type="image/png" href="../images/logo.png">

<title>Escalated Complaints</title>

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:Arial,sans-serif;
}

body{
background:#f4f6f9;
}

/* Sidebar */

.sidebar{
width:250px;
height:100vh;
background:#5E2D91;
position:fixed;
left:0;
top:0;
box-shadow:2px 0 10px rgba(0,0,0,0.1);
}

.logo-section{
text-align:center;
padding:20px;
border-bottom:1px solid rgba(255,255,255,0.15);
}

.sidebar-logo{
width:80px;
height:80px;
object-fit:contain;
}

.sidebar h2{
color:white;
font-size:20px;
margin-top:10px;
}

.sidebar a{
display:block;
padding:15px 20px;
color:white;
text-decoration:none;
font-size:15px;
transition:0.3s;
}

.sidebar a:hover{
background:#4b2374;
}

.active{
background:#4b2374;
border-left:5px solid white;
}

/* Topbar */

.topbar{
height:70px;
background:white;
display:flex;
justify-content:flex-end;
align-items:center;
padding:0 30px;
margin-left:250px;
box-shadow:0 2px 10px rgba(0,0,0,0.08);
}

.profile-menu{
display:flex;
align-items:center;
gap:10px;
position:relative;
cursor:pointer;
}

.username{
font-weight:bold;
color:#333;
}

.profile-menu img{
width:45px;
height:45px;
border-radius:50%;
object-fit:cover;
border:2px solid #5E2D91;
}

.dropdown{
display:none;
position:absolute;
right:0;
top:55px;
background:white;
width:180px;
border-radius:10px;
box-shadow:0 5px 15px rgba(0,0,0,0.15);
overflow:hidden;
z-index:9999;
}

.dropdown a{
display:block;
padding:12px 15px;
text-decoration:none;
color:#333;
}

.dropdown a:hover{
background:#f5f5f5;
}

/* Content */

.content{
margin-left:250px;
padding:30px;
}




.search-box{
margin-bottom:20px;
}

.search-box input{
width:350px;
padding:10px;
border:1px solid #ccc;
border-radius:5px;
}



table{
width:100%;
background:white;
border-collapse:collapse;
border-radius:10px;
overflow:hidden;
box-shadow:0 2px 10px rgba(0,0,0,0.1);
}

th{
background:#5E2D91;
color:white;
padding:12px;
}

td{
padding:12px;
border-bottom:1px solid #ddd;
}



.btn{
background:#5E2D91;
color:white;
padding:8px 15px;
text-decoration:none;
border-radius:5px;
}

.btn:hover{
background:#4b2374;
}





.dashboard-header{
background:white;
padding:25px 30px;
border-radius:15px;
margin-bottom:25px;
box-shadow:0 2px 10px rgba(0,0,0,0.08);
border-left:5px solid #5E2D91;
}

.dashboard-header h1{
margin-bottom:8px;
font-size:38px;
}

.dashboard-header p{
color:#666;
margin:0;
}


</style>

</head>




<body>

<div class="sidebar">

    <div class="logo-section">

        <img
        src="../images/logo.png"
        class="sidebar-logo">

        <h2>SafeRoad UiTM</h2>

        <p class="sidebar-role">
            Superior
        </p>

    </div>

         <a
        href="dashboard.php">

        Dashboard

        </a>

        <a href="manage_escalated.php" class="active">
        Escalated Complaints
        </a>

        <a href="police_performance.php">
        Police Performance
        </a>


        <a href="heatmap.php">
        Complaint Heatmap
        </a>

</div>






<div class="topbar">

    <div class="profile-menu">

        <span class="username">
            <?php echo $name; ?>
        </span>

        <img
        src="<?php echo $profileImage; ?>"
        alt="Profile"
        onclick="toggleMenu()">

        <div
        id="dropdownMenu"
        class="dropdown">

            <a href="profile.php">
                My Profile
            </a>

            <a href="../logout.php">
                Logout
            </a>

        </div>

    </div>

</div>



<div class="content">

<div class="dashboard-header">

<h1>Escalated Complaints</h1>

<p>Monitor, manage and review escalated complaints that require superior attention.</p>

</div>

<br>





<div class="search-box">

<input
type="text"

id="searchInput"

placeholder="Search Reference Number, Issue, Risk Level or Police">

</div>




<table>

<tr>

<th>Reference No</th>

<th>Category</th>

<th>Subcategory</th>

<th>Risk</th>

<th>Assigned Police</th>

<th>Deadline</th>

<th>Action</th>

</tr>

<div style="
background:white;
padding:15px 20px;
border-radius:10px;
margin-bottom:20px;
box-shadow:0 2px 10px rgba(0,0,0,0.08);
">

<b>Total Escalated Complaints:</b>

<?php echo mysqli_num_rows($complaints); ?>

</div>

<?php

while(
$row =
mysqli_fetch_assoc($complaints)
){

?>

<tr>

<td>
<?php echo $row['ReferenceNumber']; ?>
</td>

<td>
<?php echo $row['CategoryName']; ?>
</td>

<td>
<?php echo $row['Subcategory_name']; ?>
</td>

<td>

<?php

if(
$row['Subcategory_risk']=="High"
){
echo "<span style='color:red;font-weight:bold;'>High</span>";
}
elseif(
$row['Subcategory_risk']=="Medium"
){
echo "<span style='color:orange;font-weight:bold;'>Medium</span>";
}
else{
echo "<span style='color:green;font-weight:bold;'>Low</span>";
}

?>

</td>

<td>

<?php

echo
$row['Police_fullName']
?
$row['Police_fullName']
:
"Not Assigned";

?>

</td>

<td>

<?php

echo date(
"d M Y h:i A",
strtotime(
$row['Complaint_deadline']
)
);

?>

</td>

<td>

<a
href="view_complaint.php?id=<?php echo $row['ComplaintID']; ?>"
class="btn">

View

</a>

</td>

</tr>

<?php } ?>

</table>

</div>




<script>

document
.getElementById("searchInput")
.addEventListener(
"keyup",
function(){

var value =
this.value.toLowerCase();

var rows =
document.querySelectorAll("table tr");

for(
var i=1;
i<rows.length;
i++
){

var text =
rows[i].innerText.toLowerCase();

rows[i].style.display =
text.includes(value)
?
""
:
"none";

}

}
);

</script>



<script>

function toggleMenu(){

var menu = document.getElementById(
"dropdownMenu"
);

if(menu.style.display=="block"){
menu.style.display="none";
}

else{
menu.style.display="block";
}

}

document.addEventListener("click",function(event){

var menu = document.getElementById("dropdownMenu");

var profile = document.querySelector(".profile-menu");

if(!profile.contains(event.target)){
menu.style.display="none";
}

}
);

</script>


</body>
</html>










