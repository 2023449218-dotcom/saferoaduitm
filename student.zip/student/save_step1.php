<?php

/* Start user session */
session_start();


/*=====================================================
    Store Complaint Information

    Save the complaint details entered by the user
    into session variables so the information can
    be used throughout the multi-step complaint
    submission process.
=====================================================*/

$_SESSION['CategoryID'] = $_POST['CategoryID'];

$_SESSION['SubcategoryID'] = $_POST['SubcategoryID'];

$_SESSION['Complaint_desc'] = $_POST['Complaint_desc'];


/* Redirect to Complaint Submission Step 2 */
header("Location: submit_complaint_step2.php");


/* Ensure the page is accessed through a POST request */
if ($_SERVER['REQUEST_METHOD'] != 'POST') {

    header("Location: submit_complaint_step1.php");

    exit();

}


/* Stop further script execution */
exit();

?>