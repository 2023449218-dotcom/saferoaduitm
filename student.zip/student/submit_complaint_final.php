<?php

session_start();


/* Set Malaysia timezone */
date_default_timezone_set('Asia/Kuala_Lumpur');



if (!isset($_SESSION['Role']) || $_SESSION['Role'] != "Student") {

    header("Location: ../index.php");

    exit();

}


/* Load database connection */
include("../db.php");



$role = $_SESSION['Role'];

$studentID = $_SESSION['UserID'];



/*=====================================================
    Retrieve Complaint Information

    Load all complaint data stored in session variables
    during the multi-step complaint submission process.
=====================================================*/
$categoryID = $_SESSION['CategoryID'];

$subcategoryID = $_SESSION['SubcategoryID'];

$description = $_SESSION['Complaint_desc'];




$evidence1 = $_SESSION['Evidence1'] ?? "";

$evidence2 = $_SESSION['Evidence2'] ?? "";

$evidence3 = $_SESSION['Evidence3'] ?? "";




$locationName = $_SESSION['Complaint_locationName'];

$locationDescription = $_SESSION['Complaint_locationDesc'];

$latitude = $_SESSION['Complaint_locationLat'];

$longitude = $_SESSION['Complaint_locationLong'];




$vehiclePlateNo = $_SESSION['Vehicle_plateNum'] ?? "";

$vehicleColor = $_SESSION['Vehicle_color'] ?? "";

$vehicleModel = $_SESSION['Vehicle_model'] ?? "";

$vehicleType = $_SESSION['Vehicle_type'] ?? "";




$year = date("Y");



/*=====================================================
    Generate Complaint Reference Number

    Format:
    SR + Current Year + Running Number

    Example:
    SR202600001
=====================================================*/
$getLast = mysqli_query(
$conn,
"SELECT ComplaintID
FROM complaint
ORDER BY ComplaintID DESC
LIMIT 1"
);

$last = mysqli_fetch_assoc($getLast);

$nextID = ($last['ComplaintID'] ?? 0) + 1;

$referenceNumber = "SR".$year.str_pad($nextID,5,"0",STR_PAD_LEFT);



/*=====================================================
    Calculate Complaint Deadline

    Retrieve the resolution time from the selected
    complaint subcategory and calculate the deadline.
=====================================================*/
$subcategoryQuery = mysqli_query(
$conn,
"SELECT Subcategory_resolutionTime
FROM subcategory
WHERE SubcategoryID='$subcategoryID'"
);

$subcategory = mysqli_fetch_assoc(
$subcategoryQuery
);

$hours = $subcategory['Subcategory_resolutionTime'];

$deadlineDate = date("Y-m-d H:i:s",strtotime("+$hours hours"));




$description = 
mysqli_real_escape_string($conn, $description);

$locationName = 
mysqli_real_escape_string($conn, $locationName);

$locationDescription = 
mysqli_real_escape_string($conn, $locationDescription);




/*=====================================================
    Save Complaint Information
=====================================================*/
$sql = "
INSERT INTO Complaint
(
    ReferenceNumber,
    StudentID,
    CategoryID,
    SubcategoryID,

    Complaint_desc,

    Complaint_locationName,
    Complaint_locationDesc,
    Complaint_locationLat,
    Complaint_locationLong,

    Complaint_status,
    Complaint_deadline
)

VALUES
(
    '$referenceNumber',
    '$studentID',
    '$categoryID',
    '$subcategoryID',

    '$description',

    '$locationName',
    '$locationDescription',
    '$latitude',
    '$longitude',

    'Pending',
    '$deadlineDate'
)";


$result = mysqli_query($conn, $sql);

if (!$result) {
    die(mysqli_error($conn));
}





$complaintID = mysqli_insert_id($conn);



/*=====================================================
    Save Reported Vehicle Information

    Check whether the reported vehicle exists
    in the Vehicle table.

    If found:
        Store VehicleID.

    Otherwise:
        Save only the reported vehicle details.
=====================================================*/
$vehicleQuery = mysqli_query(
    $conn,
    "SELECT VehicleID
     FROM Vehicle
     WHERE Vehicle_plateNum='$vehiclePlateNo'"
);

$vehicle = mysqli_fetch_assoc($vehicleQuery);

$vehicleID = $vehicle['VehicleID'] ?? "NULL";

$vehiclePlateNo = mysqli_real_escape_string($conn, $vehiclePlateNo);
$vehicleType    = mysqli_real_escape_string($conn, $vehicleType);
$vehicleColor   = mysqli_real_escape_string($conn, $vehicleColor);
$vehicleModel   = mysqli_real_escape_string($conn, $vehicleModel);

$result = mysqli_query(
$conn,
"INSERT INTO ComplaintVehicle
(
    ComplaintID,
    VehicleID,
    Reported_plateNum,
    Reported_type,
    Reported_color,
    Reported_model
)
VALUES
(
    '$complaintID',
    ".($vehicleID=="NULL" ? "NULL" : "'$vehicleID'").",
    '$vehiclePlateNo',
    '$vehicleType',
    '$vehicleColor',
    '$vehicleModel'
)"
);

if(!$result){
    die(mysqli_error($conn));
}





/*=====================================================
    Save Complaint Evidence

    Store uploaded images/videos into
    the Evidence table.
=====================================================*/
if($evidence1!=""){

$fileType = "Image";

if(preg_match('/\.(mp4|avi|mov)$/i',$evidence1)){

    $fileType = "Video";

}

$result = mysqli_query(
$conn,
"INSERT INTO Evidence
(
    ComplaintID,
    Evidence_fileName,
    Evidence_fileType,
    Evidence_uploadDate,
    Evidence_type
)

VALUES
(
    '$complaintID',
    '$evidence1',
    '$fileType',
    NOW(),
    'Complaint'
)"

);

if(!$result){

    die(mysqli_error($conn));

}

}







if($evidence2!=""){

$fileType = "Image";

if(preg_match('/\.(mp4|avi|mov)$/i',$evidence2)){

    $fileType = "Video";

}

$result = mysqli_query(
$conn,
"INSERT INTO Evidence
(
    ComplaintID,
    Evidence_fileName,
    Evidence_fileType,
    Evidence_uploadDate,
    Evidence_type
)

VALUES
(
    '$complaintID',
    '$evidence2',
    '$fileType',
    NOW(),
    'Complaint'
)"

);

if(!$result){

    die(mysqli_error($conn));

}

}






if($evidence3!=""){

$fileType = "Image";

if(preg_match('/\.(mp4|avi|mov)$/i',$evidence3)){

    $fileType = "Video";

}

$result = mysqli_query(
$conn,
"INSERT INTO Evidence
(
    ComplaintID,
    Evidence_fileName,
    Evidence_fileType,
    Evidence_uploadDate,
    Evidence_type
)

VALUES
(
    '$complaintID',
    '$evidence3',
    '$fileType',
    NOW(),
    'Complaint'
)"

);

if(!$result){

    die(mysqli_error($conn));

}

}








/*=====================================================
    Create Initial Complaint Timeline

    Record the first complaint activity after
    successful submission.
=====================================================*/
mysqli_query(
$conn,
"INSERT INTO Complaint_timeline
(
    ComplaintID,
    TimelineDesc,
    TimelineDate
)

VALUES
(
    '$complaintID',
    'Complaint submitted by student.',
    NOW()
)"
);






$subcategoryQuery = mysqli_query(
    $conn,
    "SELECT Subcategory_name
     FROM Subcategory
     WHERE SubcategoryID='$subcategoryID'"
);

$subcategory = mysqli_fetch_assoc($subcategoryQuery);

$subcategoryName = $subcategory['Subcategory_name'];




$categoryQuery = mysqli_query(
    $conn,
    "SELECT CategoryName
     FROM Category
     WHERE CategoryID='$categoryID'"
);

$category = mysqli_fetch_assoc($categoryQuery);

$categoryName = $category['CategoryName'];






/*=====================================================
    Retrieve User Information

    Retrieve the user's email address,
    notification preference, and Telegram ID.
=====================================================*/

$userEmail = "";

$userName = "";

$staffID = $_SESSION['UserID'] ?? "";

if($role == "Student"){

    $userQuery = mysqli_query(
    $conn,
    "SELECT *
    FROM student
    WHERE StudentID='$studentID'"
    );

    $user = mysqli_fetch_assoc(
    $userQuery
    );

    $userEmail = $user['Student_email'];

    $userName = $user['Student_fullName'];

}

else{

    $userQuery = mysqli_query(
    $conn,
    "SELECT *
    FROM staff
    WHERE StaffID='$staffID'"
    );

    $user = mysqli_fetch_assoc(
    $userQuery
    );

    $userEmail = $user['Staff_email'];

    $userName = $user['Staff_fullName'];

}

include("../includes/send_email.php");


$subject = "SafeRoad UiTM - Complaint Submitted Successfully";

$message = "

<h2>Complaint Submitted Successfully</h2>

<p>

Dear ".$userName.",

</p>

<p>

Your complaint has been successfully submitted.

</p>

<hr>

<b>Reference Number:</b>
".$referenceNumber."

<br><br>

<b>Category:</b>
".$category['CategoryName']."

<br><br>

<b>Subcategory:</b>
".$subcategoryName."

<br><br>

<b>Status:</b>
Pending

<br><br>

<b>Location:</b>
".$locationName."

<hr>

<p>

Please keep your reference number for future tracking.

</p>

<p>

Thank you.

<br>

SafeRoad UiTM

</p>

";

$notificationPreference = $user['notification_preference'];

if($notificationPreference == "Email"){


/*=====================================================
    Send Complaint Notification

    Notification is sent based on the user's
    preferred notification method:
    - Email
    - Telegram
=====================================================*/
sendEmail(
$userEmail,
$userName,
$subject,
$message
);

}

else{

include("../includes/send_telegram.php");

$telegramMessage =

        "🚨 SafeRoad UiTM\n\n".

        "Complaint Submitted Successfully\n\n".

        "Reference Number: ".$referenceNumber.

        "\n\nCategory: ".$category['CategoryName'].

        "\n\nSubcategory: ".$subcategoryName.

        "\n\nStatus: Pending".

        "\n\nLocation: ".$locationName;

        sendTelegram($user['telegram_chatID'],$telegramMessage);

}



/*=====================================================
    Clear Temporary Session Data

    Remove all complaint information stored during
    the submission process.
=====================================================*/
unset($_SESSION['CategoryID']);
unset($_SESSION['SubcategoryID']);
unset($_SESSION['Complaint_desc']);

unset($_SESSION['Evidence1']);
unset($_SESSION['Evidence2']);
unset($_SESSION['Evidence3']);

unset($_SESSION['Vehicle_plateNum']);
unset($_SESSION['Vehicle_type']);
unset($_SESSION['Vehicle_color']);
unset($_SESSION['Vehicle_model']);

unset($_SESSION['Complaint_locationLat']);
unset($_SESSION['Complaint_locationLong']);
unset($_SESSION['Complaint_locationName']);
unset($_SESSION['Complaint_locationDesc']);





$_SESSION['referenceNumber'] = $referenceNumber;

$_SESSION['complaintID'] = $complaintID;


/* Redirect to Complaint Success Page */
header("Location: complaint_success.php?ref=".$referenceNumber);

exit();







