<?php


/* Load database connection */
include("../db.php");



/* Retrieve selected category and previously selected
   subcategory from the AJAX request */
$categoryID = intval($_GET['CategoryID']);

$selectedSubcategory = $_GET['selected'] ?? "";



/* Retrieve all subcategories that belong to the
   selected complaint category */
$query = mysqli_query(
$conn,
"SELECT *
FROM subcategory
WHERE CategoryID='$categoryID'
ORDER BY Subcategory_name"
);



/* Display the default dropdown option */
echo
"<option value=''>
Select Subcategory
</option>";


/* Generate each subcategory option */
while($row = mysqli_fetch_assoc($query)){

$selected = "";


/* Preserve the previously selected subcategory
   when returning to this page */
if($row['SubcategoryID'] == $selectedSubcategory){

	$selected = "selected";
}


echo

"<option value='".$row['SubcategoryID']."' ".$selected.">"

.$row['Subcategory_name'].

"</option>";

}

?>