<?php

session_start();


/*=====================================================
    Session Validation

    Allow access only to authenticated Student users.
=====================================================*/
if(!isset($_SESSION['Role']) || $_SESSION['Role'] != "Student"){

    header("Location: ../index.php");

    exit();
}



/* Load database connection */
include("../db.php");



/* Retrieve logged-in student's session information */
$studentID = $_SESSION['UserID'];

$name = $_SESSION['UserName'];




/*=====================================================
    Retrieve Student Profile Information
=====================================================*/
$studentQuery = mysqli_query(
$conn,
"SELECT *
FROM student
WHERE StudentID='$studentID'"
);

$student = mysqli_fetch_assoc($studentQuery);


/* Display uploaded profile image or default image */
$profileImage = !empty($student['Student_profile'])
?
"../uploads/profile/".$student['Student_profile']
:
"../images/default-profile.png";




/*=====================================================
    Restore previously entered form values.

    This allows users to return to this page without
    losing their inputs.
=====================================================*/
$selectedCategory = $_SESSION['CategoryID'] ?? "";

$selectedSubcategory = $_SESSION['SubcategoryID'] ?? "";

$description = $_SESSION['Complaint_desc'] ?? "";



/* Retrieve all complaint categories */
$categoryQuery = mysqli_query(
$conn,
"SELECT CategoryID, CategoryName
FROM Category
ORDER BY CategoryName;"
);

?>






<!DOCTYPE html>

<html>

<head>

<link rel="icon" type="image/png" href="../images/logo.png">

<title>Submit Complaint</title>

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:Arial,sans-serif;
}

body{
background:#f4f6f9;
}

/* Sidebar */

.sidebar{
width:250px;
height:100vh;
background:#5E2D91;
position:fixed;
left:0;
top:0;
box-shadow:2px 0 10px rgba(0,0,0,0.1);
}

.logo-section{
text-align:center;
padding:20px;
border-bottom:1px solid rgba(255,255,255,0.15);
}

.sidebar-logo{
width:80px;
height:80px;
object-fit:contain;
}

.sidebar h2{
color:white;
font-size:20px;
margin-top:10px;
}

.sidebar a{
display:block;
padding:15px 20px;
color:white;
text-decoration:none;
font-size:15px;
transition:0.3s;
}

.sidebar a:hover{
background:#4b2374;
}

.active{
background:#4b2374;
border-left:5px solid white;
}

/* Topbar */

.topbar{
height:70px;
background:white;
display:flex;
justify-content:flex-end;
align-items:center;
padding:0 30px;
margin-left:250px;
box-shadow:0 2px 10px rgba(0,0,0,0.08);
}

.profile-menu{
display:flex;
align-items:center;
gap:10px;
position:relative;
cursor:pointer;
}

.username{
font-weight:bold;
color:#333;
}

.profile-menu img{
width:45px;
height:45px;
border-radius:50%;
object-fit:cover;
border:2px solid #5E2D91;
}

.dropdown{
display:none;
position:absolute;
right:0;
top:55px;
background:white;
width:180px;
border-radius:10px;
box-shadow:0 5px 15px rgba(0,0,0,0.15);
overflow:hidden;
z-index:9999;
}

.dropdown a{
display:block;
padding:12px 15px;
text-decoration:none;
color:#333;
}

.dropdown a:hover{
background:#f5f5f5;
}

.container{
width:calc(100% - 320px);
margin-left:280px;
margin-top:30px;
background:white;
padding:30px;
border-radius:10px;
}

.step-bar{
display:flex;
margin-bottom:30px;
}

.step{
flex:1;
padding:12px;
text-align:center;
background:#e9ecef;
margin-right:5px;
border-radius:8px;
}


.form-group{
margin-bottom:20px;
}



label{
display:block;
margin-bottom:8px;
font-weight:bold;
}

select,
textarea{
width:100%;
padding:12px;
border:1px solid #ccc;
border-radius:5px;
}

textarea{
height:120px;
resize:none;
}

.info-box{
background:#f8f9fa;
padding:15px;
border-left:5px solid #5E2D91;
border-radius:5px;
margin-bottom:20px;
}


.btn{
background:#5E2D91;
color:white;
padding:12px 25px;
border:none;
border-radius:5px;
cursor:pointer;
}

.btn:hover{
background:#4b2374;
}


.step-bar{
display:flex;
justify-content:space-between;
margin-bottom:30px;
}

.step{
flex:1;
text-align:center;
padding:12px;
background:#e9ecef;
margin-right:5px;
border-radius:8px;
font-size:14px;
}

.step.active{
background:#5E2D91;
color:white;
font-weight:bold;
}

.active{
background:#4b2374;
border-left:5px solid white;
}

.container{
width:calc(100% - 320px);
max-width:none;
margin-left:280px;
margin-top:30px;
margin-right:30px;
background:white;
padding:30px;
border-radius:10px;
box-shadow:0 2px 10px rgba(0,0,0,0.1);
}


.progress-container{
display:flex;
align-items:center;
justify-content:space-between;
margin-bottom:40px;
}

.progress-step{
text-align:center;
display:flex;
flex-direction:column;
align-items:center;
}

.circle{
width:50px;
height:50px;
border-radius:50%;
background:#d8d8d8;
color:#555;
font-weight:bold;
font-size:18px;
display:flex;
align-items:center;
justify-content:center;
}

.progress-step.current .circle{
background:#5E2D91;
color:white;
box-shadow:0 4px 10px rgba(94,45,145,0.3);
}

.progress-step.completed .circle{
background:#28a745;
color:white;
}


.line{
flex:1;
height:3px;
background:#d8d8d8;
margin:0 10px;
margin-bottom:25px;
border-radius:10px;
}

.button-group{
display:flex;
justify-content:space-between;
margin-top:30px;
}

</style>

</head>

<body>

<!-- Sidebar Navigation -->
<div class="sidebar">

    <div class="logo-section">

    <img
    src="../images/logo.png"
    class="sidebar-logo">

    <h2>SafeRoad UiTM</h2>

    </div>

    <a href="dashboard.php">Dashboard</a>

    <a href="submit_complaint_step1.php" class="active" >Submit Complaint</a>

    <a href="my_complaints.php">My Complaints</a>

</div>



<!-- Sidebar Navigation -->
<div class="topbar">

    <div class="profile-menu">

    <span class="username">
    <?php echo $name; ?>
    </span>

    <img
    src="<?php echo $profileImage; ?>"
    alt="Profile"
    onclick="toggleMenu()">


        <div
        id="dropdownMenu"
        class="dropdown">

        <a href="profile.php">My Profile</a>

        <a href="../logout.php">Logout</a>

        </div>

    </div>

</div>


<!-- Complaint Submission Form -->

<div class="container"> 

    <h2>Submit Complaint</h2>

    <p style="
    color:#666;
    margin-top:10px;
    margin-bottom:25px;
    ">Step 1 of 5: Select complaint category and provide a description.</p>

    <br>

    <!-- Multi-Step Progress Indicator -->
    <div class="progress-container">

        <div class="progress-step current">
        <div class="circle">1</div>
        <p>Details</p>
        </div>

        <div class="line"></div>

        <div class="progress-step">
        <div class="circle">2</div>
        <p>Evidence</p>
        </div>

        <div class="line"></div>

        <div class="progress-step">
        <div class="circle">3</div>
        <p>Vehicle</p>
        </div>

        <div class="line"></div>

        <div class="progress-step">
        <div class="circle">4</div>
        <p>Location</p>
        </div>

        <div class="line"></div>

        <div class="progress-step">
        <div class="circle">5</div>
        <p>Review</p>
        </div>

    </div>



<!-- Step 1 Complaint Form -->
<form action="save_step1.php" method="POST">

<div class="form-group">

    <label>Category</label>

    <select
    id="category"
    name="CategoryID"
    required>

    <option value="">
    Select Category
    </option>

    <?php
    while($category=mysqli_fetch_assoc($categoryQuery)){
    ?>

    <option
    value="<?php echo $category['CategoryID']; ?>"
    <?php
    if(
    $selectedCategory == $category['CategoryID']){
    echo "selected";
    }
    ?>>

    <?php echo $category['CategoryName']; ?>
    </option>

    <?php } ?>

    </select>

</div>




<div class="form-group">

    <label>Subcategory</label>

    <select
    id="subcategory"
    name="SubcategoryID"
    required>

    <option value="">
    Select Category First
    </option>

    </select>

</div>




<div
class="info-box"
id="infoBox"
style="display:none;">

<p>
<b>Risk Level:</b>
<span id="risk"></span>
</p>

<br>

<p>
<b>Resolution Target:</b>
<span id="target"></span>
</p>

</div>




<div class="form-group">

<br>

<label>Description</label>

<textarea
id="description"
name="Complaint_desc"
maxlength="150"
required><?php echo $description; ?></textarea>

<div
id="charCount"
style="
text-align:right;
font-size:12px;
color:#666;
margin-top:5px;
">
0 / 150 characters
</div>

<div class="button-group">


<button
type="submit"
class="btn">

Next Step →

</button>

</div>

</form>






<script>

/*=====================================================
    Restore Selected Subcategory
=====================================================*/

var selectedSubcategory = "<?php echo $selectedSubcategory; ?>";

</script>




<script>

/*=====================================================
    Load Complaint Subcategories

    Retrieve subcategories dynamically based on the
    selected complaint category using AJAX.
=====================================================*/

document.getElementById("category").addEventListener("change",

function(){

    var categoryID = this.value;

    var xhr = new XMLHttpRequest();

    xhr.open("GET", "get_subcategory.php?CategoryID="
    + categoryID + "&selected="
    + selectedSubcategory,
    true
    );

    xhr.onload = function(){

        if(xhr.status==200){

        document.getElementById("subcategory")
        .innerHTML = xhr.responseText;

        }

    };

    xhr.send();

}

);

window.onload = function(){

    var category = document.getElementById("category");

    if(category.value != ""){

    category.dispatchEvent(new Event("change"));

    setTimeout(

    function(){

        if(selectedSubcategory!=""){

        document.getElementById("subcategory")
        .value = selectedSubcategory;

        document.getElementById("subcategory")
        .dispatchEvent(new Event("change")
        );

        }

    },
    500
    );

    }

};

</script>






<script>

/*=====================================================
    Toggle Profile Dropdown Menu
=====================================================*/

function toggleMenu(){

    var menu = document.getElementById(
    "dropdownMenu");

    if(menu.style.display=="block"){

        menu.style.display="none";

    }

    else{

         menu.style.display="block";

    }

}

document.addEventListener("click",

function(event){

    var menu = document.getElementById("dropdownMenu");

    var profile = document.querySelector(".profile-menu");

    if(!profile.contains(event.target)){

         menu.style.display="none";

    }

}

);

</script>





<script>

/*=====================================================
    Display Risk Level and Resolution Target

    Retrieve complaint information dynamically based
    on the selected subcategory.
=====================================================*/

document.getElementById("subcategory").addEventListener(
"change",

function(){

var subcategoryID = this.value;

if(subcategoryID==""){

    document.getElementById("infoBox").style.display="none";

    return;

}

var xhr = new XMLHttpRequest();

xhr.open("GET","get_subcategory_info.php?SubcategoryID="+subcategoryID,
true
);

xhr.onload =

function(){

    if(xhr.status==200){

        try{

            var data = JSON.parse(xhr.responseText);

        }catch(e){

            console.log(xhr.responseText);
            return;

        }

        console.log(data);

        if(data){

            document.getElementById("infoBox").style.display="block";

        }
        else{

            document.getElementById("infoBox").style.display="none";

        }

        document.getElementById("risk")
        .innerHTML = data.Subcategory_risk;

        var target = document.getElementById("target");
        var hours = parseInt(data.Subcategory_resolutionTime);

        if(hours == 24){
            target.innerHTML = "1 Day";
        }
        else if(hours == 168){
            target.innerHTML = "7 Days";
        }
        else if(hours == 336){
            target.innerHTML = "14 Days";
        }
        else{
            target.innerHTML = hours + " Hours";
        }

    }

};

xhr.send();

});

</script>





<script>

/*=====================================================
    Character Counter

    Display the number of characters entered in the
    complaint description.
=====================================================*/

var textarea = document.getElementById("description");

var counter = document.getElementById("charCount");

function updateCount(){

counter.innerHTML = textarea.value.length + " / 150 characters";

}

textarea.addEventListener("input",updateCount);

updateCount();

</script>

</body>

</html>