<?php

session_start();


/*=====================================================
    Ensure the page is accessed through
    a POST request.
=====================================================*/

if ($_SERVER['REQUEST_METHOD'] != 'POST') {

    header("Location: submit_complaint_step4.php");

    exit();

}


/*=====================================================
    Store Complaint Location

    Save the complaint location information into
    session variables so it can be displayed on the
    review page before the complaint is submitted.
=====================================================*/

$_SESSION['Complaint_locationLat'] = $_POST['Complaint_locationLat'];

$_SESSION['Complaint_locationLong'] = $_POST['Complaint_locationLong'];

$_SESSION['Complaint_locationName'] = $_POST['Complaint_locationName'];

$_SESSION['Complaint_locationDesc'] = $_POST['Complaint_locationDesc'];


/* Redirect to Complaint Review Page */
header("Location: review_complaint.php");

exit();

?>