<?php

session_start();



$slot =
$_GET['slot'];



if($slot==1){

$file =
$_SESSION['Evidence1'];

if(file_exists(
"../uploads/evidence/".$file
)){
unlink(
"../uploads/evidence/".$file
);
}

unset(
$_SESSION['Evidence1']
);

}





if($slot==2){

$file =
$_SESSION['Evidence2'];

if(file_exists(
"../uploads/evidence/".$file
)){
unlink(
"../uploads/evidence/".$file
);
}

unset(
$_SESSION['Evidence2']
);

}




if($slot==3){

$file =
$_SESSION['Evidence3'];

if(file_exists(
"../uploads/evidence/".$file
)){
unlink(
"../uploads/evidence/".$file
);
}

unset(
$_SESSION['Evidence3']
);

}




header(
"Location: submit_complaint_step2.php"
);

exit();

?>