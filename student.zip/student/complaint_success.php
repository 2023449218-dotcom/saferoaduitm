<?php

session_start();


if(!isset($_SESSION['Role'])){

    header("Location: ../index.php");

    exit();
}


/*=====================================================
    Ensure the complaint has just been submitted.

    Prevent users from accessing this page directly
    without submitting a complaint.
=====================================================*/
if(!isset($_SESSION['referenceNumber'])){

    header("Location: dashboard.php");

    exit();
}


/* Retrieve complaint information for display */
$referenceNumber = $_SESSION['referenceNumber'];

$complaintID = $_SESSION['complaintID'];


/* Clear temporary session data after displaying
   the success message */
unset($_SESSION['referenceNumber']);

unset($_SESSION['complaintID']);

?>




<!DOCTYPE html>

<html>

<head>

<link rel="icon" type="image/png" href="../images/logo.png">

<title>Complaint Submitted</title>

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:Arial,sans-serif;
}

body{
background:#f5f5f5;
display:flex;
justify-content:center;
align-items:center;
height:100vh;
}

.card{
background:white;
padding:50px;
border-radius:20px;
box-shadow:0 8px 25px rgba(0,0,0,0.12);
width:650px;
text-align:center;
border-top:6px solid #28a745;
}

.success-icon{
font-size:80px;
color:#28a745;
margin-bottom:20px;
}

h1{
color:#28a745;
margin-bottom:15px;
}

.reference-box{
background:#f3edff;
padding:20px;
border-radius:10px;
margin:25px 0;
}

.reference-box h2{
color:#5E2D91;
margin-bottom:10px;
}

.reference-number{
font-size:28px;
font-weight:bold;
color:#5E2D91;
}

.message{
color:#555;
line-height:1.8;
margin-bottom:25px;
}

.btn{
display:inline-block;
padding:12px 25px;
background:#5E2D91;
color:white;
text-decoration:none;
border-radius:8px;
margin:5px;
}

.btn:hover{
background:#4b2374;
}

</style>

</head>

<body>

<!-- Complaint Submission Success Card -->
<div class="card">

    <!-- Success Icon -->
    <div class="success-icon">
    ✅
    </div>

    <h1>Complaint Submitted Successfully</h1>


    <!-- Complaint Reference Number -->
    <div class="reference-box">

        <h2>Reference Number</h2>

        <div class="reference-number">

        <?php echo htmlspecialchars($referenceNumber); ?>

        </div>

    </div>



<!-- Confirmation Message -->
    <div class="message">

    Your complaint has been successfully submitted.

    <br>

    Please keep your reference number for future tracking.

    You will receive updates through your selected notification method.

    </div>



<!-- View Submitted Complaint -->
    <a
    href="view_complaint.php?id=<?php echo (int)$complaintID; ?>"
    class="btn">

    View Complaint

    </a>


<!-- Return to Dashboard -->
    <a
    href="dashboard.php"
    class="btn">

    Back to Dashboard

    </a>

</div>

</body>

</html>