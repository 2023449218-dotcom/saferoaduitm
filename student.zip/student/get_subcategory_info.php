<?php


/* Load database connection */
include("../db.php");


/* Retrieve the selected subcategory ID */
$subcategoryID = intval($_GET['SubcategoryID']);


/*=====================================================
    Retrieve Risk Level and Resolution Time
=====================================================*/
$query = mysqli_query(
$conn,
"SELECT
Subcategory_risk,
Subcategory_resolutionTime
FROM subcategory
WHERE SubcategoryID='$subcategoryID'"
);


/* Fetch query result */
$row = mysqli_fetch_assoc($query);


/* Return data in JSON format */
echo json_encode($row);

?>