<?php

session_start();


if(!isset($_SESSION['Role']) || $_SESSION['Role'] != "Student"){

    header("Location: ../index.php");
    exit();
}


include("../db.php");



$studentID = $_SESSION['UserID'];

$name = $_SESSION['UserName'];



$studentQuery = mysqli_query(
$conn,
"SELECT *
FROM student
WHERE StudentID='$studentID'"
);

$student = mysqli_fetch_assoc($studentQuery);



$profileImage = !empty($student['Student_profile'])
?
"../uploads/profile/".$student['Student_profile']
:
"../images/default-profile.png";




$vehicleQuery = mysqli_query(
$conn,
"SELECT *
FROM vehicle
WHERE StudentID='$studentID'"
);

?>





<!DOCTYPE html>

<html>

<head>

<link rel="icon" type="image/png" href="../images/logo.png">

<title>Student Profile</title>

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:Arial,sans-serif;
}

body{
background:#f4f6f9;
}

/* Sidebar */

.sidebar{
width:250px;
height:100vh;
background:#5E2D91;
position:fixed;
left:0;
top:0;
box-shadow:2px 0 10px rgba(0,0,0,0.1);
}

.logo-section{
text-align:center;
padding:20px;
border-bottom:1px solid rgba(255,255,255,0.15);
}

.sidebar-logo{
width:80px;
height:80px;
object-fit:contain;
}

.sidebar h2{
color:white;
font-size:20px;
margin-top:10px;
}

.sidebar a{
display:block;
padding:15px 20px;
color:white;
text-decoration:none;
font-size:15px;
transition:0.3s;
}

.sidebar a:hover{
background:#4b2374;
}

.active{
background:#4b2374;
border-left:5px solid white;
}

.content{
margin-left:250px;
padding:30px;
margin-top:20px;
}

.page-title{
    margin-bottom:20px;
}

.card{
    background:white;
    padding:20px;
    border-radius:10px;
    margin-bottom:20px;
    box-shadow:0px 2px 10px rgba(0,0,0,0.1);
}

.card h3{
    color:#5E2D91;
    margin-bottom:15px;
}

.profile-table{
    width:100%;
    border-collapse:collapse;
}

.profile-table td{
    padding:12px;
    border-bottom:1px solid #ddd;
}

.profile-table td:first-child{
    width:220px;
    font-weight:bold;
}

.form-group{
    margin-bottom:15px;
}

.form-group label{
    display:block;
    margin-bottom:5px;
    font-weight:bold;
}

.form-group input,
.form-group select{
    width:100%;
    padding:10px;
    border:1px solid #ccc;
    border-radius:5px;
}

.btn{
    background:#5E2D91;
    color:white;
    border:none;
    padding:10px 20px;
    border-radius:5px;
    cursor:pointer;
}

.btn:hover{
    background:#4b2374;
}

.vehicle-table{
    width:100%;
    border-collapse:collapse;
}

.vehicle-table th{
    background:#5E2D91;
    color:white;
    padding:10px;
}

.vehicle-table td{
    border:1px solid #ddd;
    padding:10px;
    text-align:center;
}

.no-data{
    text-align:center;
    color:gray;
    padding:20px;
}

.topbar{
height:70px;
background:white;
display:flex;
justify-content:flex-end;
align-items:center;
padding:0 30px;
box-shadow:0 2px 10px rgba(0,0,0,0.1);
margin-left:250px;
}

.profile-menu{
display:flex;
align-items:center;
gap:10px;
position:relative;
}

.username{
font-weight:bold;
color:#5E2D91;
}

.profile-menu img{
width:45px;
height:45px;
border-radius:50%;
object-fit:cover;
cursor:pointer;
border:2px solid #5E2D91;
}

.dropdown{
display:none;
position:absolute;
right:0;
top:55px;
background:white;
width:180px;
border-radius:10px;
box-shadow:0 5px 15px rgba(0,0,0,0.15);
overflow:hidden;
z-index:999;
}

.dropdown a{
display:block;
padding:12px 15px;
text-decoration:none;
color:#333;
}

.dropdown a:hover{
background:#f5f5f5;
}


</style>

</head>

<body>

<div class="sidebar">

    <div class="logo-section">

    <img
    src="../images/logo.png"
    class="sidebar-logo">

    <h2>SafeRoad UiTM</h2>

    </div>

    <a href="dashboard.php">Dashboard</a>

    <a href="submit_complaint_step1.php">Submit Complaint</a>

    <a href="my_complaints.php">My Complaints</a>

</div>




<div class="topbar">

    <div class="profile-menu">

        <span class="username">
        <?php echo $name; ?>
        </span>

        <img
        src="<?php echo $profileImage; ?>"
        alt="Profile"
        onclick="toggleMenu()">

        <div
        id="dropdownMenu"
        class="dropdown">

        <a href="profile.php">
        My Profile
        </a>

        <a href="../logout.php">
        Logout
        </a>

        </div>

    </div>

</div>





<div class="content">

    <h1 class="page-title">My Profile</h1>

    <div class="card" style="text-align:center;">

    <img
    src="<?php echo $profileImage; ?>"
    style="
    width:150px;
    height:150px;
    border-radius:50%;
    object-fit:cover;
    border:4px solid #5E2D91;
    ">

    <br><br>

    </div>



<div class="card">

    <h3>Personal Information</h3>

    <table class="profile-table">

        <tr>
            <td>Full Name</td>
            <td><?php echo $student['Student_fullName']; ?></td>
        </tr>

        <tr>
            <td>Matric Number</td>
            <td><?php echo $student['Student_matricNum']; ?></td>
        </tr>

        <tr>
            <td>Faculty</td>
            <td><?php echo $student['Student_faculty']; ?></td>
        </tr>

        <tr>
            <td>Course</td>
            <td><?php echo $student['Student_course']; ?></td>
        </tr>

        <tr>
            <td>Email</td>
            <td><?php echo $student['Student_email']; ?></td>
        </tr>

        <tr>
            <td>Phone Number</td>
            <td><?php echo $student['Student_phoneNumber']; ?></td>
        </tr>

        <tr>
    <td>Notification Preference</td>
    <td>
        <?php echo $student['notification_preference']; ?>
    </td>
</tr>

<tr>
    <td>Telegram Chat ID</td>
    <td>

    <?php

    if(
    empty($student['telegram_chatID'])
    ){
        echo "Not Set";
    }

    else{
        echo $student['telegram_chatID'];
    }

    ?>

    </td>
</tr>

    </table>

</div>




<div class="card">

    <h3>Notification Settings</h3>

    <form action="update_profile.php" method="POST">

        <div class="form-group">

            <label>Notification Preference</label>

            <select name="notification_preference">

                <option value="Email"
                <?php
                if($student['notification_preference']=="Email"){
                    echo "selected";
                }
                ?>>
                Email
                </option>

                <option value="Telegram"
                <?php
                if($student['notification_preference']=="Telegram"){
                    echo "selected";
                }
                ?>>
                Telegram
                </option>

            </select>

        </div>




    <div
    class="form-group"
    id="telegramSection">

    <label>Telegram Chat ID</label>

    <input
    type="text"
    name="telegram_chatID"
    value="<?php echo $student['telegram_chatID']; ?>">

    </div>

        <button type="submit" class="btn">
            Save Notification Settings
        </button>

    </form>

</div>




<div class="card">

    <h3>Registered Vehicle</h3>

    <table class="vehicle-table">

        <tr>

            <th>Plate Number</th>

            <th>Vehicle Type</th>

            <th>Vehicle Color</th>

            <th>Vehicle Model</th>

        </tr>

        <?php

        if(mysqli_num_rows($vehicleQuery) > 0){

            while($vehicle = mysqli_fetch_assoc($vehicleQuery)){

        ?>

        <tr>

            <td>
            <?php echo $vehicle['Vehicle_plateNum']; ?>
            </td>

            <td>
            <?php echo $vehicle['Vehicle_type']; ?>
            </td>

            <td>
            <?php echo $vehicle['Vehicle_color']; ?>
            </td>

            <td>
            <?php echo $vehicle['Vehicle_model']; ?>
            </td>

        </tr>

        <?php

            }

        }

        else{

        ?>

        <tr>

            <td colspan="4" class="no-data">
                No registered vehicle found.
            </td>

        </tr>

        <?php } ?>

    </table>

</div>

</div>










<script>

var preference = document.querySelector(
'select[name="notification_preference"]'
);

var telegramSection = document.getElementById('telegramSection');

function toggleTelegram(){

if(preference.value == "Telegram"){

telegramSection.style.display = "block";}

else{

telegramSection.style.display = "none";

}

}

toggleTelegram();

preference.addEventListener("change",toggleTelegram);

</script>








<script>

function toggleMenu(){

var menu = document.getElementById("dropdownMenu");

if(menu.style.display=="block"){

menu.style.display="none";

}

else{
    menu.style.display="block";
}

}

document.addEventListener("click",

function(event){

var menu = document.getElementById("dropdownMenu");

var profile = document.querySelector(".profile-menu");

if(!profile.contains(event.target)
){

menu.style.display="none";

}

}

);

</script>

</body>

</html>
