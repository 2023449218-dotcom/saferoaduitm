<?php

session_start();

/*=====================================================
    Store Vehicle Information

    Save the vehicle details entered by the user
    into session variables so they can be used
    throughout the complaint submission process.
=====================================================*/
$_SESSION['Vehicle_plateNum'] = $_POST['Vehicle_plateNum'];

$_SESSION['Vehicle_type'] = $_POST['Vehicle_type'];

$_SESSION['Vehicle_color'] = $_POST['Vehicle_color'];

$_SESSION['Vehicle_model'] = $_POST['Vehicle_model'];


/* Redirect to Complaint Submission Step 4 */
header("Location: submit_complaint_step4.php");

exit();

?>