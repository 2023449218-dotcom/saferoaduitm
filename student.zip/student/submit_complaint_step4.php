<?php



session_start();



if(!isset($_SESSION['Role']) || $_SESSION['Role']!="Student"){

	header("Location: ../index.php");

	exit();

}




include("../db.php");




$name = $_SESSION['UserName'];

$studentID = $_SESSION['UserID'];


/*=====================================================
    Restore Complaint Location

    Retrieve previously selected complaint location
    from session variables when returning
    to this page.
=====================================================*/
$latitude = $_SESSION['Complaint_locationLat'] ?? "";
$longitude = $_SESSION['Complaint_locationLong'] ?? "";
$locationName = $_SESSION['Complaint_locationName'] ?? "";



/* Retrieve student's profile information */
$studentQuery = mysqli_query(
$conn,
"SELECT *
FROM student
WHERE StudentID='$studentID'"
);

$student = mysqli_fetch_assoc($studentQuery);


/* Display uploaded profile image or default image */
$profileImage = !empty($student['Student_profile'])
?
"../uploads/profile/".$student['Student_profile']
:
"../images/default-profile.png";

?>





<!DOCTYPE html>

<html>

<head>

<link rel="icon" type="image/png" href="../images/logo.png">

<link
rel="stylesheet"
href="https://unpkg.com/leaflet/dist/leaflet.css">

<script
src="https://unpkg.com/leaflet/dist/leaflet.js">
</script>

<title>Complaint Location</title>

<style>
*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:Arial,sans-serif;
}

body{
background:#f4f6f9;
}

/* Sidebar */

.sidebar{
width:250px;
height:100vh;
background:#5E2D91;
position:fixed;
left:0;
top:0;
box-shadow:2px 0 10px rgba(0,0,0,0.1);
}

.logo-section{
text-align:center;
padding:20px;
border-bottom:1px solid rgba(255,255,255,0.15);
}

.sidebar-logo{
width:80px;
height:80px;
object-fit:contain;
}

.sidebar h2{
color:white;
font-size:20px;
margin-top:10px;
}

.sidebar a{
display:block;
padding:15px 20px;
color:white;
text-decoration:none;
font-size:15px;
transition:0.3s;
}

.sidebar a:hover{
background:#4b2374;
}

.active{
background:#4b2374;
border-left:5px solid white;
}

/* Topbar */

.topbar{
height:70px;
background:white;
display:flex;
justify-content:flex-end;
align-items:center;
padding:0 30px;
margin-left:250px;
box-shadow:0 2px 10px rgba(0,0,0,0.08);
}

.profile-menu{
display:flex;
align-items:center;
gap:10px;
position:relative;
cursor:pointer;
}

.username{
font-weight:bold;
color:#333;
}

.profile-menu img{
width:45px;
height:45px;
border-radius:50%;
object-fit:cover;
border:2px solid #5E2D91;
}

.dropdown{
display:none;
position:absolute;
right:0;
top:55px;
background:white;
width:180px;
border-radius:10px;
box-shadow:0 5px 15px rgba(0,0,0,0.15);
overflow:hidden;
z-index:9999;
}

.dropdown a{
display:block;
padding:12px 15px;
text-decoration:none;
color:#333;
}

.dropdown a:hover{
background:#f5f5f5;
}


.form-group{
margin-bottom:20px;
}

input,
select{
width:100%;
padding:12px;
border:1px solid #ccc;
border-radius:5px;
}

.btn{
background:#5E2D91;
color:white;
padding:12px 25px;
border:none;
border-radius:5px;
cursor:pointer;
}

.back-btn{
background:#6c757d;
}

.container{
width:calc(100% - 320px);
margin-left:280px;
margin-top:30px;
background:white;
padding:30px;
border-radius:10px;
}

.progress-container{
display:flex;
align-items:center;
justify-content:space-between;
margin-bottom:40px;
}

.progress-step{
text-align:center;
display:flex;
flex-direction:column;
align-items:center;
}

.circle{
width:50px;
height:50px;
border-radius:50%;
background:#d8d8d8;
color:#555;
font-weight:bold;
font-size:18px;
display:flex;
align-items:center;
justify-content:center;
}

.progress-step.current .circle{
background:#5E2D91;
color:white;
box-shadow:0 4px 10px rgba(94,45,145,0.3);
}

.progress-step.completed .circle{
background:#28a745;
color:white;
}

.progress-step p{
margin-top:8px;
font-size:13px;
font-weight:500;
color:#666;
}

.line{
flex:1;
height:3px;
background:#d8d8d8;
margin:0 10px;
margin-bottom:25px;
border-radius:10px;
}

.button-group{
display:flex;
justify-content:space-between;
margin-top:30px;
}


</style>

</head>

<body>

<!-- Sidebar Navigation -->
<div class="sidebar">

	<div class="logo-section">

	<img
	src="../images/logo.png"

	class="sidebar-logo">



	<h2>SafeRoad UiTM</h2>

	</div>

	<a href="dashboard.php" >Dashboard</a>

	<a href="submit_complaint_step1.php" class="active" >Submit Complaint</a>

	<a href="my_complaints.php">My Complaints</a>

</div>



<!-- Top Navigation Bar -->
<div class="topbar">

	<div class="profile-menu">

		<span class="username">
		<?php echo $name; ?>
		</span>

		<img
		src="<?php echo $profileImage; ?>"
		alt="Profile"
		onclick="toggleMenu()">

		<div
		id="dropdownMenu"

		class="dropdown">

		<a href="profile.php">My Profile</a>

		<a href="../logout.php">Logout</a>

		</div>

	</div>

</div>





<!-- Complaint Submission - Step 4 -->
<div class="container">

	<h2>Submit Complaint</h2>

	<p style="
	color:#666;
	margin-top:10px;
	margin-bottom:25px;
	">Step 4 of 5: Select complaint location.</p>


	<!-- Multi-Step Progress Indicator -->
	<div class="progress-container">

	<div class="progress-step completed">
	<div class="circle">1</div>
	<p>Details</p>
	</div>

	<div class="line"></div>

	<div class="progress-step completed">
	<div class="circle">2</div>
	<p>Evidence</p>
	</div>

	<div class="line"></div>

	<div class="progress-step completed">
	<div class="circle">3</div>
	<p>Vehicle</p>
	</div>

	<div class="line"></div>

	<div class="progress-step current">
	<div class="circle">4</div>
	<p>Location</p>
	</div>

	<div class="line"></div>

	<div class="progress-step">
	<div class="circle">5</div>
	<p>Review</p>
	</div>

</div>



<!-- Complaint Location Form -->
<form
action="save_step4.php"
method="POST">

<input
type="hidden"
name="Complaint_locationLat"
id="latitude"
value="<?php echo $latitude; ?>">

<input
type="hidden"
name="Complaint_locationLong"
id="longitude"
value="<?php echo $longitude; ?>">





<div class="form-group">

	<label>Current Location</label>

	<br>

	<button
	type="button"
	class="btn"
	onclick="getCurrentLocation()">

	📍 Use Current Location
	</button>



	<div class="form-group">

	<br>

	<label>Search Location</label>

		<div style="display:flex;gap:10px;">

		<input
		type="text"
		id="locationSearch"
		placeholder="Search location...">

		<button
		type="button"
		class="btn"
		onclick="searchLocation()">

		Search

		</button>

		</div>

	<br>


	<label>Location Name</label>

	<input
	type="text"
	name="Complaint_locationName"
	id="locationName"
	value="<?php echo $locationName; ?>"
	readonly
	required>

	</div>


	<!-- Interactive Leaflet Map -->
	<div
	id="map"
	style="
	height:500px;
	border-radius:10px;
	margin-bottom:20px;
	">
	</div>



	<div class="form-group">

	<label>Specific Location Description</label>

	<br>

	<input
	type="text"
	name="Complaint_locationDesc"
	value="<?php echo $_SESSION['Complaint_locationDesc'] ?? ''; ?>"
	placeholder="Example: Behind Faculty of Computer Science, near parking lot B"
	required>

	</div>



	<div class="button-group">

	<a
	href="submit_complaint_step3.php"
	class="btn back-btn"
	style="text-decoration:none;">

	← Previous

	</a>

	<button
	type="submit"
	class="btn">

	Next Step →

	</button>

	</div>


</div>

</form>






<script>

/*=====================================================
    Initialize Leaflet Map
=====================================================*/
var map = L.map('map').setView([3.072038,101.491613],16);

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
{
	maxZoom:19
}

).addTo(map);

var marker;

if(
	document.getElementById("latitude").value != "" &&
	document.getElementById("longitude").value != ""
){

    var lat = parseFloat(document.getElementById("latitude").value);
    var lon = parseFloat(document.getElementById("longitude").value);

    map.setView([lat, lon], 17);

    marker = L.marker([lat, lon]).addTo(map);

}



/*=====================================================
    Select Complaint Location

    Allows users to click anywhere on the map
    to place a complaint marker.
=====================================================*/
map.on('click',

function(e){

var lat = e.latlng.lat;

var lng = e.latlng.lng;

if(marker){

	map.removeLayer(marker);

}

marker = L.marker([lat,lng]).addTo(map);

document.getElementById("latitude").value = lat;

document.getElementById("longitude").value = lng;


fetch(

	"https://nominatim.openstreetmap.org/reverse?format=json&lat="
	+lat+"&lon="+lng
)

.then(response => response.json())

.then(data => {

	document.getElementById("locationName").value = data.display_name;

}

);

}

);


/*=====================================================
    Validate Location Selection

    Ensure a complaint location has been selected
    before proceeding.
=====================================================*/
document.querySelector("form").addEventListener("submit",

function(e){

	if(

		document.getElementById("latitude").value == ""

	){

		alert("Please select a location on the map.");

		e.preventDefault();

	}

}

);


/*=====================================================
    Search Location

    Search for a location using
    OpenStreetMap Nominatim API.
=====================================================*/
function searchLocation(){

var location = document.getElementById("locationSearch").value;

fetch(
	"https://nominatim.openstreetmap.org/search?format=json&q="
	+encodeURIComponent(location)
)

.then(response => response.json())

.then(data => {

if(data.length > 0){

var lat = data[0].lat;

var lon = data[0].lon;

map.setView([lat,lon],17);

if(marker){

	map.removeLayer(marker);

}

marker = L.marker([lat,lon]).addTo(map);

document.getElementById("latitude").value = lat;

document.getElementById("longitude").value = lon;

document.getElementById("locationName").value = data[0].display_name;

}

else{

    alert("Location not found.");
}

});

}



/*=====================================================
    Retrieve User's Current Location

    Uses the browser Geolocation API
    to retrieve the user's current location.
=====================================================*/
function getCurrentLocation(){

if(
	navigator.geolocation
){

navigator.geolocation.getCurrentPosition(

function(position){

var lat = position.coords.latitude;

var lon = position.coords.longitude;

map.setView([lat,lon],18);

if(marker){

	map.removeLayer(marker);

}

marker = L.marker([lat,lon]).addTo(map);

document.getElementById("latitude").value = lat;

document.getElementById("longitude").value = lon;



fetch(

	"https://nominatim.openstreetmap.org/reverse?format=json&lat="
	+lat+"&lon="+lon)

	.then(response => response.json()

)

.then(data => {

if(data.display_name){

    document.getElementById("locationName").value = data.display_name;

}

else{

    document.getElementById("locationName").value =
    "Unknown Location";

}

});

},

function(){

	alert("Unable to retrieve your location.");

}

);

}

else{

	alert("Geolocation is not supported by this browser.");

}

}

</script>







<script>

/*=====================================================
    Toggle Profile Dropdown Menu
=====================================================*/
function toggleMenu()
{

	var menu = document.getElementById("dropdownMenu");

	if(menu.style.display=="block")
	{
		menu.style.display="none";
	}

	else
	{
		menu.style.display="block";
	}

}

document.addEventListener("click",function(event)
{

	var menu = document.getElementById("dropdownMenu");

	var profile = document.querySelector(".profile-menu");

	if(!profile.contains(event.target))
	{
		menu.style.display="none";
	}

}

);

</script>

</body>

</html>