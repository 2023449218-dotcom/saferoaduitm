<?php

session_start();

date_default_timezone_set('Asia/Kuala_Lumpur');


if(!isset($_SESSION['Role'])){

    header("Location: ../index.php");

    exit();
}


include("../db.php");



$studentID = $_SESSION['UserID'];


$studentQuery = mysqli_query(
$conn,
"SELECT *
FROM student
WHERE StudentID='$studentID'"
);

$student = mysqli_fetch_assoc($studentQuery);



$name = $student['Student_fullName'];

if(!isset($_GET['id'])){

    header("Location: my_complaints.php");

    exit();
}



$profileImage = !empty($student['Student_profile'])
?
"../uploads/profile/".$student['Student_profile']
:
"../images/default-profile.png";




$complaintID = mysqli_real_escape_string(
$conn,
$_GET['id']
);


$query = mysqli_query(
$conn,
"SELECT
c.*,
cc.CategoryName,
cs.Subcategory_name,
cs.Subcategory_risk,
cs.Subcategory_resolutionTime
FROM complaint c
INNER JOIN category cc
ON c.CategoryID = cc.CategoryID
INNER JOIN subcategory cs
ON c.SubcategoryID = cs.SubcategoryID
WHERE c.ComplaintID='$complaintID'"
);


$complaint = mysqli_fetch_assoc($query);


if(!$complaint){

    die("Complaint not found.");

}


$role = $_SESSION['Role'];

$userID = $_SESSION['UserID'];


if($role == "Student"
&&
$complaint['StudentID'] != $userID){

    die("Access Denied");
}

if($role == "Staff"
&&
$complaint['StaffID'] != $userID){

    die("Access Denied");

}




$assignedPolice = null;

if(!empty($complaint['PoliceID'])){



$policeQuery = mysqli_query(
$conn,
"SELECT *
FROM auxiliary_police
WHERE PoliceID='".
$complaint['PoliceID']."'"
);

$assignedPolice = mysqli_fetch_assoc($policeQuery);

}




$vehicleQuery = mysqli_query(
$conn,
"SELECT
cv.Reported_plateNum,
cv.Reported_type,
cv.Reported_color,
cv.Reported_model,
v.VehicleID,
s.Student_fullName,
st.Staff_fullName
FROM ComplaintVehicle cv
LEFT JOIN Vehicle v
ON cv.VehicleID = v.VehicleID
LEFT JOIN Student s
ON v.StudentID = s.StudentID
LEFT JOIN Staff st
ON v.StaffID = st.StaffID
WHERE cv.ComplaintID='$complaintID'"
);

$vehicle = mysqli_fetch_assoc($vehicleQuery);





$userEvidenceQuery =mysqli_query(
$conn,
"SELECT *
FROM evidence
WHERE ComplaintID='$complaintID'
AND Evidence_type='Complaint'"
);



$resolutionEvidenceQuery = mysqli_query(
$conn,
"SELECT *
FROM evidence
WHERE ComplaintID='$complaintID'
AND Evidence_type='Resolution'"
);




$timelineQuery = mysqli_query(
$conn,
"SELECT *
FROM complaint_timeline
WHERE ComplaintID='$complaintID'
ORDER BY TimelineDate ASC"
);

?>



<?php

$statusClass = "";

switch($complaint['Complaint_status']){

case "Pending":
$statusClass = "pending";
break;

case "In Progress":
$statusClass = "progress";
break;

case "Resolved":
$statusClass = "resolved";
break;

case "Escalated":
$statusClass = "escalated";
break;

case "Cancelled":
$statusClass = "cancelled";
break;

case "Warning Sent":
$statusClass = "warning";
break;

case "Awaiting Police":
$statusClass = "awaiting";
break;

}

?>




<!DOCTYPE html>

<html>

<head>

<link rel="icon" type="image/png" href="../images/logo.png">

<title>Complaint Details</title>

<link
rel="stylesheet"
href="https://unpkg.com/leaflet/dist/leaflet.css">

<script
src="https://unpkg.com/leaflet/dist/leaflet.js">
</script>


<style>
*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:Arial,sans-serif;
}

body{
background:#f4f6f9;
}

/* Sidebar */

.sidebar{
width:250px;
height:100vh;
background:#5E2D91;
position:fixed;
left:0;
top:0;
box-shadow:2px 0 10px rgba(0,0,0,0.1);
}

.logo-section{
text-align:center;
padding:20px;
border-bottom:1px solid rgba(255,255,255,0.15);
}

.sidebar-logo{
width:80px;
height:80px;
object-fit:contain;
}

.sidebar h2{
color:white;
font-size:20px;
margin-top:10px;
}

.sidebar a{
display:block;
padding:15px 20px;
color:white;
text-decoration:none;
font-size:15px;
transition:0.3s;
}

.sidebar a:hover{
background:#4b2374;
}

.active{
background:#4b2374;
border-left:5px solid white;
}

/* Topbar */

.topbar{
height:70px;
background:white;
display:flex;
justify-content:flex-end;
align-items:center;
padding:0 30px;
margin-left:250px;
box-shadow:0 2px 10px rgba(0,0,0,0.08);
}

.profile-menu{
display:flex;
align-items:center;
gap:10px;
position:relative;
cursor:pointer;
}

.username{
font-weight:bold;
color:#333;
}

.profile-menu img{
width:45px;
height:45px;
border-radius:50%;
object-fit:cover;
border:2px solid #5E2D91;
}

.dropdown{
display:none;
position:absolute;
right:0;
top:55px;
background:white;
width:180px;
border-radius:10px;
box-shadow:0 5px 15px rgba(0,0,0,0.15);
overflow:hidden;
z-index:9999;
}

.dropdown a{
display:block;
padding:12px 15px;
text-decoration:none;
color:#333;
}

.dropdown a:hover{
background:#f5f5f5;
}


.content{
margin-left:250px;
padding:30px;
}

.card{
background:white;
padding:25px;
border-radius:10px;
margin-bottom:20px;
box-shadow:0 2px 8px rgba(0,0,0,0.1);
}

h2{
color:#5E2D91;
}

table{
width:100%;
border-collapse:collapse;
}

td{
padding:12px;
border-bottom:1px solid #ddd;
}

td:first-child{
font-weight:bold;
width:250px;
}

.evidence{
width:220px;
height:220px;
object-fit:cover;
border-radius:10px;
margin:10px;
}



#map{
height:400px;
border-radius:10px;
}

.badge{
padding:8px 15px;
border-radius:20px;
color:white;
font-weight:bold;
}



.pending{
background:#f39c12;
}

.progress{
background:#1f4e79;
}

.resolved{
background:#27ae60;
}

.escalated{
background:#e74c3c;
}

.cancelled{
background:#7f8c8d;
}

.warning{
    background:#9b59b6;
}

.awaiting{
    background:#17a2b8;
}


.timeline{
position:relative;
margin-top:20px;
}

.timeline-item{
position:relative;
padding-left:50px;
margin-bottom:25px;
}

.timeline-item::before{
content:"";
position:absolute;
left:14px;
top:35px;
width:3px;
height:100%;
background:#d8d8d8;
}

.timeline-item:last-child::before{
display:none;
}

.timeline-icon{
width:30px;
height:30px;
border-radius:50%;
background:#5E2D91;
color:white;
display:flex;
align-items:center;
justify-content:center;
font-size:14px;
font-weight:bold;
position:absolute;
left:0;
top:0;
}

.timeline-content{
background:#fafafa;
padding:15px;
border-radius:10px;
box-shadow:0 2px 6px rgba(0,0,0,0.08);
}

.timeline-content b{
display:block;
margin-bottom:8px;
}

.timeline-content small{
color:#666;
}




.evidence-grid{
display:grid;
grid-template-columns:1fr 1fr;
gap:20px;
margin-bottom:20px;
}

.evidence-grid .card{
margin-bottom:0;
}

.evidence-gallery{
display:flex;
flex-wrap:wrap;
gap:12px;
}

.evidence-gallery img{
width:180px;
height:140px;
object-fit:cover;
border-radius:10px;
border:1px solid #ddd;
cursor:pointer;
transition:.3s;
}

.evidence-gallery img:hover{

transform:scale(1.05);

box-shadow:0 4px 12px rgba(0,0,0,.2);

}



.resolution-box{

background:#f8f9fa;

padding:15px;

border-left:5px solid #5E2D91;

border-radius:8px;

margin-bottom:20px;

}

.evidence-description{

color:#777;

font-size:14px;

margin:5px 0 15px;

}



.feedback-card{
background:#fff8e6;
border-left:6px solid #f39c12;
}

.feedback-buttons{
display:flex;
gap:20px;
margin:20px 0;
}

.feedback-option{
    flex:1;
    cursor:pointer;
}

.feedback-option input{
    display:none;
}

.feedback-box{
    padding:20px;
    border:2px solid #ddd;
    border-radius:10px;
    text-align:center;
    transition:.3s;
    font-weight:bold;
    background:white;
}

.feedback-option input:checked + .feedback-box{

    border-color:#5E2D91;

    background:#f3ebfc;

}

.feedback-box:hover{

    border-color:#5E2D91;

}

.feedback-submit{

    background:#5E2D91;

    color:white;

    border:none;

    padding:12px 25px;

    border-radius:8px;

    cursor:pointer;

    font-size:15px;

}

.feedback-submit:hover{

    background:#4b2374;

}


.action-buttons{
    display:flex;
    gap:12px;
    margin-bottom:20px;
}

.btn-back,
.btn-withdraw{
    padding:10px 18px;
    border-radius:8px;
    text-decoration:none;
    color:white;
}

.btn-back{
    background:#5E2D91;
}

.btn-withdraw{
    background:#e74c3c;
}

</style>

</head>

<body>

<div class="sidebar">

    <div class="logo-section">

    <img
    src="../images/logo.png"
    class="sidebar-logo">

    <h2>SafeRoad UiTM</h2>

    </div>

    <a href="dashboard.php" >Dashboard</a>

    <a href="submit_complaint_step1.php">Submit Complaint</a>

    <a href="my_complaints.php" class="active">My Complaints</a>

</div>




<div class="topbar">

    <div class="profile-menu">

        <span class="username">
        <?php echo $name; ?>
        </span>

        <img
        src="<?php echo $profileImage; ?>"
        alt="Profile"
        onclick="toggleMenu()">


        <div
        id="dropdownMenu"
        class="dropdown">

        <a href="profile.php">My Profile</a>

        <a href="../logout.php">Logout</a>

        </div>

    </div>

</div>





<div class="content">

    <div class="card">

    <div class="action-buttons">

    <a
    href="my_complaints.php"
    class="btn-back">

    ← Back to My Complaints

    </a>

    <?php if($complaint['Complaint_status']=="Pending" 
    && 
    empty($complaint['PoliceID'])){ ?>

    <a
    href="withdraw_complaint.php?id=<?php echo $complaintID; ?>"
    class="btn-withdraw"
    onclick="return confirm('Are you sure you want to withdraw this complaint?');">

    Withdraw Complaint

    </a>

    <?php } ?>

    </div>



<h2>Complaint Information</h2>

<table>

<tr>
<td>Reference Number</td>
<td><?php echo $complaint['ReferenceNumber']; ?></td>
</tr>




<tr>
<td>Category</td>
<td><?php echo $complaint['CategoryName']; ?></td>
</tr>



<tr>
<td>Subcategory</td>
<td><?php echo $complaint['Subcategory_name']; ?></td>
</tr>




<tr>
<td>Description</td>
<td>

<?php echo nl2br($complaint['Complaint_desc']); ?>

</td>
</tr>




<tr>
<td>Risk Level</td>
<td>

<?php

if($complaint['Subcategory_risk']=="High"){

echo "<span style='color:red;font-weight:bold;'>High</span>";

}

elseif($complaint['Subcategory_risk']=="Medium"){

echo "<span style='color:orange;font-weight:bold;'>Medium</span>";

}

else{

echo "<span style='color:green;font-weight:bold;'>Low</span>";

}

?>

</td>
</tr>





<tr>
<td>Status</td>
<td>

<span class="badge <?php echo $statusClass; ?>">

<?php echo $complaint['Complaint_status']; ?>

</span>

</td>
</tr>




<tr>
<td>Created Date</td>
<td>

<?php
echo date(
"d M Y h:i A",
strtotime(
$complaint['Complaint_createdAt']
)
);
?>

</td>
</tr>

<tr>
<td>Deadline</td>
<td>

<?php
echo date("d M Y h:i A",
strtotime($complaint['Complaint_deadline']));
?>

</td>
</tr>

</table>

<hr style="margin:25px 0;">

<h2>🚗 Vehicle Information</h2>


<?php if($vehicle){ ?>

<table>

<tr>
<td>Plate Number</td>
<td><?php echo $vehicle['Reported_plateNum']; ?></td>
</tr>

<tr>
<td>Vehicle Type</td>
<td><?php echo $vehicle['Reported_type']; ?></td>
</tr>

<tr>
<td>Vehicle Color</td>
<td><?php echo !empty($vehicle['Reported_color']) ? $vehicle['Reported_color'] : "-"; ?></td>
</tr>

<tr>
<td>Vehicle Model</td>
<td><?php echo !empty($vehicle['Reported_model']) ? $vehicle['Reported_model'] : "-"; ?></td>
</tr>

</table>

<?php } ?>

</div>



<?php

if($complaint['Complaint_status'] == "Warning Sent"
&&
$complaint['WaitingFeedback'] == 1){

?>

<div class="card feedback-card">

<h2>🚗 Vehicle Warning Feedback</h2>

<p>

A warning notice has been sent to the reported vehicle owner.

Please confirm whether the reported vehicle has been moved.

</p>

<br>

<form
action="submit_warning_feedback.php"
method="POST">

<input
type="hidden"
name="ComplaintID"
value="<?php echo $complaintID; ?>">

<div class="feedback-buttons">

<label class="feedback-option">

<input
type="radio"
name="Feedback"
value="YES"
required>

<div class="feedback-box">

<h3>✅ YES</h3>

<p>The vehicle has been moved.</p>

</div>



</label>

<label class="feedback-option">

<input
type="radio"
name="Feedback"
value="NO">

<div class="feedback-box">

<h3>❌ NO</h3>

<p>The vehicle is still in the area.</p>

</div>

</label>

</div>

<label>Remarks (Optional)</label>

<textarea

name="Remarks"

rows="4"

style="
width:100%;
padding:12px;
margin-top:8px;
border:1px solid #ccc;
border-radius:8px;">

</textarea>

<br><br>

<button
type="submit"
class="feedback-submit">

Submit Feedback

</button>

</form>

</div>

<?php

}

?>





<div class="card">

<h2>Location</h2>

<table>

<tr>
<td>Location Name</td>
<td><?php echo $complaint['Complaint_locationName']; ?></td>
</tr>

<tr>
<td>Specific Location Description</td>
<td><?php echo $complaint['Complaint_locationDesc']; ?></td>
</tr>

</table>

<br>

<h2>🗺️ Location Map</h2>

<br>

<div id="map"></div>

</div>








<div class="evidence-grid">

<!-- Complaint Evidence -->

<div class="card">

<h2>Complaint Evidence</h2>

<p class="evidence-description">
Evidence uploaded during complaint submission.
</p>

<hr><br>

<?php

if(mysqli_num_rows($userEvidenceQuery)==0){

echo "<p>No complaint evidence uploaded.</p>";

}

else{

echo "<div class='evidence-gallery'>";

while($file=mysqli_fetch_assoc($userEvidenceQuery)){

?>

<img
src="../uploads/evidence/<?php echo $file['Evidence_fileName']; ?>"
onclick="window.open(this.src)">

<?php

}

echo "</div>";

}

?>

</div>





<!-- Resolution Evidence -->

<div class="card">

<h2>Resolution Evidence</h2>

<p class="evidence-description">
Evidence uploaded by the auxiliary police after resolving the complaint.
</p>

<hr><br>

<?php

if(mysqli_num_rows($resolutionEvidenceQuery)==0){

echo "<p style='color:#777;'>No resolution evidence available yet.</p>";

}

else{

$file=mysqli_fetch_assoc($resolutionEvidenceQuery);

?>

<div class="resolution-box">

<p>

<b>👮 Resolved By</b><br>

<?php

echo $assignedPolice
?
$assignedPolice['Police_fullName']
:
"Unknown";

?>

</p>

<br>

<p>

<b>📅 Resolution Date</b><br>

<?php

echo date("d M Y h:i A",
strtotime($complaint['Complaint_resolvedAt'])
);

?>

</p>

<br>

<p>

<b>📝 Resolution Remarks</b>

</p>

<p>

<?php

echo nl2br($file['Evidence_resolutionRemark']);

?>

</p>

</div>

<div class="evidence-gallery">

<img
src="../uploads/evidence/<?php echo $file['Evidence_fileName']; ?>"
onclick="window.open(this.src)">

</div>

<?php } ?>

</div>

</div>






<div class="card">

    <h2>Timeline</h2>

    <?php

    if(mysqli_num_rows($timelineQuery) == 0){

        echo "<p>No timeline available.</p>";
    }

    else{
    ?>


    <div class="timeline">


    <?php
    while($timeline = mysqli_fetch_assoc($timelineQuery)){
    ?>


    <div class="timeline-item">

        <div class="timeline-icon">
        ✓
        </div>

        <div class="timeline-content">

        <b>
        <?php echo $timeline['TimelineDesc']; ?>
        </b>

        <br><br>

        <small>
        <?php
        echo date("d M Y h:i A",
        strtotime($timeline['TimelineDate']
        )
        );
        ?>
        </small>

        </div>

    </div>

    <?php
    }
    ?>

    </div>

<?php
}
?>

</div>




<script>

var map = L.map('map')

.setView(
[
<?php echo $complaint['Complaint_locationLat']; ?>,
<?php echo $complaint['Complaint_locationLong']; ?>
],
17
);

L.tileLayer(
'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png'
).addTo(map);

L.marker(
[
<?php echo $complaint['Complaint_locationLat']; ?>,
<?php echo $complaint['Complaint_locationLong']; ?>
]
)
.addTo(map)
.bindPopup(
"<?php echo addslashes($complaint['Complaint_locationName']); ?>"
)
.openPopup();

</script>



<script>

function toggleMenu(){

var menu = document.getElementById( "dropdownMenu");

if(menu.style.display=="block"){
    menu.style.display="none";
}

else{
    menu.style.display="block";
}

}

document.addEventListener("click",

function(event){

var menu = document.getElementById( "dropdownMenu");

var profile = document.querySelector(".profile-menu");

if(!profile.contains(event.target)){

    menu.style.display="none";
}

}

);

</script>

</body>

</html>