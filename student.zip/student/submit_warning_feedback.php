<?php

session_start();



if(!isset($_SESSION['Role'])){

    header("Location: ../index.php");
    exit();
}



include("../db.php");

require_once("../includes/send_email.php");
require_once("../includes/send_telegram.php");



$complaintID = intval($_POST['ComplaintID']);

$feedback = $_POST['Feedback'];

$remarks = mysqli_real_escape_string(
$conn,
trim($_POST['Remarks'])
);



$query = mysqli_query(
$conn,
"SELECT
c.*,
s.Subcategory_resolutionTime
FROM Complaint c
INNER JOIN Subcategory s
ON c.SubcategoryID = s.SubcategoryID
WHERE c.ComplaintID='$complaintID'"
);

$complaint = mysqli_fetch_assoc($query);

if(!empty($complaint['StudentID'])){

    $userQuery = mysqli_query(
    $conn,
    "SELECT
    Student_email,
    Student_fullName,
    telegram_chatID,
    notification_preference
    FROM student
    WHERE StudentID='".$complaint['StudentID']."'"
    );

    $user = mysqli_fetch_assoc($userQuery);

}

elseif(!empty($complaint['StaffID'])){

    $userQuery = mysqli_query(
    $conn,
    "SELECT
    Staff_email,
    Staff_fullName,
    telegram_chatID,
    notification_preference
    FROM staff
    WHERE StaffID='".$complaint['StaffID']."'"
    );

    $user = mysqli_fetch_assoc($userQuery);

}

if(!$complaint){

    die("Complaint not found.");

}




if($complaint['Complaint_status'] != "Warning Sent" ||

$complaint['WaitingFeedback'] != 1){

    die("This complaint is no longer waiting for feedback.");

}




$userName = !empty($complaint['StudentID'])
    ? $user['Student_fullName']
    : $user['Staff_fullName'];

$userEmail = !empty($complaint['StudentID'])
    ? $user['Student_email']
    : $user['Staff_email'];





if($feedback == "YES"){

mysqli_query(
$conn,
"UPDATE Complaint
SET
Complaint_status='Resolved',
WaitingFeedback=0,
Complaint_ResolvedAt=NOW()
WHERE ComplaintID='$complaintID'"
);

$subject = "Complaint Resolved";

$message = "

Dear ".$userName.",

Thank you for your feedback.

Your complaint (".$complaint['ReferenceNumber'].") has been marked as RESOLVED.

We appreciate your cooperation.

Regards,

SafeRoad UiTM
";

$timeline =

"Complainant confirmed that the reported vehicle has been moved.

Complaint automatically marked as Resolved.";

$timeline = mysqli_real_escape_string($conn, $timeline);

}



else{

$resolutionHours = (int)$complaint['Subcategory_resolutionTime'];
mysqli_query(
$conn,
"UPDATE Complaint
SET
Complaint_status='Awaiting Police',
WaitingFeedback=0,
Complaint_deadline = DATE_ADD(NOW(), INTERVAL $resolutionHours HOUR)
WHERE ComplaintID='$complaintID'"
);

$subject = "Complaint Reassigned";

$message = "

Dear ".$userName.",

Thank you for your feedback.

You confirmed that the reported issue has NOT been resolved.

Your complaint (".$complaint['ReferenceNumber'].") has been reassigned to the Auxiliary Police for further investigation.

You will receive another notification once there is further progress.

Regards,

SafeRoad UiTM
";

$timeline =

"Complainant confirmed that the reported vehicle is still causing the problem.

Complaint status changed to Awaiting Police.";

$timeline = mysqli_real_escape_string($conn, $timeline);

}





$insert = mysqli_query(
$conn,
"INSERT INTO Complaint_timeline
(
ComplaintID,
AdminID,
TimelineDesc,
TimelineDate
)
VALUES
(
'$complaintID',
NULL,
'$timeline',
NOW()
)"
);

if(!$insert){

    die(mysqli_error($conn));
}





mysqli_query(
$conn,
"UPDATE Complaint
SET
Complaint_feedbackRemark='$remarks'
WHERE ComplaintID='$complaintID'"
);


if($user['notification_preference']=="Email"){

    sendEmail(
        !empty($complaint['StudentID']) ? $user['Student_email'] : $user['Staff_email'],
        !empty($complaint['StudentID']) ? $user['Student_fullName'] : $user['Staff_fullName'],
        $subject,
        nl2br($message)
    );

}
elseif($user['notification_preference']=="Telegram"){

    if(!empty($user['telegram_chatID'])){

        sendTelegram(
            $user['telegram_chatID'],
            strip_tags($message)
        );

    }

}









header(

"Location:view_complaint.php?id=".$complaintID

);

exit();

